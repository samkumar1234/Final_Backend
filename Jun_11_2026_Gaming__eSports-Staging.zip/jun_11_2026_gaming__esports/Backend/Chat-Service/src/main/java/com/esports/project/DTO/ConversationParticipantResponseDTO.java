package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.entity.Conversation;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConversationParticipantResponseDTO {

    private String id;
    private Conversation conversation;
    private String participant;
    private boolean isAdmin;
    private boolean isMuted;
    private LocalDateTime joinedAt;
}
