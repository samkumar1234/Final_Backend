package com.esports.project.auth;

import com.esports.project.repository.ConversationParticipantsRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

@Service
public class ConversationAuthenticator {
    private final ConversationParticipantsRepository participantRepository;

    public ConversationAuthenticator(ConversationParticipantsRepository participantRepository)
    {
        this.participantRepository = participantRepository;
    }

    public void validateConversationAccess(String conversationId,String sender)
    {
        boolean exists = participantRepository.existsByConversation_IdAndParticipant(conversationId,sender);
        if (!exists)
        {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Access denied");

        }
    }
}
