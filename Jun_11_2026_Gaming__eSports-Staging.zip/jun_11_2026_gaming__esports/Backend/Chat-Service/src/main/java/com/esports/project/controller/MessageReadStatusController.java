package com.esports.project.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.entity.MessageReadStatus;
import com.esports.project.service.MessageReadStatusService;

@RestController
@RequestMapping("/chat/read-status")
public class MessageReadStatusController {

    private final MessageReadStatusService statusService;

    public MessageReadStatusController(MessageReadStatusService statusService)
    {
        this.statusService = statusService;
    }

    @GetMapping
    public List<MessageReadStatus> getAllMessageReadStatus()
    {
        return statusService.getAllMessageReadStatus();
    }
    
    @GetMapping("/{id}")
    public MessageReadStatus getMessageReadStatusById(@PathVariable String id)
    {
        return statusService.getStatusById(id);
    }

    @GetMapping("/message/{id}")
    public List<MessageReadStatus> getMessageReadStatusByMessageId(@PathVariable String id)
    {
        return statusService.getByMessageId(id);
    }

    @PostMapping
    public MessageReadStatus addMessageReadStatus(@RequestBody MessageReadStatus status)
    {
        return statusService.addMessageReadStatus(status);
    }

    @PutMapping
    public MessageReadStatus updateMessageReadStatus(@RequestBody MessageReadStatus status)
    {
        return statusService.updateMessageReadStatus(status);
    }

    @DeleteMapping("/{id}")
    public void deleteMessageReadStatus(@PathVariable String id)
    {
        statusService.deleteMessageReadStatus(id);
    }
}
