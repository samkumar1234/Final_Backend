package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.entity.MessageReadStatus;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.ValidationException;
import com.esports.project.repository.MessageReadStatusRepository;



@Service
public class MessageReadStatusService {

    private final MessageReadStatusRepository MRSrep;
    
    public MessageReadStatusService(MessageReadStatusRepository MRSrep)
    {
        this.MRSrep = MRSrep;
    }

    public List<MessageReadStatus> getAllMessageReadStatus()
    {
        return MRSrep.findAll();
    }

    public MessageReadStatus getStatusById(String id)
    {
        return MRSrep.findById(id).orElseThrow(
            ()-> new NotFoundException("Message Read Status Id not Found :"+id)
        );
    }

    public List<MessageReadStatus> getByMessageId(String id)
    {
        return MRSrep.findByMessage_Id(id);
    }

    public MessageReadStatus addMessageReadStatus(MessageReadStatus status)
    {
        if (status.getMessage() == null)
        {
            throw new ValidationException("Message is required");
        }
        return MRSrep.save(status);
    }

    public MessageReadStatus updateMessageReadStatus(MessageReadStatus status)
    {
        MessageReadStatus existingStatus = MRSrep.findById(status.getId()).orElseThrow(
            ()-> new NotFoundException("Message Status Not Found")
        );
        existingStatus.setReadAt(LocalDateTime.now());
        existingStatus.setReadBy(status.getReadBy());
        return MRSrep.save(existingStatus);
    }

    public void deleteMessageReadStatus(String id)
    {
        if (!MRSrep.existsById(id))
        {
            throw new NotFoundException("Message Status Not Found");
        }
        MRSrep.deleteById(id);
    }
}
