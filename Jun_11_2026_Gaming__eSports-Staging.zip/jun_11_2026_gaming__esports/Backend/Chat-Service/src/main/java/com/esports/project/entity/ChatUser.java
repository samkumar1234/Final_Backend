package com.esports.project.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name="chat_users")
public class ChatUser {
    @Id
    @Column(name="username")
    private String username;

    @Column(nullable = false)
    private String role;

    @Column(nullable = false)
    private String status;


}
