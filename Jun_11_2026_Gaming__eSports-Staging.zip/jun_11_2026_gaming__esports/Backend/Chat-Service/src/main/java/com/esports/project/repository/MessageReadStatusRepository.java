package com.esports.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.MessageReadStatus;

@Repository
public interface MessageReadStatusRepository extends JpaRepository<MessageReadStatus,String>{

    List<MessageReadStatus> findByMessage_Id(String message_id);
}
