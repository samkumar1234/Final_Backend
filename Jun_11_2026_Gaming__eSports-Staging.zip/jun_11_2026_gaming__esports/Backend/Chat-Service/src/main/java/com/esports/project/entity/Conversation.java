package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.SQLRestriction;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.jsonwebtoken.lang.Collections;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;

import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "conversations")
public class Conversation {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String conversationType;
    private String name;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private String createdBy;

    // conversationParticipants

    @OneToMany(mappedBy = "conversation",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JsonManagedReference(value = "conversation-participants")
    private List<ConversationParticipants> conversationParticipants;

    // converation message mapping

   /*  @OneToMany(mappedBy = "conversation", fetch = FetchType.LAZY)
    @JsonManagedReference(value = "converation-message")*/

    @Transient
    private List<Message> messages = Collections.emptyList();

}
