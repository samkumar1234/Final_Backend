package com.esports.project.websocket;


import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.esports.project.DTO.ChatUserDTO;
import com.esports.project.DTO.MessageRequestDTO;
import com.esports.project.DTO.MessageResponseDTO;
import com.esports.project.DTO.ReadReceiptDTO;
import com.esports.project.DTO.SocketMessageDTO;
import com.esports.project.DTO.SocketReceiptDTO;
import com.esports.project.DTO.SocketRequestDTO;
import com.esports.project.entity.ConversationParticipants;
import com.esports.project.entity.Message;
import com.esports.project.entity.MessageReadStatus;
import com.esports.project.mapper.MessageMapper;
import com.esports.project.service.ChatParticipantService;
import com.esports.project.service.ChatUserService;
import com.esports.project.service.JwtService;
import com.esports.project.service.MessageReadStatusService;
import com.esports.project.service.MessageService;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.jsonwebtoken.Claims;


@Component
public class ChatWebSocketHandler extends TextWebSocketHandler{

    private final MessageService messageService;
    private final MessageMapper messageMapper;
    private final ChatParticipantService participantService;
    private final MessageReadStatusService messageReadStatusService;
    private final ChatUserService chatUserService;
    private final ObjectMapper mapper = new ObjectMapper();

    private final Map<String,WebSocketSession> userSessions = new ConcurrentHashMap<>();
    private final Map<String,LocalDateTime> lastMessageSent = new ConcurrentHashMap<>();

    private final JwtService jwtService;
    
    public ChatWebSocketHandler(MessageService messageService,MessageMapper messageMapper,ChatParticipantService participantService,JwtService jwtService,
    MessageReadStatusService messageReadStatusService,ChatUserService chatUserService)//,ObjectMapper mapper)
    {
        this.messageMapper = messageMapper;
        this.messageService = messageService;
        this.participantService = participantService;
        this.jwtService = jwtService;
        this.messageReadStatusService = messageReadStatusService;
        this.chatUserService = chatUserService;
        //this.mapper = mapper;
    }

    @Override 
    public void afterConnectionEstablished(WebSocketSession session) throws Exception
    {
        
        String query = session.getUri().getQuery();
        if (query==null) 
        {
            session.close();
            return;
        }

        String token = query.split("=")[1];

        if(!jwtService.validateToken(token))
        {
            session.close();
            return;
        }
        
        Claims claims = jwtService.extractAllClaims(token);
        String name = claims.getSubject();
        userSessions.put(name,session);
        session.getAttributes().put("name",name);


        if (chatUserService.checkUser(name).equalsIgnoreCase("Invalid"))
        {
        ChatUserDTO dto = new ChatUserDTO();
        dto.setUser(name);
        dto.setRole("Participant");
        dto.setStatus("ACTIVE");
        chatUserService.addUser(dto);
        }
    }

    @Override
    protected void handleTextMessage(WebSocketSession session,TextMessage message) throws Exception
    {
        try{

        SocketRequestDTO request = mapper.readValue(message.getPayload(),SocketRequestDTO.class);
        
        String messageType = request.getMessageType();
        MessageRequestDTO dto = request.getData();
        String name = (String) session.getAttributes().get("name");
        System.out.println(dto.getContent());
        if ("MESSAGE_CREATED".equals(messageType) && canSendMessage(name))
        {
            System.out.println("creating a new message");
            Message entity = messageMapper.toCreateEntity(dto);
            //entity.setCreatedAt(LocalDateTime.now());
            entity.setSender(name);
            if (!isParticipant(name,dto.getConversationId())) return; //|| isMuted(name,dto.getConversationId())) return;
            messageCreation(entity,dto.getConversationId());
        }
        else if ("MESSAGE_UPDATED".equals(messageType))
        {
            Message entity = messageMapper.toUpdateEntity(dto);
            entity.setSender(name);
            if (validateMessageId(entity.getId(), name))
            {
            messageUpdate(entity, dto.getConversationId());
            }
        
        }
        else if ("MESSAGE_DELETED".equals(messageType))
        {
            Message entity = messageMapper.toUpdateEntity(dto);
            entity.setSender(name);
            if (validateMessageId(entity.getId(),name))
            {
            messageDelete(entity, dto.getConversationId());
            }
        }
        else if("MESSAGE_READ".equals(messageType))
        {
            messageRead(dto,name);
        }
    }
    catch(Exception e)
    {
        e.printStackTrace();
        throw e;
    }
        
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session,CloseStatus status)
    {
        userSessions.remove(session.getAttributes().get("name"));
        lastMessageSent.remove(session.getAttributes().get("name"));
        System.out.println("Disconnected :"+session.getId());
    }

    private void messageCreation(Message entity,String conversationId) throws Exception
    {
        System.out.println("creating a new message in function");
        Message saved = messageService.addMessage(entity);
        MessageResponseDTO responseDTO = messageMapper.toResponseEntity(saved);
        SocketMessageDTO socketMessage = new SocketMessageDTO("MESSAGE_CREATED",responseDTO);
        String json = mapper.writeValueAsString(socketMessage);

        broadcastMessage(conversationId, json);
        
        System.out.println("Message added successfully");

    }

    private void messageUpdate(Message entity,String conversationId) throws Exception
    {

        Message updated = messageService.updateMessage(entity);
        MessageResponseDTO responseDTO = messageMapper.toResponseEntity(updated);
        SocketMessageDTO socketMessage = new SocketMessageDTO("MESSAGE_UPDATED",responseDTO);
        String json = mapper.writeValueAsString(socketMessage);

        broadcastMessage(conversationId, json);
        System.out.println("Message updated successfully");
    }

    private void messageDelete(Message entity,String conversationId) throws Exception
    {

        messageService.deleteMessage(entity.getId());
        Message deleted = messageService.getMessageById(entity.getId());
        
        MessageResponseDTO responseDTO = messageMapper.toResponseEntity(deleted);
        SocketMessageDTO socketMessage = new SocketMessageDTO("MESSAGE_DELETED",responseDTO);
        String json = mapper.writeValueAsString(socketMessage);

        broadcastMessage(conversationId, json);
        System.out.println("Message deleted successfully");
    }

    private void messageRead(MessageRequestDTO dto,String name) throws Exception
    {
        Message message = messageService.getMessageById(dto.getId());
        if (!message.getConversation().getConversationType().equals("P2P"))
        {
            return;
        }

        String conversationId = message.getConversation().getId();

        MessageReadStatus status = new MessageReadStatus();
        status.setMessage(message);
        status.setReadBy(name);
    
        messageReadStatusService.addMessageReadStatus(status);
        ReadReceiptDTO receipt = new ReadReceiptDTO();
        receipt.setReadBy(name);
        receipt.setMessageId(message.getId());

        SocketReceiptDTO socketMessage = new SocketReceiptDTO("MESSAGE_READ",receipt);
        String json = mapper.writeValueAsString(socketMessage);

        broadcastMessage(conversationId, json);


    }

    private void broadcastMessage(String conversationId,String json) throws Exception
    {
        List<ConversationParticipants> participants = participantService.getParticipantsByConversationId(conversationId);

            for (ConversationParticipants participant : participants)
            {
                WebSocketSession target = userSessions.get(participant.getParticipant());

                if (target != null)
                {
                    target.sendMessage(new TextMessage(json));
                }
            }

    }

    private boolean validateMessageId(String id,String name)
    {
        Message existing = messageService.getMessageById(id);
        return existing.getSender().equals(name);

    }

    private boolean isParticipant(String userName,String conversationId)
    {
        return participantService.getParticipant(conversationId,userName)!=null;
    }
    
    /*private boolean isMuted(String name,String conversationId)
    {
        return participantService.getIsMuted(name,conversationId);
    }*/

    private boolean canSendMessage(String username)
    {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime lastSent = lastMessageSent.get(username);

        if (lastSent!=null && Duration.between(lastSent,now).toMillis()<1000)
        {
            return false;
        }
        lastMessageSent.put(username,now);
        return true;
    }

    public void notifyParticipantRemoved(String username,String conversationId) throws Exception{
        WebSocketSession target = userSessions.get(username);
        if (target==null) return;
        MessageResponseDTO dto = new MessageResponseDTO();
        dto.setConversationId(conversationId);
        SocketMessageDTO msg = new SocketMessageDTO("PARTICIPANT_REMOVED",dto);
        String json = mapper.writeValueAsString(msg);
        target.sendMessage(new TextMessage(json));


    }
}
