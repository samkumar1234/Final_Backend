package com.esports.project.controller;

import java.time.LocalDateTime;

import java.util.List;


//import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
/*import org.springframework.web.bind.annotation.PostMapping; //Using WebSocket to send messages here
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;*/
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.MessageFetchDTO;
//import com.esports.project.DTO.MessageRequestDTO;
import com.esports.project.DTO.MessageResponseDTO;
//import com.esports.project.entity.Message;
import com.esports.project.mapper.MessageMapper;
import com.esports.project.service.MessageService;

import org.springframework.security.core.Authentication;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.auth.ConversationAuthenticator;

@RestController
@RequestMapping("/chat/message")
public class MessageController {

    private final MessageService ms;
    private final MessageMapper mm;
    private final ConversationAuthenticator authenticator;

    public MessageController(MessageService ms,MessageMapper mm,ConversationAuthenticator authenticator)
    {
        this.ms = ms;
        this.mm = mm;
        this.authenticator = authenticator;
    }
    
    /*@GetMapping
    public List<MessageResponseDTO> getAllMessages()
    {
        return ms.getAllMessages().stream().map(mm :: toResponseEntity).toList(); 
    }*/

    /*@GetMapping("/{id}")
    public MessageResponseDTO getMessageById(@PathVariable String id)
    {
        return mm.toResponseEntity(ms.getMessageById(id));
    }*/

    /*@GetMapping("/conversation/{conversation_id}")
    public List<MessageResponseDTO> getMessagesByConversationId(@PathVariable String conversation_id)
    {
        return ms.getMessagesByConversationId(conversation_id).stream().map(mm :: toResponseEntity).toList();
    }

    @PostMapping
    public MessageResponseDTO addMessage(@RequestBody MessageRequestDTO dto)
    {
        Message message = mm.toCreateEntity(dto);
        return mm.toResponseEntity(ms.addMessage(message));
    }

    @PutMapping
    public MessageResponseDTO updateMessage(@RequestBody MessageRequestDTO dto)
    {
        Message message = mm.toUpdateEntity(dto);
        return mm.toResponseEntity(ms.updateMessage(message));
    }

    @DeleteMapping
    public void deleteMessages()
    {
        ms.deleteALL();
    }*/ 

    /*@DeleteMapping("/{id}")
    public void deleteMessageById(@PathVariable String id)
    {
        ms.deleteMessage(id);
    }*/

    @GetMapping("/conversation")
    public List<MessageResponseDTO> getMessagesByConversationId(@RequestParam String id,@RequestParam(required=false) LocalDateTime before,Authentication authentication)
    {
        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();
        authenticator.validateConversationAccess(id,user.getUsername());
        before = before == null ? LocalDateTime.now() : before;
        //return ms.getPagedMessagesByConversationId(id,page).map(mm::toResponseEntity);
        return ms.getSelectFewMessageById(id,before).stream().map(mm::toResponseEntity).toList();
    }
}
