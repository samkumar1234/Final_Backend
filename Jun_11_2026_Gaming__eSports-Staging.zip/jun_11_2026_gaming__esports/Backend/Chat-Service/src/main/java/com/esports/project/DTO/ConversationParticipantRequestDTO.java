package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConversationParticipantRequestDTO {

    private String id;
    private String conversationId;
    private String participant;
    private Boolean isAdmin;
    private Boolean isMuted;
}
