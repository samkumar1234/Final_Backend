package com.esports.project.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.entity.ConversationParticipants;
import com.esports.project.mapper.ParticipantMapper;
import com.esports.project.service.ChatParticipantService;

import jakarta.validation.ValidationException;

import org.springframework.security.core.Authentication;

import com.esports.project.DTO.ConversationParticipantRequestDTO;
import com.esports.project.DTO.ConversationParticipantResponseDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.auth.ConversationAuthenticator;


@RestController
@RequestMapping("/chat/participant")
public class ConversationParticipantController {

    private final ChatParticipantService chatParticipantService;
    private final ConversationAuthenticator authenticator;
    private final ParticipantMapper participantMapper;

    public ConversationParticipantController(ChatParticipantService chatParticipantService,ConversationAuthenticator authenticator,ParticipantMapper participantMapper)
    {
        this.chatParticipantService = chatParticipantService;
        this.authenticator = authenticator;
        this.participantMapper = participantMapper;
    }

    /*@GetMapping
    public List<ConversationParticipants> getAllParticipants()
    {
        return chatParticipantService.getAllParticipants();
    }*/

    @GetMapping("/{id}")
    public ConversationParticipantResponseDTO getParticipantById(@PathVariable String id)
    {
        return participantMapper.toResponseDTO(chatParticipantService.getParticipantById(id));
    }

    @GetMapping("/user")
    public List<ConversationParticipantResponseDTO> getConverationByParticipants(Authentication authentication)
    {
        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();
        return chatParticipantService.getConversationsByParticipant(user.getUsername()).stream().map(participantMapper :: toResponseDTO).toList();
    }

    @PostMapping
    public ConversationParticipantResponseDTO addParticipant(@RequestBody ConversationParticipantRequestDTO dto,Authentication authentication)
    {
        ConversationParticipants participant = participantMapper.toCreateEntity(dto);
        String convoID = participant.getConversation().getId();
        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();
        authenticator.validateConversationAccess(convoID,user.getUsername());
        return participantMapper.toResponseDTO(chatParticipantService.addParticipant(participant));
    }

    @PutMapping
    public ConversationParticipantResponseDTO updateParticipantById(@RequestBody ConversationParticipantRequestDTO dto,Authentication authentication)
    {
        ConversationParticipants participant = participantMapper.toUpdateEntity(dto);
        String convoID = participant.getConversation().getId();
        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();
        authenticator.validateConversationAccess(convoID,user.getUsername());
        return participantMapper.toResponseDTO(chatParticipantService.updateParticipant(participant,user.getUsername()));
    }

    @DeleteMapping("/{id}")
    public void deleteParticipantById(@PathVariable String id,Authentication authentication)
    {
        ConversationParticipants participant = chatParticipantService.getParticipantById(id);
        String convoId = participant.getConversation().getId();
        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();
        authenticator.validateConversationAccess(convoId,user.getUsername());
        String targetUser = participant.getParticipant();
        if (!targetUser.equals(user.getUsername()))
        {
            ConversationParticipants currentParticipant = chatParticipantService.getParticipant(convoId, user.getUsername());
            if (!Boolean.TRUE.equals(currentParticipant.getIsAdmin()))
            {
                throw new ValidationException("Forbidden: Unauthorized access");
            }

        }
        chatParticipantService.removeParticipant(id);
    }


}
