package com.esports.project.config;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.service.JwtService;

import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtConfig extends OncePerRequestFilter {

        @Autowired
        private JwtService jwtService;


        @Override
        protected void doFilterInternal(
                        HttpServletRequest request,
                        HttpServletResponse response,
                        FilterChain filterChain)
                        throws ServletException, IOException {

                String authHeader = request.getHeader("Authorization");

                if (authHeader != null &&
                                authHeader.startsWith("Bearer ")) {

                        String token = authHeader.substring(7);

                        if (jwtService.validateToken(token)) {

                                Claims claims = jwtService.extractAllClaims(token);

                                String username = claims.getSubject();

                                String userId = claims.get("user_id",String.class);

                                @SuppressWarnings("unchecked")
                                List<String> roles = claims.get("roles", List.class);

                                @SuppressWarnings("unchecked")
                                List<String> permissions =claims.get("permissions", List.class);

                                Set<GrantedAuthority> authorities = new HashSet<>();

                                if (roles != null) {
                                        roles.forEach(role -> authorities.add(
                                                        new SimpleGrantedAuthority(
                                                                        "ROLE_" + role)));
                                }

                                if (permissions != null) {
                                        permissions.forEach(permission -> authorities.add(
                                                        new SimpleGrantedAuthority(
                                                                        permission)));
                                }

                                UserDetailsDTO userDetailsDTO = new UserDetailsDTO(userId,username, roles, permissions);


                                UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
                                                userDetailsDTO,
                                                null,
                                                authorities);

                                SecurityContextHolder
                                                .getContext()
                                                .setAuthentication(auth);
                        }
                }

                filterChain.doFilter(request, response);
        }
}