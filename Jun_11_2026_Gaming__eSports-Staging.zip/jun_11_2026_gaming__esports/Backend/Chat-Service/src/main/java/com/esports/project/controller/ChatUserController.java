package com.esports.project.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.esports.project.DTO.ChatUserDTO;
import com.esports.project.service.ChatUserService;

//import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/chat/user")
public class ChatUserController {
    private ChatUserService service;
    public ChatUserController(ChatUserService service)
    {
        this.service = service;
    }

    @GetMapping("/{user}")
    public String getUser(@PathVariable String user)
    {
        return service.checkUser(user);
    }

}
