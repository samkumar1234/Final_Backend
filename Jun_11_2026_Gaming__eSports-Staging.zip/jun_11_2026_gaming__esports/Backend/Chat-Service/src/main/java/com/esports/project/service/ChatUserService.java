package com.esports.project.service;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.ChatUserDTO;
import com.esports.project.entity.ChatUser;
import com.esports.project.repository.ChatUserRepository;

@Service
public class ChatUserService {

    private final ChatUserRepository repository;

    public ChatUserService(ChatUserRepository repository)
    {
        this.repository = repository;
    }

    public String checkUser(String username)
    {
        ChatUser user = repository.findByUsername(username);
        if (user==null)
        {
            return "Invalid";
        }
        if ("BANNED".equalsIgnoreCase(user.getStatus()))
        {
            return "Banned";
        }
        return "Active";

    }

    public void addUser(ChatUserDTO dto)
    {
        System.out.println("Adding user:"+dto.getUser());
        ChatUser user = repository.findByUsername(dto.getUser());
        if (user==null)
        {
            user = new ChatUser();
            user.setUsername(dto.getUser());
            user.setRole(dto.getRole());
            user.setStatus("Active");
            repository.save(user);
        }
    }
}
