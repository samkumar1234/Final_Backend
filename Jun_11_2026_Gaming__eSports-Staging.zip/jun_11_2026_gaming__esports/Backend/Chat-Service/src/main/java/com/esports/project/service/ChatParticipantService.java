package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.entity.ConversationParticipants;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.ValidationException;
import com.esports.project.repository.ConversationParticipantsRepository;

@Service
public class ChatParticipantService {

    private final ConversationParticipantsRepository conversationParticipants;
    
    public ChatParticipantService(ConversationParticipantsRepository conversationParticipants)
    {
        this.conversationParticipants = conversationParticipants;
    }

    public ConversationParticipants addParticipant(ConversationParticipants conversationParticipant)
    {
        conversationParticipant.setCreatedAt(LocalDateTime.now());
        conversationParticipant.setJoinedAt(LocalDateTime.now());
        return conversationParticipants.save(conversationParticipant);
    }

    public List<ConversationParticipants> getAllParticipants()
    {
        return conversationParticipants.findAll();
    }

    public ConversationParticipants getParticipantById(String id)
    {
        return conversationParticipants.findById(id).orElseThrow(
            ()-> new NotFoundException("User Does Not Exist :"+id)
        );
    }

    public ConversationParticipants updateParticipant(ConversationParticipants participant,String adminName)
    {
        ConversationParticipants existingParticipant = conversationParticipants.findById(participant.getId()).orElseThrow(
         () ->  new NotFoundException("Participant does Not exist"));
        
        ConversationParticipants admin =  getParticipant(existingParticipant.getConversation().getId(),adminName);
        if (!Boolean.TRUE.equals(admin.getIsAdmin()))
        {
            throw new ValidationException("Forbidden : Unauthorized access");
        }
        existingParticipant.setIsAdmin(participant.getIsAdmin());
        existingParticipant.setIsMuted(participant.getIsMuted());
        
        return conversationParticipants.save(existingParticipant);
    }

    public void removeParticipant(String id)
    {
        if (!conversationParticipants.existsById(id))
        {
            throw new NotFoundException("Conversation Does Not Exist :"+id);
        }
        conversationParticipants.deleteById(id);
        
    }

    public List<ConversationParticipants> getConversationsByParticipant(String participant)
    {
        return conversationParticipants.findByParticipant(participant);
    }

    public List<ConversationParticipants> getParticipantsByConversationId(String conversationId)
    {
        return conversationParticipants.findByConversation_Id(conversationId);
    }

    public boolean getIsMuted(String participant,String conversationId)
    {
        return conversationParticipants.findByConversation_IdAndParticipant(conversationId, participant).getIsMuted();
    }

    public ConversationParticipants getParticipant(String conversationId,String userName)
    {
        return conversationParticipants.findByConversation_IdAndParticipant(conversationId, userName);
    }

    public String findExistingP2PConversation(String currentUser,String otherUser)
    {
        List<ConversationParticipants> userConversations =
            conversationParticipants
                .findByParticipantAndConversation_ConversationType(
                    currentUser,
                    "P2P"
                );

        for (ConversationParticipants participant : userConversations)
        {
            String conversationId = participant.getConversation().getId();

            List<ConversationParticipants> participants = getParticipantsByConversationId(conversationId);

            boolean containsOtherUser = participants.stream().anyMatch(p -> p.getParticipant().equals(otherUser));

            if (containsOtherUser)
            {
                return conversationId;
            }
        }
        return null;
    }
}

