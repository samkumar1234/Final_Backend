package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChatUserDTO {

    private String user;
    private String role;
    private String status;
}
