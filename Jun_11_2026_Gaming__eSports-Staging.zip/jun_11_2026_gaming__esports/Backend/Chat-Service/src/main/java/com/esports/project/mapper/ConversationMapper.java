package com.esports.project.mapper;

import org.springframework.stereotype.Component;

import com.esports.project.DTO.ConversationRequestDTO;
import com.esports.project.DTO.ConversationResponseDTO;
import com.esports.project.entity.Conversation;

@Component 
public class ConversationMapper {

    public Conversation toCreateEntity(ConversationRequestDTO dto)
    {
        Conversation conversation = new Conversation();
        conversation.setConversationType(dto.getConversationType());
        conversation.setName(dto.getName());
        conversation.setCreatedBy(dto.getCreatedBy());
        conversation.setDescription(dto.getDescription());

        return conversation;
    }

    public Conversation toUpdateEntity(ConversationRequestDTO dto)
    {
        Conversation conversation = new Conversation();
        conversation.setId(dto.getId());
        conversation.setName(dto.getName());
        conversation.setDescription(dto.getDescription());

        return conversation;
    }

    public ConversationResponseDTO toResponseEntity(Conversation conversation)
    {
        ConversationResponseDTO dto = new ConversationResponseDTO();

        dto.setConversationType(conversation.getConversationType());
        dto.setId(conversation.getId());
        dto.setCreatedBy(conversation.getCreatedBy());
        dto.setDescription(conversation.getDescription());
        dto.setName(conversation.getName());

        return dto;
    }
}
