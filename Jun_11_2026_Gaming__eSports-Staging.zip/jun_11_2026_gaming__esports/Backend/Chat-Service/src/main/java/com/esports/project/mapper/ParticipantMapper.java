package com.esports.project.mapper;

import org.springframework.stereotype.Component;

import com.esports.project.DTO.ConversationParticipantRequestDTO;
import com.esports.project.DTO.ConversationParticipantResponseDTO;
import com.esports.project.entity.Conversation;
import com.esports.project.entity.ConversationParticipants;



@Component
public class ParticipantMapper {


    public ConversationParticipants toCreateEntity(ConversationParticipantRequestDTO dto)
    {
        ConversationParticipants entity = new ConversationParticipants();
        Conversation conversation = new Conversation();
        conversation.setId(dto.getConversationId());
        entity.setConversation(conversation);
        entity.setParticipant(dto.getParticipant());
        entity.setIsAdmin(dto.getIsAdmin());
        entity.setIsMuted(dto.getIsMuted());

        return entity;
    }

    public ConversationParticipants toUpdateEntity(ConversationParticipantRequestDTO dto)
    {
        ConversationParticipants existing = new ConversationParticipants();
        Conversation conversation = new Conversation();
        conversation.setId(dto.getConversationId());
        existing.setParticipant(dto.getParticipant());
        existing.setId(dto.getId());
        existing.setConversation(conversation);
        existing.setIsAdmin(dto.getIsAdmin());
        existing.setIsMuted(dto.getIsMuted());

        //System.out.println("Incoming Admin: " + existing.getIsAdmin());
        //System.out.println("Incoming Muted: " + existing.getIsMuted());

        return existing;
    }

    public ConversationParticipantResponseDTO toResponseDTO(ConversationParticipants entity)
    {
        ConversationParticipantResponseDTO dto = new ConversationParticipantResponseDTO();

        dto.setAdmin(Boolean.TRUE.equals(entity.getIsAdmin()));
        dto.setConversation(entity.getConversation());
        dto.setId(entity.getId());
        dto.setJoinedAt(entity.getJoinedAt());
        dto.setMuted(Boolean.TRUE.equals(entity.getIsMuted()));
        dto.setParticipant(entity.getParticipant());

        return dto;
    }
}
