package com.esports.project.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.Message;

@Repository
public interface MessageRepository extends JpaRepository<Message,String> {

    public List<Message> findByConversation_Id(String conversationId);

    List<Message> findTop100ByConversation_IdAndCreatedAtBeforeOrderByCreatedAtDesc(String conversationId,LocalDateTime before);
}
