package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReadReceiptDTO {
    private String messageId;
    private String readBy;
}
