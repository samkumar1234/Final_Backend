package com.esports.project.controller;

//import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ConversationRequestDTO;
import com.esports.project.DTO.ConversationResponseDTO;
import com.esports.project.auth.ConversationAuthenticator;
import com.esports.project.entity.Conversation;
import com.esports.project.entity.ConversationParticipants;
import com.esports.project.mapper.ConversationMapper;
import com.esports.project.service.ChatParticipantService;
import com.esports.project.service.ConversationService;


import org.springframework.security.core.Authentication;

import com.esports.project.DTO.UserDetailsDTO;


@RestController
@RequestMapping("/chat/conversation")
public class ConversationController {

    private final ConversationService conversationService;
    private final ConversationMapper conversationMapper;
    private final ConversationAuthenticator authenticator;
    private final ChatParticipantService participantService;
    public ConversationController(ConversationService conversationService,ConversationMapper conversationMapper,ConversationAuthenticator authenticator,ChatParticipantService participantService)
    {
        this.conversationService = conversationService;
        this.authenticator = authenticator;
        this.conversationMapper = conversationMapper;
        this.participantService = participantService;
    }

    @PostMapping
    public ConversationResponseDTO createConversation(@RequestBody ConversationRequestDTO dto,Authentication authentication)
    {

        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();

        Conversation conversation = conversationMapper.toCreateEntity(dto);
        Conversation saved = conversationService.createConversation(conversation);
        ConversationParticipants owner = new ConversationParticipants();
        owner.setConversation(saved);
        owner.setIsAdmin(true);
        owner.setIsMuted(false);
        owner.setParticipant(user.getUsername());

        participantService.addParticipant(owner);

        return conversationMapper.toResponseEntity(saved);
    }

    @GetMapping("/{id}")
    public ConversationResponseDTO getConversationById(@PathVariable String id,Authentication authentication)
    {
        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();
        authenticator.validateConversationAccess(id,user.getUsername());
        return conversationMapper.toResponseEntity(conversationService.getConversationById(id));
    }

    /*@GetMapping
    public List<ConversationResponseDTO> getAllConversations()
    {
        return conversationService.getAllConversations().stream().map(conversationMapper::toResponseEntity).toList();
    }*/

    @DeleteMapping("/{id}")
    public void deleteConversation(@PathVariable String id,Authentication authentication)
    {
        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();
        authenticator.validateConversationAccess(id,user.getUsername());
        conversationService.deleteConversation(id);
    }

    @PutMapping
    public ConversationResponseDTO updateConversation(@RequestBody ConversationRequestDTO dto)
    {
        Conversation conversation = conversationMapper.toUpdateEntity(dto);
        return conversationMapper.toResponseEntity(conversationService.updateConversation(conversation));
    }
}
