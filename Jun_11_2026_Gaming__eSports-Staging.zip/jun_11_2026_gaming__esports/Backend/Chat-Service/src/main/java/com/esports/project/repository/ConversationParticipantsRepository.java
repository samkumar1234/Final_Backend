package com.esports.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.ConversationParticipants;

@Repository
public interface ConversationParticipantsRepository extends JpaRepository<ConversationParticipants,String>{
    
    List<ConversationParticipants> findByParticipant(String participant);

    List<ConversationParticipants> findByConversation_Id(String conversationId);

    ConversationParticipants findByConversation_IdAndParticipant(String conversationId, String participant);

    boolean existsByConversation_IdAndParticipant(String conversationId, String sender);

    List<ConversationParticipants> findByParticipantAndConversation_ConversationType(String participant,String conversationType);
}
