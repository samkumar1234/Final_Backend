package com.esports.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.ChatUser;

@Repository
public interface ChatUserRepository extends JpaRepository<ChatUser,String>{

    ChatUser findByUsername(String username);

}
