package com.esports.project.DTO;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class UserDetailsDTO {
    private String userId;
    private String username;
    private List<String> roles = new ArrayList<>();
    private List<String> permissions = new ArrayList<>();

    public UserDetailsDTO(String userId,String username, List<String> roles, List<String> permissions) {
        this.userId = userId;
        this.roles = roles;
        this.username = username;
        this.permissions = permissions;
    }
    
}
