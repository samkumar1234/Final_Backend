package com.esports.project.exception;

public class ValidationException extends CustomException{
    public ValidationException(String message)
    {
        super(message);
    }

}
