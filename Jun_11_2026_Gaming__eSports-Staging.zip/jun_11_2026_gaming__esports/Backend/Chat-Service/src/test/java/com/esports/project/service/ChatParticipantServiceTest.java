package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

//import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.entity.Conversation;
import com.esports.project.entity.ConversationParticipants;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.ValidationException;
import com.esports.project.repository.ConversationParticipantsRepository;

@ExtendWith(MockitoExtension.class)
class ChatParticipantServiceTest {

    @Mock
    private ConversationParticipantsRepository conversationParticipants;

    @InjectMocks
    private ChatParticipantService service;

    @Test
    void shouldAddParticipant()
    {
        ConversationParticipants participant =
                new ConversationParticipants();

        when(conversationParticipants.save(any()))
                .thenAnswer(invocation ->
                        invocation.getArgument(0));

        ConversationParticipants result =
                service.addParticipant(participant);

        assertNotNull(result);
        assertNotNull(result.getCreatedAt());
        assertNotNull(result.getJoinedAt());
    }

    @Test
    void shouldGetAllParticipants()
    {
        when(conversationParticipants.findAll())
                .thenReturn(List.of(
                        new ConversationParticipants(),
                        new ConversationParticipants()));

        List<ConversationParticipants> result =
                service.getAllParticipants();

        assertEquals(2, result.size());
    }

    @Test
    void shouldGetParticipantById()
    {
        ConversationParticipants participant =
                new ConversationParticipants();

        participant.setId("123");

        when(conversationParticipants.findById("123"))
                .thenReturn(Optional.of(participant));

        ConversationParticipants result =
                service.getParticipantById("123");

        assertEquals("123", result.getId());
    }

    @Test
    void shouldThrowWhenParticipantNotFound()
    {
        when(conversationParticipants.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getParticipantById("123"));
    }

    @Test
    void shouldUpdateParticipantAsAdmin()
    {
        ConversationParticipants existing =
        new ConversationParticipants();

        existing.setId("123");
        existing.setIsAdmin(false);
        existing.setIsMuted(false);

        ConversationParticipants update =
        new ConversationParticipants();

        update.setId("123");
        update.setIsAdmin(true);
        update.setIsMuted(true);

        Conversation conversation =
        new Conversation();

        conversation.setId("conv-1");

        existing.setConversation(conversation);

        ConversationParticipants admin =
        new ConversationParticipants();

        admin.setIsAdmin(true);

        when(conversationParticipants.findById("123"))
        .thenReturn(Optional.of(existing));

        when(conversationParticipants
        .findByConversation_IdAndParticipant(
        "conv-1",
        "alan"))
        .thenReturn(admin);

        when(conversationParticipants.save(any()))
        .thenAnswer(i -> i.getArgument(0));

        ConversationParticipants result =
        service.updateParticipant(
        update,
        "alan");

        assertTrue(result.getIsAdmin());
        assertTrue(result.getIsMuted());
    }

    @Test
    void shouldThrowWhenUserIsNotAdmin()
    {
        ConversationParticipants existing =
                new ConversationParticipants();

        existing.setId("123");

        Conversation conversation =
                new Conversation();

        conversation.setId("conv-1");

        existing.setConversation(conversation);

        ConversationParticipants update =
                new ConversationParticipants();

        update.setId("123");

        ConversationParticipants user =
                new ConversationParticipants();

        user.setIsAdmin(false);

        when(conversationParticipants.findById("123"))
                .thenReturn(Optional.of(existing));

        when(conversationParticipants
                .findByConversation_IdAndParticipant(
                        "conv-1",
                        "alan"))
                .thenReturn(user);

        assertThrows(
                ValidationException.class,
                () -> service.updateParticipant(
                        update,
                        "alan"));
    }

    @Test
    void shouldRemoveParticipant()
    {
        when(conversationParticipants.existsById("123"))
                .thenReturn(true);

        service.removeParticipant("123");

        verify(conversationParticipants)
                .deleteById("123");
    }

    @Test
    void shouldThrowWhenRemovingMissingParticipant()
    {
        when(conversationParticipants.existsById("123"))
                .thenReturn(false);

        assertThrows(
                NotFoundException.class,
                () -> service.removeParticipant("123"));
    }

    @Test
    void shouldReturnConversationsByParticipant()
    {
        when(conversationParticipants.findByParticipant("alan"))
                .thenReturn(List.of(
                        new ConversationParticipants(),
                        new ConversationParticipants()));

        List<ConversationParticipants> result =
                service.getConversationsByParticipant("alan");

        assertEquals(2, result.size());
    }

    @Test
    void shouldReturnParticipantsByConversationId()
    {
        when(conversationParticipants.findByConversation_Id("conv-1"))
                .thenReturn(List.of(
                        new ConversationParticipants(),
                        new ConversationParticipants(),
                        new ConversationParticipants()));

        List<ConversationParticipants> result =
                service.getParticipantsByConversationId("conv-1");

        assertEquals(3, result.size());
    }

    @Test
        void shouldReturnMutedStatus()
        {
        ConversationParticipants participant =
                new ConversationParticipants();

        participant.setIsMuted(true);

        when(conversationParticipants
                .findByConversation_IdAndParticipant(
                        "conv-1",
                        "alan"))
                .thenReturn(participant);

        boolean result =
                service.getIsMuted(
                        "alan",
                        "conv-1");

        assertTrue(result);
        }

        @Test
void shouldReturnParticipant()
{
    ConversationParticipants participant =
            new ConversationParticipants();

    participant.setParticipant("alan");

    when(conversationParticipants
            .findByConversation_IdAndParticipant(
                    "conv-1",
                    "alan"))
            .thenReturn(participant);

    ConversationParticipants result =
            service.getParticipant(
                    "conv-1",
                    "alan");

    assertEquals(
            "alan",
            result.getParticipant());
}

@Test
void shouldReturnFalseWhenParticipantNotMuted()
{
    ConversationParticipants participant =
            new ConversationParticipants();

    participant.setIsMuted(false);

    when(conversationParticipants
            .findByConversation_IdAndParticipant(
                    "conv-1",
                    "alan"))
            .thenReturn(participant);

    boolean result =
            service.getIsMuted(
                    "alan",
                    "conv-1");

    assertFalse(result);
}
@Test
void shouldThrowWhenUpdatingMissingParticipant()
{
    ConversationParticipants update =
            new ConversationParticipants();

    update.setId("123");

    when(conversationParticipants.findById("123"))
            .thenReturn(Optional.empty());

    assertThrows(
            NotFoundException.class,
            () -> service.updateParticipant(
                    update,
                    "alan"));
}


}