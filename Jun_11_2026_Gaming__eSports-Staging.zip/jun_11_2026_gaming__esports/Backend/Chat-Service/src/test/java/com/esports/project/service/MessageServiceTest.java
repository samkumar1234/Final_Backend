package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.entity.Conversation;
import com.esports.project.entity.Message;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.ValidationException;
import com.esports.project.repository.MessageRepository;

@ExtendWith(MockitoExtension.class)
class MessageServiceTest {

    @Mock
    private MessageRepository messages;

    @InjectMocks
    private MessageService service;

    @Test
    void shouldSaveMessage()
    {
        Conversation conversation = new Conversation();
        conversation.setId("conv-1");

        Message message = new Message();
        message.setConversation(conversation);
        message.setContent("Hello");

        when(messages.save(any(Message.class)))
                .thenReturn(message);

        Message saved =
                service.addMessage(message);

        assertNotNull(saved);
        assertEquals(
                "Hello",
                saved.getContent());
    }

    @Test
    void shouldThrowWhenContentIsNull()
    {
        Conversation conversation = new Conversation();
        conversation.setId("conv-1");

        Message message = new Message();
        message.setConversation(conversation);

        assertThrows(
                ValidationException.class,
                () -> service.addMessage(message));
    }

    @Test
    void shouldThrowWhenConversationIsMissing()
    {
        Message message = new Message();
        message.setContent("Hello");

        assertThrows(
                ValidationException.class,
                () -> service.addMessage(message));
    }

    @Test
    void shouldGetMessageById()
    {
        Message message = new Message();
        message.setId("123");

        when(messages.findById("123"))
                .thenReturn(Optional.of(message));

        Message result =
                service.getMessageById("123");

        assertEquals(
                "123",
                result.getId());
    }

    @Test
    void shouldThrowWhenMessageNotFound()
    {
        when(messages.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getMessageById("123"));
    }

    @Test
    void shouldThrowWhenContentIsBlank()
    {
        Conversation conversation = new Conversation();
        conversation.setId("conv-1");

        Message message = new Message();
        message.setConversation(conversation);
        message.setContent(" ");

        assertThrows(
                ValidationException.class,
                () -> service.addMessage(message));
    }

    @Test
    void shouldThrowWhenConversationIdIsBlank()
    {
        Conversation conversation = new Conversation();
        conversation.setId("");

        Message message = new Message();
        message.setConversation(conversation);
        message.setContent("Hello");

        assertThrows(
                ValidationException.class,
                () -> service.addMessage(message));
    }

    @Test
    void shouldUpdateMessage()
    {
        Message existing = new Message();
        existing.setId("123");
        existing.setContent("Old");

        Message update = new Message();
        update.setId("123");
        update.setContent("New");

        when(messages.findById("123"))
                .thenReturn(Optional.of(existing));

        when(messages.save(any(Message.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Message result =
                service.updateMessage(update);

        assertEquals(
                "New",
                result.getContent());

        assertTrue(result.getIsEdited());
        assertNotNull(result.getEditedAt());
    }

    @Test
    void shouldThrowWhenUpdatingWithoutId()
    {
        Message update = new Message();

        assertThrows(
                ValidationException.class,
                () -> service.updateMessage(update));
    }

    @Test
    void shouldThrowWhenUpdatingMissingMessage()
    {
        Message update = new Message();
        update.setId("123");

        when(messages.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.updateMessage(update));
    }

    @Test
    void shouldSoftDeleteMessage()
    {
        Message existing = new Message();
        existing.setId("123");
        existing.setContent("Hello");

        when(messages.findById("123"))
                .thenReturn(Optional.of(existing));

        when(messages.save(any(Message.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        service.deleteMessage("123");

        assertEquals(
                "This Message Was Deleted",
                existing.getContent());

        assertTrue(existing.getIsDeleted());
        assertNotNull(existing.getDeletedAt());
    }

    @Test
    void shouldThrowWhenDeletingMissingMessage()
    {
        when(messages.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.deleteMessage("123"));
    }

    @Test
    void shouldReturnAllMessages()
    {
        when(messages.findAll())
                .thenReturn(
                        java.util.List.of(
                                new Message(),
                                new Message()));

        assertEquals(
                2,
                service.getAllMessages().size());
    }

    @Test
    void shouldReturnMessagesByConversation()
    {
        when(messages.findByConversation_Id("conv-1"))
                .thenReturn(
                        java.util.List.of(
                                new Message(),
                                new Message(),
                                new Message()));

        assertEquals(
                3,
                service.getMessagesByConversationId("conv-1")
                        .size());
    }

    @Test
    void shouldReturnLatestMessagesBeforeTimestamp()
    {
        LocalDateTime before =
                LocalDateTime.now();

        when(messages
                .findTop100ByConversation_IdAndCreatedAtBeforeOrderByCreatedAtDesc(
                        "conv-1",
                        before))
                .thenReturn(
                        List.of(
                                new Message(),
                                new Message()));

        List<Message> result =
                service.getSelectFewMessageById(
                        "conv-1",
                        before);

        assertEquals(2, result.size());
        }

     @Test
     void shouldDeleteAllMessages()
     {
        service.deleteALL();

        verify(messages)
                .deleteAll();
     }
}