package com.esports.project.DTO;

import com.esports.project.enums.SubscriptionType;

import lombok.Data;

@Data
public class SubscriptionFilterRequestDTO {

    private SubscriptionType userType;

    private String subscriptionPlanId;

    private Boolean expired;

	public SubscriptionType getUserType() {
		return userType;
	}

	public void setUserType(SubscriptionType userType) {
		this.userType = userType;
	}

	public String getSubscriptionPlanId() {
		return subscriptionPlanId;
	}

	public void setSubscriptionPlanId(String subscriptionPlanId) {
		this.subscriptionPlanId = subscriptionPlanId;
	}

	public Boolean getExpired() {
		return expired;
	}

	public void setExpired(Boolean expired) {
		this.expired = expired;
	}
    
    

}
