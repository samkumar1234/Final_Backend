package com.esports.project.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.CreateSubscriptionRequestDTO;
import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.DTO.SubscriptionFilterDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.DTO.UserSubscriptionResponseDTO;
import com.esports.project.entity.SubscriptionPlan;
import com.esports.project.entity.UserSubscription;
import com.esports.project.enums.SubscriptionStatus;
import com.esports.project.enums.SubscriptionType;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.UnauthorizedException;
import com.esports.project.repository.SubscriptionPlanRepository;
import com.esports.project.repository.UserSubscriptionRepository;
import com.esports.project.service.EventPublisher;
import com.esports.project.service.interfaces.UserSubscriptionService;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class UserSubscriptionServiceImpl
        implements UserSubscriptionService {

	@Autowired
    private UserSubscriptionRepository subscriptionRepository;
	@Autowired
    private SubscriptionPlanRepository planRepository;

    private final EventPublisher publisher;

    @Override
    public UserSubscriptionResponseDTO createSubscription(CreateSubscriptionRequestDTO request) {
    	
        SubscriptionPlan plan = planRepository.findById(
                        request.getSubscriptionPlanId())
                .orElseThrow(() ->
                        new NotFoundException(
                                "Subscription Plan not found"));

        LocalDateTime startDate = LocalDateTime.now();
        UserDetailsDTO userDetailsDTO = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserSubscription subscription = new UserSubscription();
        subscription.setUserId(userDetailsDTO.getUserId());
        subscription.setSubscriptionPlan(plan);
        subscription.setAmountPaid(request.getAmountPaid());
        subscription.setStartDate(startDate);
        subscription.setEndDate(startDate.plusDays(plan.getDurationDays()));
        subscription.setStatus(SubscriptionStatus.ACTIVE);
        subscription.setCreatedAt(LocalDateTime.now());
        subscription.setUpdatedAt(LocalDateTime.now());

        UserSubscription saved =
                subscriptionRepository.save(subscription);

        try {
    NotificationEventDTO notification =
            new NotificationEventDTO(
                    saved.getUserId(),
                    "Subscription Created",
                    "Subscription created successfully for Plan : "
                            + plan.getName()
                            + " with amount paid : "
                            + saved.getAmountPaid()
                            + ". Valid until : "
                            + saved.getEndDate());

    publisher.publishNotification(notification);

} catch (Exception e) {
    System.out.println(
            "Error Subscription Creation Notification : "
                    + e.getMessage());
}

        return mapToResponse(saved);
    }

    @Override
    public UserSubscriptionResponseDTO getSubscriptionById( String subscriptionId,String userId) {

        UserSubscription subscription =
                subscriptionRepository.findById(subscriptionId)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Subscription not found"));

        if (!subscription.getUserId().equals(userId)) {
            throw new UnauthorizedException(
                    "You are not allowed to access this subscription");
        }

        return mapToResponse(subscription);
    }

    @Override
    public List<UserSubscriptionResponseDTO> getSubscriptionsByUserId(
            String userId) {

        return subscriptionRepository.findByUserId(userId)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    @Override
    public List<UserSubscriptionResponseDTO> getAllSubscriptions() {

        return subscriptionRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    @Override
    public UserSubscriptionResponseDTO cancelSubscription(
            String subscriptionId) {

        UserSubscription subscription =
                subscriptionRepository.findById(subscriptionId)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Subscription not found"));

        if (subscription.getStatus() == SubscriptionStatus.CANCELLED) {
            throw new BadRequestException(
                    "Subscription already cancelled");
        }

        subscription.setStatus(SubscriptionStatus.CANCELLED);
        subscription.setUpdatedAt(LocalDateTime.now());

        try {
    NotificationEventDTO notification =
            new NotificationEventDTO(
                    subscription.getUserId(),
                    "Subscription Cancelled",
                    "Your subscription for Plan : "
                            + subscription.getSubscriptionPlan().getName()
                            + " has been cancelled successfully.");

    publisher.publishNotification(notification);

} catch (Exception e) {
    System.out.println(
            "Error Subscription Cancellation Notification : "
                    + e.getMessage());
}

        return mapToResponse(
                subscriptionRepository.save(subscription));
    }

    @Override
    public List<UserSubscriptionResponseDTO> getSubscriptionsByPlan(
            String planId) {

        return subscriptionRepository
                .findBySubscriptionPlan_Id(planId)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    @Override
    public List<UserSubscriptionResponseDTO> getSubscriptionsByUserType(
            SubscriptionType userType) {

        return subscriptionRepository
                .findBySubscriptionPlan_UserType(userType)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    @Override
    public List<UserSubscriptionResponseDTO> getActiveSubscriptions() {

        return subscriptionRepository.findAll()
                .stream()
                .filter(sub ->
                        sub.getStatus() == SubscriptionStatus.ACTIVE
                                && sub.getEndDate()
                                .isAfter(LocalDateTime.now()))
                .map(this::mapToResponse)
                .toList();
    }

    @Override
    public List<UserSubscriptionResponseDTO> getExpiredSubscriptions() {

        return subscriptionRepository.findAll()
                .stream()
                .filter(sub ->
                        sub.getEndDate()
                                .isBefore(LocalDateTime.now()))
                .map(this::mapToResponse)
                .toList();
    }

    @Override
    public List<UserSubscriptionResponseDTO> filterSubscriptions(
            SubscriptionFilterDTO filterDTO) {

        return subscriptionRepository.findAll()
                .stream()
                .filter(sub -> {

                    boolean matches = true;

                    if (filterDTO.getPlanId() != null) {
                        matches = matches &&
                                sub.getSubscriptionPlan()
                                        .getId()
                                        .equals(filterDTO.getPlanId());
                    }

                    if (filterDTO.getUserType() != null) {
                        matches = matches &&
                                sub.getSubscriptionPlan()
                                        .getUserType()
                                        .equals(filterDTO.getUserType());
                    }

                    if (filterDTO.getExpired() != null) {

                        boolean isExpired =
                                sub.getEndDate()
                                        .isBefore(LocalDateTime.now());

                        matches = matches &&
                                (isExpired ==
                                        filterDTO.getExpired());
                    }

                    return matches;
                })
                .map(this::mapToResponse)
                .toList();
    }

        private UserSubscriptionResponseDTO mapToResponse(UserSubscription subscription) {

            boolean expired = subscription.getEndDate()
                    .isBefore(LocalDateTime.now());

            UserSubscriptionResponseDTO response =
                    new UserSubscriptionResponseDTO();

            response.setId(subscription.getId());
            response.setUserId(subscription.getUserId());
            response.setSubscriptionPlanId(
                    subscription.getSubscriptionPlan().getId());
            response.setPlanName(
                    subscription.getSubscriptionPlan().getName());
            response.setUserType(
                    subscription.getSubscriptionPlan().getUserType());
            response.setAmountPaid(subscription.getAmountPaid());
            response.setStatus(subscription.getStatus());
            response.setStartDate(subscription.getStartDate());
            response.setEndDate(subscription.getEndDate());
            response.setCreatedAt(subscription.getCreatedAt());
            response.setUpdatedAt(subscription.getUpdatedAt());
            response.setExpired(expired);

            return response;
        }

}
