package com.esports.project.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.DTO.TournamentRegistrationPaymentRequestDTO;
import com.esports.project.DTO.TournamentRegistrationPaymentResponseDTO;
import com.esports.project.entity.TournamentRegistrationPayment;
import com.esports.project.enums.TournamentPaymentStatus;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.CustomException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.TournamentRegistrationPaymentRepository;
import com.esports.project.service.EventPublisher;
import com.esports.project.service.interfaces.TournamentRegistrationPaymentServiceInterface;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TournamentRegistrationPaymentServiceImpl
        implements TournamentRegistrationPaymentServiceInterface {

    @Autowired
    private TournamentRegistrationPaymentRepository repository;
    private final EventPublisher publisher;

    @Override
    public TournamentRegistrationPaymentResponseDTO registerTournamentPayment(
            TournamentRegistrationPaymentRequestDTO requestDTO) {

        if (requestDTO == null) {
            throw new BadRequestException("Request cannot be null");
        }

        if (requestDTO.getUserId() == null
                || requestDTO.getUserId().trim().isEmpty()) {
            throw new BadRequestException("User ID is required");
        }

        if (requestDTO.getTournamentRegistrationId() == null
                || requestDTO.getTournamentRegistrationId().trim().isEmpty()) {
            throw new BadRequestException(
                    "Tournament Registration ID is required");
        }

        if (requestDTO.getAmount() == null
                || requestDTO.getAmount().doubleValue() <= 0) {
            throw new BadRequestException(
                    "Payment amount must be greater than zero");
        }

        if (requestDTO.getPaymentMethod() == null) {
            throw new BadRequestException("Payment method is required");
        }

        TournamentRegistrationPayment payment =
                new TournamentRegistrationPayment();

        payment.setAmount(requestDTO.getAmount());
        payment.setPaymentMethod(requestDTO.getPaymentMethod());
        payment.setUserId(requestDTO.getUserId());
        payment.setTournamentRegistrationId(
                requestDTO.getTournamentRegistrationId());

        payment.setCreatedAt(LocalDateTime.now());
        payment.setPaidDate(LocalDateTime.now());

        if (requestDTO.getPaymentStatus() != null) {
            payment.setPaymentStatus(requestDTO.getPaymentStatus());
        } else {
            payment.setPaymentStatus(TournamentPaymentStatus.SUCCESS);
        }

        TournamentRegistrationPayment saved =
                repository.save(payment);

        try {
    NotificationEventDTO notification =
            new NotificationEventDTO(
                    requestDTO.getUserId(),
                    "Tournament Payment Successful",
                    "Tournament payment completed for Registration ID : "
                            + requestDTO.getTournamentRegistrationId()
                            + " with amount : "
                            + requestDTO.getAmount());

    publisher.publishNotification(notification);

} catch (Exception e) {
    System.out.println(
            "Error Tournament Payment Notification : "
                    + e.getMessage());
}

        return mapToResponse(saved);
    }

    private TournamentRegistrationPaymentResponseDTO mapToResponse(
            TournamentRegistrationPayment payment) {

        TournamentRegistrationPaymentResponseDTO dto =
                new TournamentRegistrationPaymentResponseDTO();

        dto.setId(payment.getId());
        dto.setAmount(payment.getAmount());
        dto.setPaymentMethod(payment.getPaymentMethod());
        dto.setUserId(payment.getUserId());
        dto.setTournamentRegistrationId(
                payment.getTournamentRegistrationId());
        dto.setPaymentStatus(payment.getPaymentStatus());
        dto.setPaidDate(payment.getPaidDate());
        dto.setCreatedAt(payment.getCreatedAt());

        return dto;
    }

    @Override
    public TournamentPaymentStatus getTournamentPaymentStatus(
            String registrationId) {

        if (registrationId == null || registrationId.trim().isEmpty()) {
            throw new BadRequestException(
                    "Registration ID cannot be empty");
        }

        TournamentRegistrationPayment payment = repository
                .findByTournamentRegistrationId(registrationId)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Payment not found for registration ID: "
                                        + registrationId));

        return payment.getPaymentStatus();
    }

    @Override
    public List<TournamentRegistrationPayment> getPaymentHistory(
            String userId) {

        if (userId == null || userId.trim().isEmpty()) {
            throw new BadRequestException("User ID cannot be empty");
        }

        return repository.findByUserId(userId);
    }

    @Override
    public TournamentRegistrationPayment raiseCancellationRequest(
            String registrationId) {

        if (registrationId == null || registrationId.trim().isEmpty()) {
            throw new BadRequestException(
                    "Registration ID cannot be empty");
        }

        TournamentRegistrationPayment payment = repository
                .findByTournamentRegistrationId(registrationId)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Registration not found"));

        if (payment.getPaymentStatus()
                == TournamentPaymentStatus.PENDING_CANCELLATION) {
            throw new CustomException(
                    "Cancellation request already raised");
        }

        if (payment.getPaymentStatus()
                == TournamentPaymentStatus.CANCELLED) {
            throw new CustomException(
                    "Registration is already cancelled");
        }

        payment.setPaymentStatus(
                TournamentPaymentStatus.PENDING_CANCELLATION);

        try {
    NotificationEventDTO notification =
            new NotificationEventDTO(
                    payment.getUserId(),
                    "Tournament Cancellation Requested",
                    "Cancellation request has been raised for Tournament Registration ID : "
                            + payment.getTournamentRegistrationId());

    publisher.publishNotification(notification);

} catch (Exception e) {
    System.out.println(
            "Error Tournament Cancellation Request Notification : "
                    + e.getMessage());
}

        return repository.save(payment);
    }

    @Override
    public List<TournamentRegistrationPayment> getCancellationRequests() {

        return repository.findByPaymentStatus(
                TournamentPaymentStatus.PENDING_CANCELLATION);
    }

    @Override
    public TournamentRegistrationPayment approveCancellation(
            String registrationId) {

        if (registrationId == null || registrationId.trim().isEmpty()) {
            throw new BadRequestException(
                    "Registration ID cannot be empty");
        }

        TournamentRegistrationPayment payment = repository
                .findByTournamentRegistrationId(registrationId)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Registration not found"));

        if (payment.getPaymentStatus()
                != TournamentPaymentStatus.PENDING_CANCELLATION) {
            throw new CustomException(
                    "No pending cancellation request found");
        }

        payment.setPaymentStatus(
                TournamentPaymentStatus.CANCELLED);

        return repository.save(payment);
    }

    @Override
    public TournamentRegistrationPayment rejectCancellation(
            String registrationId) {

        if (registrationId == null || registrationId.trim().isEmpty()) {
            throw new BadRequestException(
                    "Registration ID cannot be empty");
        }

        TournamentRegistrationPayment payment = repository
                .findByTournamentRegistrationId(registrationId)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Registration not found"));

        if (payment.getPaymentStatus()
                != TournamentPaymentStatus.PENDING_CANCELLATION) {
            throw new CustomException(
                    "No pending cancellation request found");
        }

        payment.setPaymentStatus(
                TournamentPaymentStatus.CANCELLATION_REJECTED);

        return repository.save(payment);
    }

    @Override
    public TournamentPaymentStatus getCancellationStatus(
            String registrationId) {

        if (registrationId == null || registrationId.trim().isEmpty()) {
            throw new BadRequestException(
                    "Registration ID cannot be empty");
        }

        TournamentRegistrationPayment payment = repository
                .findByTournamentRegistrationId(registrationId)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Registration not found"));

        return payment.getPaymentStatus();
    }
}