package com.esports.project.service.interfaces;

import java.util.List;

import com.esports.project.DTO.CreateSubscriptionRequestDTO;
import com.esports.project.DTO.SubscriptionFilterDTO;
import com.esports.project.DTO.UserSubscriptionResponseDTO;
import com.esports.project.enums.SubscriptionType;

public interface UserSubscriptionService {

    UserSubscriptionResponseDTO createSubscription(
            CreateSubscriptionRequestDTO request);

    UserSubscriptionResponseDTO getSubscriptionById(
            String subscriptionId,
            String userId);

    List<UserSubscriptionResponseDTO> getSubscriptionsByUserId(
            String userId);

    List<UserSubscriptionResponseDTO> getAllSubscriptions();

    UserSubscriptionResponseDTO cancelSubscription(
            String subscriptionId);

    List<UserSubscriptionResponseDTO> getSubscriptionsByPlan(
            String planId);

    List<UserSubscriptionResponseDTO> getSubscriptionsByUserType(
            SubscriptionType userType);

    List<UserSubscriptionResponseDTO> getActiveSubscriptions();

    List<UserSubscriptionResponseDTO> getExpiredSubscriptions();

    List<UserSubscriptionResponseDTO> filterSubscriptions(
            SubscriptionFilterDTO filterDTO);

}
