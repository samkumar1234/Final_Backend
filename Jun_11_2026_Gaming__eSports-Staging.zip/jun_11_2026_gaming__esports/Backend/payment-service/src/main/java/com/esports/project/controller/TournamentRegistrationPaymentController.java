package com.esports.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.TournamentRegistrationPaymentRequestDTO;
import com.esports.project.DTO.TournamentRegistrationPaymentResponseDTO;
import com.esports.project.entity.TournamentRegistrationPayment;
import com.esports.project.enums.TournamentPaymentStatus;
import com.esports.project.service.interfaces.TournamentRegistrationPaymentServiceInterface;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/payment/tournament-registrations")
@RequiredArgsConstructor
public class TournamentRegistrationPaymentController {

    @Autowired
    private TournamentRegistrationPaymentServiceInterface service;

    /**
     * Register Tournament Payment
     * POST /api/tournament-registrations
     */
    @PostMapping
    @PreAuthorize("hasAuthority('TOURNAMENT_REGISTER')")
    public ResponseEntity<TournamentRegistrationPaymentResponseDTO> registerTournamentPayment(
            @RequestBody TournamentRegistrationPaymentRequestDTO requestDTO) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.registerTournamentPayment(requestDTO));
    }

    /**
     * Get Tournament Payment Status
     * GET /api/tournament-registrations/{registrationId}/status
     */
    @GetMapping("/{tournamentRegistrationId}/status")
    @PreAuthorize("hasAuthority('TOURNAMENT_PAYMENT_VIEW')")
    public ResponseEntity<TournamentPaymentStatus> getTournamentPaymentStatus(
            @PathVariable String tournamentRegistrationId) {

        return ResponseEntity.ok(
                service.getTournamentPaymentStatus(tournamentRegistrationId));
    }

    /**
     * Get Tournament Payment History
     * GET /api/tournament-registrations/history?userId=123
     */
    @GetMapping("/history")
    @PreAuthorize("hasAuthority('TOURNAMENT_PAYMENT_HISTORY_VIEW')")
    public ResponseEntity<List<TournamentRegistrationPayment>> getPaymentHistory(
            @RequestParam String userId) {

        return ResponseEntity.ok(
                service.getPaymentHistory(userId));
    }

    /**
     * User raises cancellation request
     */
    @PostMapping("/{registrationId}/cancellation-request")
    @PreAuthorize("hasAuthority('TOURNAMENT_CANCELLATION_REQUEST')")
    public ResponseEntity<TournamentRegistrationPayment> raiseCancellationRequest(
            @PathVariable String registrationId) {

        return ResponseEntity.ok(
                service.raiseCancellationRequest(registrationId));
    }

    /**
     * Admin/Manager views all cancellation requests
     */
    @GetMapping("/cancellation-requests")
    @PreAuthorize("hasAuthority('TOURNAMENT_CANCELLATION_VIEW')")
    public ResponseEntity<List<TournamentRegistrationPayment>> getCancellationRequests() {

        return ResponseEntity.ok(
                service.getCancellationRequests());
    }

    /**
     * Admin approves cancellation
     */
    @PatchMapping("/{registrationId}/approve-cancellation")
    @PreAuthorize("hasAuthority('TOURNAMENT_CANCELLATION_APPROVE')")
    public ResponseEntity<TournamentRegistrationPayment> approveCancellation(
            @PathVariable String registrationId) {

        return ResponseEntity.ok(
                service.approveCancellation(registrationId));
    }

    /**
     * Admin rejects cancellation
     */
    @PatchMapping("/{registrationId}/reject-cancellation")
    @PreAuthorize("hasAuthority('TOURNAMENT_CANCELLATION_REJECT')")
    public ResponseEntity<TournamentRegistrationPayment> rejectCancellation(
            @PathVariable String registrationId) {

        return ResponseEntity.ok(
                service.rejectCancellation(registrationId));
    }

    /**
     * User views cancellation status
     */
    @GetMapping("/{registrationId}/cancellation-status")
    @PreAuthorize("hasAuthority('TOURNAMENT_CANCELLATION_STATUS_VIEW')")
    public ResponseEntity<TournamentPaymentStatus> getCancellationStatus(
            @PathVariable String registrationId) {

        return ResponseEntity.ok(
                service.getCancellationStatus(registrationId));
    }
}