package com.esports.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.CreateSubscriptionPlanRequestDTO;
import com.esports.project.DTO.SubscriptionPlanResponseDTO;
import com.esports.project.DTO.UpdateSubscriptionPlanRequestDTO;
import com.esports.project.enums.SubscriptionType;
import com.esports.project.service.interfaces.SubscriptionPlanService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/payment/subscription-plans")
@RequiredArgsConstructor
public class SubscriptionPlanController {

    @Autowired
    private SubscriptionPlanService subscriptionPlanService;

    // ================= ADMIN =================

    @PostMapping
    @PreAuthorize("hasAuthority('SUBSCRIPTION_PLAN_CREATE')")
    public SubscriptionPlanResponseDTO createPlan(
            @Valid @RequestBody CreateSubscriptionPlanRequestDTO dto) {

        return subscriptionPlanService.createPlan(dto);
    }

    @PutMapping("/{planId}")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_PLAN_UPDATE')")
    public SubscriptionPlanResponseDTO updatePlan(
            @PathVariable String planId,
            @RequestBody UpdateSubscriptionPlanRequestDTO dto) {

        return subscriptionPlanService.updatePlan(planId, dto);
    }

    @DeleteMapping("/{planId}")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_PLAN_DELETE')")
    public ResponseEntity<Void> deletePlan(@PathVariable String planId) {

        subscriptionPlanService.deletePlan(planId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/all")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_PLAN_VIEW_ALL')")
    public List<SubscriptionPlanResponseDTO> getAllPlans() {

        return subscriptionPlanService.getAllPlans();
    }

    // ================= BRAND =================

    @GetMapping("/brand")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_PLAN_VIEW_BRAND')")
    public List<SubscriptionPlanResponseDTO> getBrandPlans() {

        return subscriptionPlanService
                .getPlansByUserType(SubscriptionType.BRAND);
    }


    @GetMapping("/influencer")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_PLAN_VIEW_INFLUENCER')")
    public List<SubscriptionPlanResponseDTO> getInfluencerPlans() {

        return subscriptionPlanService
                .getPlansByUserType(SubscriptionType.INFLUENCER);
    }
    
    @GetMapping("/organizer")
    // @PreAuthorize("hasAuthority('SUBSCRIPTION_PLAN_VIEW_ORGANIZER')")
    public List<SubscriptionPlanResponseDTO> getOrganizerPlans() {
        return subscriptionPlanService
                .getPlansByUserType(SubscriptionType.ORGANIZER);
    }
}