package com.esports.project.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.project.entity.TournamentRegistrationPayment;
import com.esports.project.enums.TournamentPaymentStatus;

public interface TournamentRegistrationPaymentRepository
        extends JpaRepository<TournamentRegistrationPayment, String> {

    List<TournamentRegistrationPayment> findByUserId(String userId);

    Optional<TournamentRegistrationPayment> findByTournamentRegistrationId(
            String tournamentRegistrationId);
    
    List<TournamentRegistrationPayment> findByPaymentStatus(TournamentPaymentStatus paymentStatus);
}