package com.esports.project.DTO;


import java.math.BigDecimal;

import com.esports.project.enums.SubscriptionType;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class SubscriptionPlanResponseDTO {

    private String id;
    private String name;
    private SubscriptionType userType;
    private BigDecimal price;
    private Integer durationDays;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public SubscriptionType getUserType() {
		return userType;
	}
	public void setUserType(SubscriptionType userType) {
		this.userType = userType;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public Integer getDurationDays() {
		return durationDays;
	}
	public void setDurationDays(Integer durationDays) {
		this.durationDays = durationDays;
	}
    
    
}
