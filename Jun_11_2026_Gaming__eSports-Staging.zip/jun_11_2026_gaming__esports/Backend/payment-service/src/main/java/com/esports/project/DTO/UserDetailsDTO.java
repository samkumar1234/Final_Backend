package com.esports.project.DTO;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class UserDetailsDTO {
    private String userId;
    private String username;
    private List<String> roles = new ArrayList<>();
    private List<String> permissions = new ArrayList<>();

    public UserDetailsDTO(String userId,String username, List<String> roles, List<String> permissions) {
        this.userId = userId;
        this.roles = roles;
        this.username = username;
        this.permissions = permissions;
    }

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<String> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<String> permissions) {
		this.permissions = permissions;
	}
    
    
    
}
