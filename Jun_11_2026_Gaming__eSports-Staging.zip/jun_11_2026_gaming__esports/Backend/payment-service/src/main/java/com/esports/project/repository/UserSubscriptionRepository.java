package com.esports.project.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.UserSubscription;
import com.esports.project.enums.SubscriptionStatus;
import com.esports.project.enums.SubscriptionType;

@Repository
public interface UserSubscriptionRepository extends JpaRepository<UserSubscription, String> {

    /**
     * Get all subscriptions of a user
     */
    List<UserSubscription> findByUserId(String userId);

    /**
     * Get subscriptions by plan
     */
    List<UserSubscription> findBySubscriptionPlan_Id(String planId);

    /**
     * Get subscriptions by user type (BRAND / INFLUENCER)
     */
    List<UserSubscription> findBySubscriptionPlan_UserType(  SubscriptionType userType);

    /**
     * Get subscriptions by status
     */
    List<UserSubscription> findByStatus(SubscriptionStatus status);

    /**
     * Get subscriptions that expired before now
     */
    List<UserSubscription> findByEndDateBefore( LocalDateTime dateTime);

    /**
     * Get active subscriptions
     */
    List<UserSubscription> findByEndDateAfter(LocalDateTime dateTime);

    /**
     * Check if user already has an active subscription
     */
    Optional<UserSubscription> findFirstByUserIdAndStatus(String userId,SubscriptionStatus status);

    /**
     * Get subscriptions of a user by status
     */
    List<UserSubscription> findByUserIdAndStatus(String userId, SubscriptionStatus status);
}
