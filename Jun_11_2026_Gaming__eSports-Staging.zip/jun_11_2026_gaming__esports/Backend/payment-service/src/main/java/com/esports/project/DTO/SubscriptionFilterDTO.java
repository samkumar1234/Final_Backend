package com.esports.project.DTO;
import com.esports.project.enums.SubscriptionStatus;
import com.esports.project.enums.SubscriptionType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubscriptionFilterDTO {

    private String planId;

    private SubscriptionType userType;

    /**
     * true  -> expired subscriptions
     * false -> active subscriptions
     * null  -> ignore filter
     */
    private Boolean expired;

    /**
     * ACTIVE / CANCELLED / EXPIRED
     */
    private SubscriptionStatus status;

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public SubscriptionType getUserType() {
		return userType;
	}

	public void setUserType(SubscriptionType userType) {
		this.userType = userType;
	}

	public Boolean getExpired() {
		return expired;
	}

	public void setExpired(Boolean expired) {
		this.expired = expired;
	}

	public SubscriptionStatus getStatus() {
		return status;
	}

	public void setStatus(SubscriptionStatus status) {
		this.status = status;
	}
    
    
    
}