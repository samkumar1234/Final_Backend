package com.esports.project.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.CreateSubscriptionPlanRequestDTO;
import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.DTO.SubscriptionPlanResponseDTO;
import com.esports.project.DTO.UpdateSubscriptionPlanRequestDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.SubscriptionPlan;
import com.esports.project.enums.SubscriptionType;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.SubscriptionPlanRepository;
import com.esports.project.service.EventPublisher;
import com.esports.project.service.interfaces.SubscriptionPlanService;

import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class SubscriptionPlanServiceImpl implements SubscriptionPlanService {

    private final SubscriptionPlanRepository subscriptionPlanRepository;
    private final EventPublisher publisher;

    @Override
    public SubscriptionPlanResponseDTO createPlan(CreateSubscriptionPlanRequestDTO request) {

        SubscriptionPlan plan = new SubscriptionPlan();

        plan.setName(request.getName());
        plan.setUserType(request.getUserType());
        plan.setPrice(request.getPrice());
        plan.setDurationDays(request.getDurationDays());
        plan.setCreatedAt(LocalDateTime.now());
        plan.setUpdatedAt(LocalDateTime.now());

        SubscriptionPlan savedPlan =
                subscriptionPlanRepository.save(plan);
            
        try {
            NotificationEventDTO notification = new NotificationEventDTO(getUserDetails().getUserId(), "New Subsciption Plan Created", "New Subsciption Plan Created fpr Plan : " + request.getName() + " With price : " + request.getPrice() + " for type : " + request.getUserType());
            publisher.publishNotification(notification);
            
        } catch (Exception e) {
            System.out.println("Error Subscription Plan : " + e.getMessage());
        }

        return mapToDTO(savedPlan);
    }

    @Override
    public SubscriptionPlanResponseDTO updatePlan(String planId,UpdateSubscriptionPlanRequestDTO request) {

        SubscriptionPlan plan =
                subscriptionPlanRepository.findById(planId)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Subscription Plan not found with id : "
                                + planId));

        if (request.getName() != null) {
            plan.setName(request.getName());
        }

        if (request.getUserType() != null) {
            plan.setUserType(request.getUserType());
        }

        if (request.getPrice() != null) {
            plan.setPrice(request.getPrice());
        }

        if (request.getDurationDays() != null) {
            plan.setDurationDays(request.getDurationDays());
        }

        plan.setUpdatedAt(LocalDateTime.now());

        SubscriptionPlan updatedPlan =
                subscriptionPlanRepository.save(plan);

        try {
            NotificationEventDTO notification = new NotificationEventDTO(getUserDetails().getUserId(), "Subsciption Plan updated", "Subsciption Plan Updated fpr Plan : " + plan.getName() + " With price : " + plan.getPrice() + " for type : " + plan.getUserType());
            publisher.publishNotification(notification);
            
        } catch (Exception e) {
            System.out.println("Error Subscription Plan : " + e.getMessage());
        }

        return mapToDTO(updatedPlan);
    }

    @Override
    public void deletePlan(String planId) {

        SubscriptionPlan plan =
                subscriptionPlanRepository.findById(planId)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Subscription Plan not found with id : "
                                + planId));

        subscriptionPlanRepository.delete(plan);
         try {
            NotificationEventDTO notification = new NotificationEventDTO(getUserDetails().getUserId(), "Subsciption Plan deleted", "Subsciption Plan deleted fpr Plan : " + plan.getName() + " With price : " + plan.getPrice() + " for type : " + plan.getUserType());
            publisher.publishNotification(notification);
            
        } catch (Exception e) {
            System.out.println("Error Subscription Plan : " + e.getMessage());
        }
    }

    @Override
    public List<SubscriptionPlanResponseDTO> getAllPlans() {

        List<SubscriptionPlan> plans =
                subscriptionPlanRepository.findAll();

        if (plans.isEmpty()) {
            throw new NotFoundException(
                    "No subscription plans available");
        }

        return plans.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<SubscriptionPlanResponseDTO> getPlansByUserType(
            SubscriptionType userType) {

        List<SubscriptionPlan> plans =
                subscriptionPlanRepository.findByUserType(userType);

        if (plans.isEmpty()) {
            throw new NotFoundException(
                    "No subscription plans found for user type : "
                    + userType);
        }

        return plans.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    private SubscriptionPlanResponseDTO mapToDTO(
            SubscriptionPlan plan) {

        SubscriptionPlanResponseDTO dto =
                new SubscriptionPlanResponseDTO();

        dto.setId(plan.getId());
        dto.setName(plan.getName());
        dto.setUserType(plan.getUserType());
        dto.setPrice(plan.getPrice());
        dto.setDurationDays(plan.getDurationDays());

        return dto;
    }

    private UserDetailsDTO getUserDetails(){
        return  (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }
}