package com.esports.project.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum SubscriptionType {
    INFLUENCER,
    ORGANIZER,
    BRAND;

	    @JsonCreator
	    public static SubscriptionType fromValue(String value) {

	        for (SubscriptionType type : SubscriptionType.values()) {
	            if (type.name().equalsIgnoreCase(value)) {
	                return type;
	            }
	        }

	        throw new IllegalArgumentException(
	                "Invalid subscription type: " + value);
	    }
}

