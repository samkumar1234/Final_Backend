package com.esports.project.enums;

public enum SubscriptionStatus {
	ACTIVE,
	CANCELLED,
	EXPIRED
}
