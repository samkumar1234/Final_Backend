package com.esports.project.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.PaymentMethod;
import com.esports.project.enums.TournamentPaymentStatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRegistrationPaymentResponseDTO {

    private String id;

    private BigDecimal amount;

    private PaymentMethod paymentMethod;

    private String userId;

    private String tournamentRegistrationId;
    
    
    private TournamentPaymentStatus paymentStatus;

    private LocalDateTime paidDate;

    private LocalDateTime createdAt;

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTournamentRegistrationId() {
		return tournamentRegistrationId;
	}

	public void setTournamentRegistrationId(String tournamentRegistrationId) {
		this.tournamentRegistrationId = tournamentRegistrationId;
	}

	public TournamentPaymentStatus getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(TournamentPaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public LocalDateTime getPaidDate() {
		return paidDate;
	}

	public void setPaidDate(LocalDateTime paidDate) {
		this.paidDate = paidDate;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	
    
    
}