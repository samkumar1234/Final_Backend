package com.esports.project.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum StatusType {
    TOURNAMENT,
    VERIFICATION;
	
	

    @JsonCreator
    public static StatusType fromValue(String value) {

        for (StatusType type : StatusType.values()) {
            if (type.name().equalsIgnoreCase(value)) {
                return type;
            }
        }

        throw new IllegalArgumentException(
                "Invalid subscription type: " + value);
    }
    
   
}
