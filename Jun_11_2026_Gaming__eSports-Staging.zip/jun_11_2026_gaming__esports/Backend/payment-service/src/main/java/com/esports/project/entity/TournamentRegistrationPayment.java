package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.PaymentMethod;
import com.esports.project.enums.TournamentPaymentStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tournament_registration_payments")
public class TournamentRegistrationPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    private PaymentMethod paymentMethod;

     public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTournamentRegistrationId() {
		return tournamentRegistrationId;
	}
	public void setTournamentRegistrationId(String tournamentRegistrationId) {
		this.tournamentRegistrationId = tournamentRegistrationId;
	}
	public TournamentPaymentStatus getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(TournamentPaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public LocalDateTime getPaidDate() {
		return paidDate;
	}
	public void setPaidDate(LocalDateTime paidDate) {
		this.paidDate = paidDate;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	@Column(nullable=false)
    private String userId;

    @Column(nullable=false)
    private String tournamentRegistrationId;

    @Enumerated(EnumType.STRING)
    private TournamentPaymentStatus paymentStatus;
    private LocalDateTime paidDate;
    private LocalDateTime createdAt;

    /*
     * relationship mapping
     */


    // registraion mapping

    
}
