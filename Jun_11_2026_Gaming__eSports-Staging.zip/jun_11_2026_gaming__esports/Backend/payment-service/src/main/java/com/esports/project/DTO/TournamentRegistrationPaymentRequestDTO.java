package com.esports.project.DTO;

import java.math.BigDecimal;

import com.esports.project.enums.PaymentMethod;
import com.esports.project.enums.TournamentPaymentStatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRegistrationPaymentRequestDTO {

    private BigDecimal amount;

    private PaymentMethod paymentMethod;

    private String userId;

    private String tournamentRegistrationId;

    private TournamentPaymentStatus paymentStatus;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTournamentRegistrationId() {
        return tournamentRegistrationId;
    }

    public void setTournamentRegistrationId(String tournamentRegistrationId) {
        this.tournamentRegistrationId = tournamentRegistrationId;
    }

    public TournamentPaymentStatus getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(TournamentPaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
}