package com.esports.project.service;


import org.springframework.stereotype.Service;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.websocket.PublisherBrokerClient;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EventPublisher {

	
    private final PublisherBrokerClient brokerClient;

    public void publishNotification(
            NotificationEventDTO notification)
            throws Exception {

        BrokerMessage message =
                new BrokerMessage();

        message.setType("PUBLISH");

        message.setTopic(
                "payment.notification");

        message.setPayload(notification);
        brokerClient.publish(message);
    }

}