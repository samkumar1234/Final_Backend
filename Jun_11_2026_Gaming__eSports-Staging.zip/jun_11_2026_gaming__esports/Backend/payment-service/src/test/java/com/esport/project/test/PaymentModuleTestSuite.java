// package com.esport.project.test;

// import org.junit.platform.suite.api.SelectClasses;
// import org.junit.platform.suite.api.Suite;

// @Suite
// @SelectClasses({
//         SubscriptionPlanServiceImplTest.class,
//         UserSubscriptionServiceImplTest.class,
//         TournamentRegistrationPaymentServiceImplTest.class
// })
// public class PaymentModuleTestSuite {
// }