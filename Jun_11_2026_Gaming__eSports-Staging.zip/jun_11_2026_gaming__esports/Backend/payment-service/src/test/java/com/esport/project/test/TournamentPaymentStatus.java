package com.esport.project.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.esports.project.enums.TournamentPaymentStatus;

class TournamentPaymentStatusTest {

    @Test
    void shouldContainSuccess() {

        assertEquals(
                TournamentPaymentStatus.SUCCESS,
                TournamentPaymentStatus.valueOf("SUCCESS"));
    }

    @Test
    void shouldContainCancelled() {

        assertEquals(
                TournamentPaymentStatus.CANCELLED,
                TournamentPaymentStatus.valueOf("CANCELLED"));
    }

    @Test
    void shouldContainPendingCancellation() {

        assertEquals(
                TournamentPaymentStatus.PENDING_CANCELLATION,
                TournamentPaymentStatus.valueOf(
                        "PENDING_CANCELLATION"));
    }

    @Test
    void shouldContainRejectedStatus() {

        assertEquals(
                TournamentPaymentStatus.CANCELLATION_REJECTED,
                TournamentPaymentStatus.valueOf(
                        "CANCELLATION_REJECTED"));
    }
}