// package com.esport.project.test;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;

// import java.math.BigDecimal;
// import java.time.LocalDateTime;
// import java.util.Arrays;
// import java.util.Collections;
// import java.util.Optional;

// import com.esports.project.DTO.CreateSubscriptionRequestDTO;
// import com.esports.project.DTO.SubscriptionFilterDTO;
// import com.esports.project.DTO.UserSubscriptionResponseDTO;
// import com.esports.project.entity.SubscriptionPlan;
// import com.esports.project.entity.UserSubscription;
// import com.esports.project.enums.SubscriptionStatus;
// import com.esports.project.enums.SubscriptionType;
// import com.esports.project.exception.BadRequestException;
// import com.esports.project.exception.NotFoundException;
// import com.esports.project.exception.UnauthorizedException;
// import com.esports.project.repository.SubscriptionPlanRepository;
// import com.esports.project.repository.UserSubscriptionRepository;
// import com.esports.project.service.impl.UserSubscriptionServiceImpl;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// @ExtendWith(MockitoExtension.class)
// class UserSubscriptionServiceImplTest {

//     @Mock
//     private UserSubscriptionRepository subscriptionRepository;

//     @Mock
//     private SubscriptionPlanRepository planRepository;

//     @InjectMocks
//     private UserSubscriptionServiceImpl service;

//     private SubscriptionPlan plan;
//     private UserSubscription subscription;
//     private CreateSubscriptionRequestDTO request;

//     @BeforeEach
//     void setUp() {

//         plan = new SubscriptionPlan();
//         plan.setId("PLAN001");
//         plan.setName("Premium Plan");
//         plan.setUserType(SubscriptionType.BRAND);
//         plan.setDurationDays(30);

//         subscription = new UserSubscription();
//         subscription.setId("SUB001");
//         subscription.setUserId("USER001");
//         subscription.setSubscriptionPlan(plan);
//         subscription.setAmountPaid(BigDecimal.valueOf(999));
//         subscription.setStatus(SubscriptionStatus.ACTIVE);
//         subscription.setStartDate(LocalDateTime.now());
//         subscription.setEndDate(LocalDateTime.now().plusDays(30));
//         subscription.setCreatedAt(LocalDateTime.now());
//         subscription.setUpdatedAt(LocalDateTime.now());

//         request = new CreateSubscriptionRequestDTO();
//         request.setUserId("USER001");
//         request.setSubscriptionPlanId("PLAN001");
//         request.setAmountPaid(BigDecimal.valueOf(999));
//     }

//     // ==================================================
//     // CREATE SUBSCRIPTION
//     // ==================================================

//     @Test
//     void createSubscription_Positive() {

//         when(planRepository.findById("PLAN001"))
//                 .thenReturn(Optional.of(plan));

//         when(subscriptionRepository.save(any(UserSubscription.class)))
//                 .thenReturn(subscription);

//         UserSubscriptionResponseDTO response =
//                 service.createSubscription(request);

//         assertNotNull(response);

//         assertEquals("SUB001", response.getId());
//         assertEquals("USER001", response.getUserId());
//         assertEquals("PLAN001", response.getSubscriptionPlanId());
//         assertEquals("Premium Plan", response.getPlanName());

//         assertEquals(
//                 SubscriptionType.BRAND,
//                 response.getUserType());

//         assertEquals(
//                 BigDecimal.valueOf(999),
//                 response.getAmountPaid());

//         assertEquals(
//                 SubscriptionStatus.ACTIVE,
//                 response.getStatus());

//         verify(subscriptionRepository).save(any());
//     }

//     @Test
//     void createSubscription_Negative_PlanNotFound() {

//         when(planRepository.findById("PLAN001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 NotFoundException.class,
//                 () -> service.createSubscription(request));
//     }

//     @Test
//     void createSubscription_EdgeCase_ZeroAmount() {

//         request.setAmountPaid(BigDecimal.ZERO);

//         when(planRepository.findById("PLAN001"))
//                 .thenReturn(Optional.of(plan));

//         when(subscriptionRepository.save(any()))
//                 .thenReturn(subscription);

//         assertDoesNotThrow(
//                 () -> service.createSubscription(request));
//     }

//     // ==================================================
//     // GET SUBSCRIPTION BY ID
//     // ==================================================

//     @Test
//     void getSubscriptionById_Positive() {

//         when(subscriptionRepository.findById("SUB001"))
//                 .thenReturn(Optional.of(subscription));

//         UserSubscriptionResponseDTO response =
//                 service.getSubscriptionById(
//                         "SUB001",
//                         "USER001");

//         assertNotNull(response);
//     }

//     @Test
//     void getSubscriptionById_Negative_NotFound() {

//         when(subscriptionRepository.findById("SUB001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 NotFoundException.class,
//                 () -> service.getSubscriptionById(
//                         "SUB001",
//                         "USER001"));
//     }

//     @Test
//     void getSubscriptionById_EdgeCase_UnauthorizedAccess() {

//         when(subscriptionRepository.findById("SUB001"))
//                 .thenReturn(Optional.of(subscription));

//         assertThrows(
//                 UnauthorizedException.class,
//                 () -> service.getSubscriptionById(
//                         "SUB001",
//                         "USER999"));
//     }

//     // ==================================================
//     // GET SUBSCRIPTIONS BY USER
//     // ==================================================

//     @Test
//     void getSubscriptionsByUserId_Positive() {

//         when(subscriptionRepository.findByUserId("USER001"))
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.getSubscriptionsByUserId("USER001")
//                         .size());
//     }

//     @Test
//     void getSubscriptionsByUserId_EdgeCase_EmptyResult() {

//         when(subscriptionRepository.findByUserId("USER001"))
//                 .thenReturn(Collections.emptyList());

//         assertTrue(
//                 service.getSubscriptionsByUserId("USER001")
//                         .isEmpty());
//     }

//     // ==================================================
//     // GET ALL SUBSCRIPTIONS
//     // ==================================================

//     @Test
//     void getAllSubscriptions_Positive() {

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.getAllSubscriptions().size());
//     }

//     @Test
//     void getAllSubscriptions_EdgeCase_EmptyList() {

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Collections.emptyList());

//         assertTrue(
//                 service.getAllSubscriptions().isEmpty());
//     }

//     // ==================================================
//     // CANCEL SUBSCRIPTION
//     // ==================================================

//     @Test
//     void cancelSubscription_Positive() {

//         when(subscriptionRepository.findById("SUB001"))
//                 .thenReturn(Optional.of(subscription));

//         when(subscriptionRepository.save(any()))
//                 .thenReturn(subscription);

//         UserSubscriptionResponseDTO response =
//                 service.cancelSubscription("SUB001");

//         assertNotNull(response);

//         verify(subscriptionRepository)
//                 .save(any());
//     }

//     @Test
//     void cancelSubscription_Negative_NotFound() {

//         when(subscriptionRepository.findById("SUB001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 NotFoundException.class,
//                 () -> service.cancelSubscription("SUB001"));
//     }

//     @Test
//     void cancelSubscription_EdgeCase_AlreadyCancelled() {

//         subscription.setStatus(
//                 SubscriptionStatus.CANCELLED);

//         when(subscriptionRepository.findById("SUB001"))
//                 .thenReturn(Optional.of(subscription));

//         assertThrows(
//                 BadRequestException.class,
//                 () -> service.cancelSubscription("SUB001"));
//     }

//     // ==================================================
//     // GET SUBSCRIPTIONS BY PLAN
//     // ==================================================

//     @Test
//     void getSubscriptionsByPlan_Positive() {

//         when(subscriptionRepository.findBySubscriptionPlan_Id(
//                 "PLAN001"))
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.getSubscriptionsByPlan("PLAN001")
//                         .size());
//     }

//     @Test
//     void getSubscriptionsByPlan_EdgeCase_EmptyList() {

//         when(subscriptionRepository.findBySubscriptionPlan_Id(
//                 "PLAN001"))
//                 .thenReturn(Collections.emptyList());

//         assertTrue(
//                 service.getSubscriptionsByPlan("PLAN001")
//                         .isEmpty());
//     }

//     // ==================================================
//     // GET SUBSCRIPTIONS BY USER TYPE
//     // ==================================================

//     @Test
//     void getSubscriptionsByUserType_Positive() {

//         when(subscriptionRepository
//                 .findBySubscriptionPlan_UserType(
//                         SubscriptionType.BRAND))
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.getSubscriptionsByUserType(
//                         SubscriptionType.BRAND)
//                         .size());
//     }

//     @Test
//     void getSubscriptionsByUserType_EdgeCase_EmptyList() {

//         when(subscriptionRepository
//                 .findBySubscriptionPlan_UserType(
//                         SubscriptionType.BRAND))
//                 .thenReturn(Collections.emptyList());

//         assertTrue(
//                 service.getSubscriptionsByUserType(
//                         SubscriptionType.BRAND)
//                         .isEmpty());
//     }

//     // ==================================================
//     // ACTIVE SUBSCRIPTIONS
//     // ==================================================

//     @Test
//     void getActiveSubscriptions_Positive() {

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.getActiveSubscriptions().size());
//     }

//     @Test
//     void getActiveSubscriptions_EdgeCase_ExpiredSubscription() {

//         subscription.setEndDate(
//                 LocalDateTime.now().minusDays(1));

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertTrue(
//                 service.getActiveSubscriptions().isEmpty());
//     }

//     // ==================================================
//     // EXPIRED SUBSCRIPTIONS
//     // ==================================================

//     @Test
//     void getExpiredSubscriptions_Positive() {

//         subscription.setEndDate(
//                 LocalDateTime.now().minusDays(1));

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.getExpiredSubscriptions().size());
//     }

//     @Test
//     void getExpiredSubscriptions_EdgeCase_NoExpiredSubscriptions() {

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertTrue(
//                 service.getExpiredSubscriptions().isEmpty());
//     }

//     // ==================================================
//     // FILTER SUBSCRIPTIONS
//     // ==================================================

//     @Test
//     void filterSubscriptions_ByPlanId_Positive() {

//         SubscriptionFilterDTO filter =
//                 new SubscriptionFilterDTO();

//         filter.setPlanId("PLAN001");

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.filterSubscriptions(filter)
//                         .size());
//     }

//     @Test
//     void filterSubscriptions_ByUserType_Positive() {

//         SubscriptionFilterDTO filter =
//                 new SubscriptionFilterDTO();

//         filter.setUserType(
//                 SubscriptionType.BRAND);

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.filterSubscriptions(filter)
//                         .size());
//     }

//     @Test
//     void filterSubscriptions_ExpiredFilter_Positive() {

//         subscription.setEndDate(
//                 LocalDateTime.now().minusDays(1));

//         SubscriptionFilterDTO filter =
//                 new SubscriptionFilterDTO();

//         filter.setExpired(true);

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.filterSubscriptions(filter)
//                         .size());
//     }

//     @Test
//     void filterSubscriptions_EdgeCase_NoFiltersApplied() {

//         SubscriptionFilterDTO filter =
//                 new SubscriptionFilterDTO();

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertEquals(
//                 1,
//                 service.filterSubscriptions(filter)
//                         .size());
//     }

//     @Test
//     void filterSubscriptions_Negative_NoMatchFound() {

//         SubscriptionFilterDTO filter =
//                 new SubscriptionFilterDTO();

//         filter.setPlanId("INVALID");

//         when(subscriptionRepository.findAll())
//                 .thenReturn(Arrays.asList(subscription));

//         assertTrue(
//                 service.filterSubscriptions(filter)
//                         .isEmpty());
//     }
// }