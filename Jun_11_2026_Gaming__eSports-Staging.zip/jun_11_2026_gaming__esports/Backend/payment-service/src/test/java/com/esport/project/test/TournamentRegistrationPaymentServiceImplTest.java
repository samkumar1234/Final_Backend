package com.esport.project.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.TournamentRegistrationPaymentRequestDTO;
import com.esports.project.DTO.TournamentRegistrationPaymentResponseDTO;
import com.esports.project.entity.TournamentRegistrationPayment;
import com.esports.project.enums.PaymentMethod;
import com.esports.project.enums.TournamentPaymentStatus;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.CustomException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.TournamentRegistrationPaymentRepository;
import com.esports.project.service.impl.TournamentRegistrationPaymentServiceImpl;

@ExtendWith(MockitoExtension.class)
class TournamentRegistrationPaymentServiceImplTest {

    @Mock
    private TournamentRegistrationPaymentRepository repository;

    @InjectMocks
    private TournamentRegistrationPaymentServiceImpl service;

    private TournamentRegistrationPayment payment;
    private TournamentRegistrationPaymentRequestDTO request;

    @BeforeEach
    void setUp() {

        payment = new TournamentRegistrationPayment();

        payment.setId("PAY001");
        payment.setUserId("USER001");
        payment.setTournamentRegistrationId("TR001");
        payment.setAmount(BigDecimal.valueOf(500));
        payment.setPaymentMethod(PaymentMethod.GPAY);
        payment.setPaymentStatus(TournamentPaymentStatus.SUCCESS);

        request = new TournamentRegistrationPaymentRequestDTO();

        request.setUserId("USER001");
        request.setTournamentRegistrationId("TR001");
        request.setAmount(BigDecimal.valueOf(500));
        request.setPaymentMethod(PaymentMethod.GPAY);
    }

    // =====================================================
    // REGISTER TOURNAMENT PAYMENT
    // =====================================================
    
    @Test
    void registerTournamentPayment_DefaultSuccessStatus() {

        request.setPaymentStatus(null);

        when(repository.save(any(TournamentRegistrationPayment.class)))
                .thenReturn(payment);

        TournamentRegistrationPaymentResponseDTO response =
                service.registerTournamentPayment(request);

        assertNotNull(response);

        verify(repository).save(any());
    }
    @Test
    void registerTournamentPayment_NullUserId() {

        request.setUserId(null);

        BadRequestException exception =
                assertThrows(
                        BadRequestException.class,
                        () -> service.registerTournamentPayment(request));

        assertEquals(
                "User ID is required",
                exception.getMessage());
    }
    @Test
    void registerTournamentPayment_NullRegistrationId() {

        request.setTournamentRegistrationId(null);

        assertThrows(
                BadRequestException.class,
                () -> service.registerTournamentPayment(request));
    }
    
    @Test
    void registerTournamentPayment_NullAmount() {

        request.setAmount(null);

        assertThrows(
                BadRequestException.class,
                () -> service.registerTournamentPayment(request));
    }
    @Test
    void registerTournamentPayment_NegativeAmount() {

        request.setAmount(BigDecimal.valueOf(-100));

        assertThrows(
                BadRequestException.class,
                () -> service.registerTournamentPayment(request));
    }
    @Test
    void registerTournamentPayment_Positive() {

        when(repository.save(any(TournamentRegistrationPayment.class)))
                .thenReturn(payment);

        TournamentRegistrationPaymentResponseDTO response =
                service.registerTournamentPayment(request);

        assertNotNull(response);

        assertEquals("PAY001", response.getId());
        assertEquals("USER001", response.getUserId());
        assertEquals("TR001", response.getTournamentRegistrationId());

        assertEquals(
                BigDecimal.valueOf(500),
                response.getAmount());

        assertEquals(
                PaymentMethod.GPAY,
                response.getPaymentMethod());

        assertEquals(
                TournamentPaymentStatus.SUCCESS,
                response.getPaymentStatus());

        verify(repository)
                .save(any(TournamentRegistrationPayment.class));
    }

    @Test
    void registerTournamentPayment_Negative_NullRequest() {

        assertThrows(
                BadRequestException.class,
                () -> service.registerTournamentPayment(null));
    }

    @Test
    void registerTournamentPayment_Negative_EmptyUserId() {

        request.setUserId("");

        assertThrows(
                BadRequestException.class,
                () -> service.registerTournamentPayment(request));
    }

    @Test
    void registerTournamentPayment_Negative_EmptyRegistrationId() {

        request.setTournamentRegistrationId("");

        assertThrows(
                BadRequestException.class,
                () -> service.registerTournamentPayment(request));
    }

    @Test
    void registerTournamentPayment_Negative_InvalidAmount() {

        request.setAmount(BigDecimal.ZERO);

        assertThrows(
                BadRequestException.class,
                () -> service.registerTournamentPayment(request));
    }

    @Test
    void registerTournamentPayment_Negative_NullPaymentMethod() {

        request.setPaymentMethod(null);

        assertThrows(
                BadRequestException.class,
                () -> service.registerTournamentPayment(request));
    }

    @Test
    void registerTournamentPayment_EdgeCase_CustomStatus() {

        request.setPaymentStatus(
                TournamentPaymentStatus.PENDING);

        payment.setPaymentStatus(
                TournamentPaymentStatus.PENDING);

        when(repository.save(any(TournamentRegistrationPayment.class)))
                .thenReturn(payment);

        TournamentRegistrationPaymentResponseDTO response =
                service.registerTournamentPayment(request);

        assertEquals(
                TournamentPaymentStatus.PENDING,
                response.getPaymentStatus());
    }

    // =====================================================
    // GET PAYMENT STATUS
    // =====================================================
    @Test
    void getTournamentPaymentStatus_NullId() {

        assertThrows(
                BadRequestException.class,
                () -> service.getTournamentPaymentStatus(null));
    }
    
    @Test
    void getTournamentPaymentStatus_Positive() {

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        TournamentPaymentStatus status =
                service.getTournamentPaymentStatus("TR001");

        assertEquals(
                TournamentPaymentStatus.SUCCESS,
                status);
    }

    @Test
    void getTournamentPaymentStatus_Negative_NotFound() {

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getTournamentPaymentStatus("TR001"));
    }

    @Test
    void getTournamentPaymentStatus_EdgeCase_EmptyId() {

        assertThrows(
                BadRequestException.class,
                () -> service.getTournamentPaymentStatus(""));
    }

    // =====================================================
    // GET PAYMENT HISTORY
    // =====================================================
    @Test
    void getPaymentHistory_NullUserId() {

        assertThrows(
                BadRequestException.class,
                () -> service.getPaymentHistory(null));
    }
    
    @Test
    void getPaymentHistory_Positive() {

        when(repository.findByUserId("USER001"))
                .thenReturn(Arrays.asList(payment));

        assertEquals(
                1,
                service.getPaymentHistory("USER001").size());
    }

    @Test
    void getPaymentHistory_Negative_EmptyUserId() {

        assertThrows(
                BadRequestException.class,
                () -> service.getPaymentHistory(""));
    }

    @Test
    void getPaymentHistory_EdgeCase_NoPayments() {

        when(repository.findByUserId("USER001"))
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getPaymentHistory("USER001")
                        .isEmpty());
    }

    // =====================================================
    // RAISE CANCELLATION REQUEST
    // =====================================================

    @Test
    void raiseCancellationRequest_NullRegistrationId() {

        assertThrows(
                BadRequestException.class,
                () -> service.raiseCancellationRequest(null));
    }
    @Test
    void raiseCancellationRequest_EmptyRegistrationId() {

        assertThrows(
                BadRequestException.class,
                () -> service.raiseCancellationRequest(""));
    }
    
    @Test
    void raiseCancellationRequest_Positive() {

        payment.setPaymentStatus(
                TournamentPaymentStatus.SUCCESS);

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        when(repository.save(any()))
                .thenReturn(payment);

        TournamentRegistrationPayment result =
                service.raiseCancellationRequest("TR001");

        assertNotNull(result);

        verify(repository).save(any());
    }

    @Test
    void raiseCancellationRequest_Negative_NotFound() {

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.raiseCancellationRequest("TR001"));
    }

    @Test
    void raiseCancellationRequest_EdgeCase_AlreadyRaised() {

        payment.setPaymentStatus(
                TournamentPaymentStatus.PENDING_CANCELLATION);

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        assertThrows(
                CustomException.class,
                () -> service.raiseCancellationRequest("TR001"));
    }

    @Test
    void raiseCancellationRequest_EdgeCase_AlreadyCancelled() {

        payment.setPaymentStatus(
                TournamentPaymentStatus.CANCELLED);

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        assertThrows(
                CustomException.class,
                () -> service.raiseCancellationRequest("TR001"));
    }

    // =====================================================
    // GET CANCELLATION REQUESTS
    // =====================================================

    @Test
    void getCancellationRequests_Positive() {

        when(repository.findByPaymentStatus(
                TournamentPaymentStatus.PENDING_CANCELLATION))
                .thenReturn(Arrays.asList(payment));

        assertEquals(
                1,
                service.getCancellationRequests().size());
    }

    @Test
    void getCancellationRequests_EdgeCase_EmptyList() {

        when(repository.findByPaymentStatus(
                TournamentPaymentStatus.PENDING_CANCELLATION))
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getCancellationRequests().isEmpty());
    }

    // =====================================================
    // APPROVE CANCELLATION
    // =====================================================

    @Test
    void approveCancellation_NullRegistrationId() {

        assertThrows(
                BadRequestException.class,
                () -> service.approveCancellation(null));
    }
    @Test
    void approveCancellation_EmptyRegistrationId() {

        assertThrows(
                BadRequestException.class,
                () -> service.approveCancellation(""));
    }
    @Test
    void approveCancellation_Positive() {

        payment.setPaymentStatus(
                TournamentPaymentStatus.PENDING_CANCELLATION);

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        when(repository.save(any()))
                .thenReturn(payment);

        TournamentRegistrationPayment result =
                service.approveCancellation("TR001");

        assertNotNull(result);

        verify(repository).save(any());
    }

    @Test
    void approveCancellation_Negative_NotFound() {

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.approveCancellation("TR001"));
    }

    @Test
    void approveCancellation_EdgeCase_NoPendingRequest() {

        payment.setPaymentStatus(
                TournamentPaymentStatus.SUCCESS);

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        assertThrows(
                CustomException.class,
                () -> service.approveCancellation("TR001"));
    }

    // =====================================================
    // REJECT CANCELLATION
    // =====================================================
    
    @Test
    void rejectCancellation_NullRegistrationId() {

        assertThrows(
                BadRequestException.class,
                () -> service.rejectCancellation(null));
    }
    @Test
    void rejectCancellation_EmptyRegistrationId() {

        assertThrows(
                BadRequestException.class,
                () -> service.rejectCancellation(""));
    }
    @Test
    void rejectCancellation_Positive() {

        payment.setPaymentStatus(
                TournamentPaymentStatus.PENDING_CANCELLATION);

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        when(repository.save(any()))
                .thenReturn(payment);

        TournamentRegistrationPayment result =
                service.rejectCancellation("TR001");

        assertNotNull(result);

        verify(repository).save(any());
    }

    @Test
    void rejectCancellation_Negative_NotFound() {

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.rejectCancellation("TR001"));
    }

    @Test
    void rejectCancellation_EdgeCase_NoPendingRequest() {

        payment.setPaymentStatus(
                TournamentPaymentStatus.SUCCESS);

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        assertThrows(
                CustomException.class,
                () -> service.rejectCancellation("TR001"));
    }

    // =====================================================
    // GET CANCELLATION STATUS
    // =====================================================
    @Test
    void getCancellationStatus_NullRegistrationId() {

        assertThrows(
                BadRequestException.class,
                () -> service.getCancellationStatus(null));
    }
    
    @Test
    void getCancellationStatus_Positive() {

        payment.setPaymentStatus(
                TournamentPaymentStatus.PENDING_CANCELLATION);

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.of(payment));

        TournamentPaymentStatus status =
                service.getCancellationStatus("TR001");

        assertEquals(
                TournamentPaymentStatus.PENDING_CANCELLATION,
                status);
    }

    @Test
    void getCancellationStatus_Negative_NotFound() {

        when(repository.findByTournamentRegistrationId("TR001"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getCancellationStatus("TR001"));
    }

    @Test
    void getCancellationStatus_EdgeCase_EmptyRegistrationId() {

        assertThrows(
                BadRequestException.class,
                () -> service.getCancellationStatus(""));
    }
}