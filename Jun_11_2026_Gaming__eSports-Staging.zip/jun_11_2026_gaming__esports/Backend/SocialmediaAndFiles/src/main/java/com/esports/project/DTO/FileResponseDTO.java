package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.enums.FileType;
import com.esports.project.enums.OwnerType;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class FileResponseDTO {

    private String id;

    private String originalFileName;

    private FileType fileType;

    private OwnerType ownerType;

    private String ownerId;

    private String mimeType;

    private Long fileSize;

    private String uploadedByUserId;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private String downloadUrl;
}