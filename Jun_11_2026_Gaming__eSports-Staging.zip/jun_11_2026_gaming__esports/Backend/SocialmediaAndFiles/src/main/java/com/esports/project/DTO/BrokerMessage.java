package com.esports.project.DTO;


import lombok.Data;

@Data
public class BrokerMessage {
    private Long offset;
    private String type;
    private String topic;
    private Object payload;
}