package com.esports.project.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.esports.project.entity.SocialMediaAccount;

@Repository
public interface SocialMediaAccountRepository
        extends JpaRepository<SocialMediaAccount, String> {

    List<SocialMediaAccount> findByUserId(String userId);

    List<SocialMediaAccount> findByStatus(String status);

    List<SocialMediaAccount> findByAccountNameContainingIgnoreCase(String accountName);

    List<SocialMediaAccount> findByPlatformIgnoreCase(String platform);

    List<SocialMediaAccount> findByStatusIgnoreCase(String status);

    Page<SocialMediaAccount> findByUserId(
            String userId,
            Pageable pageable);

    Page<SocialMediaAccount> findByPlatformIgnoreCase(
            String platform,
            Pageable pageable);

    Page<SocialMediaAccount> findByStatusIgnoreCase(
            String status,
            Pageable pageable);
    Page<SocialMediaAccount>
findByPlatformIgnoreCaseOrderByGenuineInfluencerScoreDesc(
        String platform,
        Pageable pageable);  
}