package com.esports.project.enums;

public enum FileType {
    PROFILE_PICTURE,
    VERIFICATION_DOCUMENT,
    BANNER,
    LOGO,
    PRODUCT_IMAGE,
    DELIVERABLE,
    RULEBOOK,
    DOCUMENT,
    VIDEO,
    ATTACHMENT
}
