package com.esports.project.DTO;

//import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SocialMediaAccountDTO {

    private String platform;

    private String accountName;

    private String profileUrl;

    private Long followersCount;

    private Long subscriberCount;

    private Long totalViews;

    private Long totalLikes;

    private Long totalComments;

   //private BigDecimal viewSubscriptionRatio;

//private BigDecimal viewCommentRatio;

    private String status;

    private String userId;
}