package com.esports.project.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.esports.project.DTO.BecomeInfluencerDTO;
import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.SocialMediaAccountDTO;
import com.esports.project.entity.SocialMediaAccount;
import com.esports.project.service.SocialMediaAccountService;

@RestController
@RequestMapping("/media/social-media")
public class SocialMediaAccountController {

        private final SocialMediaAccountService service;

        public SocialMediaAccountController(
                        SocialMediaAccountService service) {

                this.service = service;
        }

        @PostMapping("/accounts")
        // @PreAuthorize("hasAuthority('INFLUENCER_WRITE')")
        public ResponseEntity<SocialMediaAccount> createAccount(
                        @RequestBody SocialMediaAccountDTO dto) {

                return ResponseEntity.ok(
                                service.createAccount(dto));
        }

        @GetMapping
        // @PreAuthorize("hasAuthority('INFLUENCER_READ')")
        public ResponseEntity<Page<SocialMediaAccount>> getAllAccounts(
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "accountName") String sortBy,
                        @RequestParam(defaultValue = "asc") String sortDir) {

                return ResponseEntity.ok(
                                service.getAllAccounts(
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/{id}")
        // @PreAuthorize("hasAuthority('INFLUENCER_READ')")
        public ResponseEntity<SocialMediaAccount> getAccountById(
                        @PathVariable String id) {

                return ResponseEntity.ok(
                                service.getAccountById(id));
        }

        @GetMapping("/user/{userId}")
        // @PreAuthorize("hasAuthority('INFLUENCER_READ')")
        public ResponseEntity<Page<SocialMediaAccount>> getByUserId(
                        @PathVariable String userId,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "accountName") String sortBy,
                        @RequestParam(defaultValue = "asc") String sortDir) {

                return ResponseEntity.ok(
                                service.getAccountsByUserId(
                                                userId,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/search/{accountName}")
        // @PreAuthorize("hasAuthority('INFLUENCER_READ')")
        public ResponseEntity<List<SocialMediaAccount>> searchByAccountName(
                        @PathVariable String accountName) {

                return ResponseEntity.ok(
                                service.searchByAccountName(accountName));
        }

        @DeleteMapping("/{id}")
        // @PreAuthorize("hasAuthority('INFLUENCER_DELETE')")
        public ResponseEntity<String> deleteAccount(
                        @PathVariable String id) {

                service.deleteAccount(id);

                return ResponseEntity.ok(
                                "Social Media Account deleted successfully");
        }

        @GetMapping("/platform/{platform}")
        // @PreAuthorize("hasAuthority('INFLUENCER_READ')")
        public ResponseEntity<Page<SocialMediaAccount>> getByPlatform(
                        @PathVariable String platform,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "accountName") String sortBy,
                        @RequestParam(defaultValue = "asc") String sortDir) {

                return ResponseEntity.ok(
                                service.getAccountsByPlatform(
                                                platform,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/status/{status}")
        // @PreAuthorize("hasAuthority('INFLUENCER_READ')")
        public ResponseEntity<Page<SocialMediaAccount>> getByStatus(
                        @PathVariable String status,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "accountName") String sortBy,
                        @RequestParam(defaultValue = "asc") String sortDir) {

                return ResponseEntity.ok(
                                service.getAccountsByStatus(
                                                status,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @PutMapping("/{id}")
        // @PreAuthorize("hasAuthority('INFLUENCER_WRITE')")
        public ResponseEntity<SocialMediaAccount> updateAccount(
                        @PathVariable String id,
                        @RequestBody SocialMediaAccountDTO dto) {

                return ResponseEntity.ok(
                                service.updateAccount(id, dto));
        }

        @PatchMapping("/{id}")
        // @PreAuthorize("hasAuthority('INFLUENCER_WRITE')")
        public ResponseEntity<SocialMediaAccount> patchAccount(
                        @PathVariable String id,
                        @RequestBody SocialMediaAccountDTO dto) {

                return ResponseEntity.ok(
                                service.patchAccount(id, dto));
        }

        @GetMapping("/top-influencers/{platform}")
        // @PreAuthorize("hasAuthority('INFLUENCER_READ')")
        public ResponseEntity<Page<SocialMediaAccount>> getTopInfluencersByPlatform(
                        @PathVariable String platform,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size) {

                return ResponseEntity.ok(
                                service.getTopInfluencersByPlatform(
                                                platform,
                                                page,
                                                size));
        }

        @PostMapping("/influencer")
        // @PreAuthorize("hasAuthority('INFLUENCER_WRITE')")
        public ResponseEntity<ResponseDTO> becomeInfluencer(@RequestBody BecomeInfluencerDTO becomeInfluencerDTO){
                return ResponseEntity.status(HttpStatus.OK).body(service.becomeInfluencer(becomeInfluencerDTO));
        }

}