package com.esports.project.DTO;

import com.esports.project.enums.FileType;
import com.esports.project.enums.OwnerType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FilePatchDTO {

    private FileType fileType;

    private OwnerType ownerType;

    private String ownerId;
}