package com.esports.project.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.BecomeInfluencerDTO;
import com.esports.project.DTO.InfluencerProfilePublishEvent;
import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.SocialMediaAccountDTO;
import com.esports.project.DTO.SocialMediaValidationResultEvent;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.Repository.SocialMediaAccountRepository;
import com.esports.project.entity.SocialMediaAccount;
import com.esports.project.exception.CustomException;
import com.esports.project.exception.NotFoundException;

import jakarta.transaction.Transactional;

@Service
public class SocialMediaAccountService {

        private final SocialMediaAccountRepository repository;
        private final SocialMediaEventPublisher publisher;

        public SocialMediaAccountService(
                        SocialMediaAccountRepository repository, SocialMediaEventPublisher publisher) {
                this.repository = repository;
                this.publisher = publisher;
        }

        public SocialMediaAccount createAccount(SocialMediaAccountDTO dto) {
                SocialMediaAccount account = new SocialMediaAccount();

                UserDetailsDTO userDetailsDTO = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication()
                                .getPrincipal();

                account.setPlatform(dto.getPlatform());
                account.setAccountName(dto.getAccountName());
                account.setProfileUrl(dto.getProfileUrl());
                account.setFollowersCount(dto.getFollowersCount());
                account.setSubscriberCount(dto.getSubscriberCount());
                account.setStatus(dto.getStatus());
                account.setUserId(userDetailsDTO.getUserId());

                account.setCreatedAt(LocalDateTime.now());
                account.setUpdatedAt(LocalDateTime.now());
                BigDecimal engagementRate = calculateEngagementRate(
                                dto.getTotalLikes(),
                                dto.getTotalComments(),
                                dto.getTotalViews());

                BigDecimal commentRatio = calculateCommentRatio(
                                dto.getTotalComments(),
                                dto.getTotalViews());

                BigDecimal viewSubscriberRatio = calculateViewSubscriberRatio(
                                dto.getTotalViews(),
                                dto.getSubscriberCount());

                BigDecimal influencerScore = calculateGenuineInfluencerScore(
                                engagementRate,
                                commentRatio,
                                viewSubscriberRatio);

                String influencerRating = getInfluencerRating(influencerScore);
                account.setTotalViews(dto.getTotalViews());
                account.setTotalLikes(dto.getTotalLikes());
                account.setTotalComments(dto.getTotalComments());

                BigDecimal viewSubscriptionRatio = calculateViewSubscriptionRatio(
                                dto.getTotalViews(),
                                dto.getSubscriberCount());

                BigDecimal viewCommentRatio = calculateViewCommentRatio(
                                dto.getTotalComments(),
                                dto.getTotalViews());

                account.setViewSubscriptionRatio(
                                viewSubscriptionRatio);

                account.setViewCommentRatio(
                                viewCommentRatio);

                account.setEngagementRate(
                                engagementRate);

                account.setGenuineInfluencerScore(
                                influencerScore);

                account.setInfluencerRating(
                                influencerRating);

                return repository.save(account);
        }

        public SocialMediaAccount updateAccount(
                        String id,
                        SocialMediaAccountDTO dto) {

                SocialMediaAccount account = repository.findById(id)
                                .orElseThrow(() -> new NotFoundException(
                                                "Social Media Account not found with id: " + id));
                
                 UserDetailsDTO userDetailsDTO = (UserDetailsDTO)
                 SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                

                 if(!account.getUserId().equals(userDetailsDTO.getUserId())) 
                 {
                        throw new CustomException("Illegal access Try with different/own User id");
                 }

                account.setPlatform(dto.getPlatform());
                account.setAccountName(dto.getAccountName());
                account.setProfileUrl(dto.getProfileUrl());
                account.setFollowersCount(dto.getFollowersCount());
                account.setSubscriberCount(dto.getSubscriberCount());
                account.setStatus(dto.getStatus());
                //account.setUserId(userDetailsDTO.getUserId());
                BigDecimal engagementRate = calculateEngagementRate(
                                account.getTotalLikes(),
                                account.getTotalComments(),
                                account.getTotalViews());

                BigDecimal commentRatio = calculateCommentRatio(
                                account.getTotalComments(),
                                account.getTotalViews());

                BigDecimal viewSubscriberRatio = calculateViewSubscriberRatio(
                                account.getTotalViews(),
                                account.getSubscriberCount());

                BigDecimal score = calculateGenuineInfluencerScore(
                                engagementRate,
                                commentRatio,
                                viewSubscriberRatio);
                account.setTotalViews(dto.getTotalViews());
                account.setTotalLikes(dto.getTotalLikes());
                account.setTotalComments(dto.getTotalComments());

                account.setEngagementRate(
                                engagementRate);

                BigDecimal viewSubscriptionRatio = calculateViewSubscriptionRatio(
                                account.getTotalViews(),
                                account.getSubscriberCount());

                BigDecimal viewCommentRatio = calculateViewCommentRatio(
                                account.getTotalComments(),
                                account.getTotalViews());
                account.setViewSubscriptionRatio(
                                viewSubscriptionRatio);

                account.setViewCommentRatio(
                                viewCommentRatio);

                account.setGenuineInfluencerScore(
                                score);

                account.setInfluencerRating(
                                getInfluencerRating(score));

                account.setUpdatedAt(LocalDateTime.now());

                return repository.save(account);
        }

        public SocialMediaAccount patchAccount(
                        String id,
                        SocialMediaAccountDTO dto) {

                SocialMediaAccount account = repository.findById(id)
                                .orElseThrow(() -> new NotFoundException(
                                                "Social Media Account not found with id: " + id));
                
                UserDetailsDTO userDetailsDTO = (UserDetailsDTO)
                 SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                

                 if(!account.getUserId().equals(userDetailsDTO.getUserId())) 
                 {
                        throw new CustomException("Illegal access Try with different/own User id");
                 }
                
                


                if (dto.getPlatform() != null) {
                        account.setPlatform(dto.getPlatform());
                }

                if (dto.getAccountName() != null) {
                        account.setAccountName(dto.getAccountName());
                }

                if (dto.getProfileUrl() != null) {
                        account.setProfileUrl(dto.getProfileUrl());
                }

                if (dto.getFollowersCount() != null) {
                        account.setFollowersCount(dto.getFollowersCount());
                }

                if (dto.getSubscriberCount() != null) {
                        account.setSubscriberCount(dto.getSubscriberCount());
                }

                if (dto.getStatus() != null) {
                        account.setStatus(dto.getStatus());
                }
                if (dto.getTotalViews() != null) {
                        account.setTotalViews(dto.getTotalViews());
                }

                if (dto.getTotalLikes() != null) {
                        account.setTotalLikes(dto.getTotalLikes());
                }

                if (dto.getTotalComments() != null) {
                        account.setTotalComments(dto.getTotalComments());
                }
                BigDecimal engagementRate = calculateEngagementRate(
                                account.getTotalLikes(),
                                account.getTotalComments(),
                                account.getTotalViews());

                BigDecimal commentRatio = calculateCommentRatio(
                                account.getTotalComments(),
                                account.getTotalViews());

                BigDecimal viewSubscriberRatio = calculateViewSubscriberRatio(
                                account.getTotalViews(),
                                account.getSubscriberCount());

                BigDecimal score = calculateGenuineInfluencerScore(
                                engagementRate,
                                commentRatio,
                                viewSubscriberRatio);

                account.setEngagementRate(
                                engagementRate);

                BigDecimal viewSubscriptionRatio = calculateViewSubscriptionRatio(
                                account.getTotalViews(),
                                account.getSubscriberCount());

                BigDecimal viewCommentRatio = calculateViewCommentRatio(
                                account.getTotalComments(),
                                account.getTotalViews());

                account.setViewSubscriptionRatio(
                                viewSubscriptionRatio);

                account.setViewCommentRatio(
                                viewCommentRatio);

                account.setGenuineInfluencerScore(
                                score);

                account.setInfluencerRating(
                                getInfluencerRating(score));

                account.setUpdatedAt(LocalDateTime.now());

                return repository.save(account);
        }

        public Page<SocialMediaAccount> getAllAccounts(
                        int page,
                        int size,
                        String sortBy,
                        String sortDir) {

                Sort sort = sortDir.equalsIgnoreCase("asc")
                                ? Sort.by(sortBy).ascending()
                                : Sort.by(sortBy).descending();

                Pageable pageable = PageRequest.of(
                                page,
                                size,
                                sort);

                return repository.findAll(pageable);
        }

        public SocialMediaAccount getAccountById(String id) {

                return repository.findById(id)
                                .orElseThrow(() -> new NotFoundException(
                                                "Social Media Account not found with id: " + id));
        }

        public Page<SocialMediaAccount> getAccountsByUserId(
                        String userId,
                        int page,
                        int size,
                        String sortBy,
                        String sortDir) {

                Sort sort = sortDir.equalsIgnoreCase("asc")
                                ? Sort.by(sortBy).ascending()
                                : Sort.by(sortBy).descending();

                Pageable pageable = PageRequest.of(
                                page,
                                size,
                                sort);

                return repository.findByUserId(
                                userId,
                                pageable);
        }

        public List<SocialMediaAccount> searchByAccountName(
                        String accountName) {

                return repository.findByAccountNameContainingIgnoreCase(accountName);
        }

        public void deleteAccount(String id) {

                SocialMediaAccount account = repository.findById(id)
                                .orElseThrow(() -> new NotFoundException(
                                                "Social Media Account not found with id: " + id));

                repository.delete(account);
        }

        public Page<SocialMediaAccount> getAccountsByPlatform(
                        String platform,
                        int page,
                        int size,
                        String sortBy,
                        String sortDir) {

                Sort sort = sortDir.equalsIgnoreCase("asc")
                                ? Sort.by(sortBy).ascending()
                                : Sort.by(sortBy).descending();

                Pageable pageable = PageRequest.of(
                                page,
                                size,
                                sort);

                return repository.findByPlatformIgnoreCase(
                                platform,
                                pageable);
        }

        public Page<SocialMediaAccount> getAccountsByStatus(
                        String status,
                        int page,
                        int size,
                        String sortBy,
                        String sortDir) {

                Sort sort = sortDir.equalsIgnoreCase("asc")
                                ? Sort.by(sortBy).ascending()
                                : Sort.by(sortBy).descending();

                Pageable pageable = PageRequest.of(
                                page,
                                size,
                                sort);

                return repository.findByStatusIgnoreCase(
                                status,
                                pageable);
        }

        private BigDecimal calculateEngagementRate(
                        Long likes,
                        Long comments,
                        Long views) {

                if (views == null || views == 0) {
                        return BigDecimal.ZERO;
                }

                return BigDecimal.valueOf(likes + comments)
                                .multiply(BigDecimal.valueOf(100))
                                .divide(
                                                BigDecimal.valueOf(views),
                                                2,
                                                RoundingMode.HALF_UP);
        }

        private BigDecimal calculateCommentRatio(
                        Long comments,
                        Long views) {

                if (views == null || views == 0) {
                        return BigDecimal.ZERO;
                }

                return BigDecimal.valueOf(comments)
                                .multiply(BigDecimal.valueOf(100))
                                .divide(
                                                BigDecimal.valueOf(views),
                                                2,
                                                RoundingMode.HALF_UP);
        }

        private BigDecimal calculateViewSubscriberRatio(
                        Long views,
                        Long subscribers) {

                if (subscribers == null || subscribers == 0) {
                        return BigDecimal.ZERO;
                }

                return BigDecimal.valueOf(views)
                                .multiply(BigDecimal.valueOf(100))
                                .divide(
                                                BigDecimal.valueOf(subscribers),
                                                2,
                                                RoundingMode.HALF_UP);
        }

        private BigDecimal calculateGenuineInfluencerScore(
                        BigDecimal engagementRate,
                        BigDecimal commentRatio,
                        BigDecimal viewSubscriberRatio) {

                BigDecimal score = engagementRate.multiply(BigDecimal.valueOf(0.40))
                                .add(
                                                commentRatio.multiply(
                                                                BigDecimal.valueOf(0.30)))
                                .add(
                                                viewSubscriberRatio.multiply(
                                                                BigDecimal.valueOf(0.30)));

                return score.min(BigDecimal.valueOf(100));
        }

        private String getInfluencerRating(
                        BigDecimal score) {

                double value = score.doubleValue();

                if (value >= 80) {
                        return "Excellent";
                }

                if (value >= 60) {
                        return "Good";
                }

                if (value >= 40) {
                        return "Average";
                }

                return "Low";
        }

        private BigDecimal calculateViewSubscriptionRatio(
                        Long views,
                        Long subscribers) {

                if (views == null || subscribers == null || subscribers == 0) {
                        return BigDecimal.ZERO;
                }

                return BigDecimal.valueOf(views)
                                .multiply(BigDecimal.valueOf(100))
                                .divide(
                                                BigDecimal.valueOf(subscribers),
                                                2,
                                                RoundingMode.HALF_UP);
        }

        private BigDecimal calculateViewCommentRatio(
                        Long comments,
                        Long views) {

                if (views == null || views == 0) {
                        return BigDecimal.ZERO;
                }

                return BigDecimal.valueOf(comments)
                                .multiply(BigDecimal.valueOf(100))
                                .divide(
                                                BigDecimal.valueOf(views),
                                                2,
                                                RoundingMode.HALF_UP);
        }

        public Page<SocialMediaAccount> getTopInfluencersByPlatform(
                        String platform,
                        int page,
                        int size) {

                Pageable pageable = PageRequest.of(page, size);

                return repository
                                .findByPlatformIgnoreCaseOrderByGenuineInfluencerScoreDesc(
                                                platform,
                                                pageable);
        }

        @Transactional
        public void updateValidationResult(
                        SocialMediaValidationResultEvent event) {

                System.out.println(
                                "response for the validation : "
                                                + event);

                SocialMediaAccount account = repository
                                .findById(event.getId())
                                .orElseThrow(() -> new NotFoundException(
                                                "Social media account not found : "
                                                                + event.getId()));

                account.setFollowersCount(
                                event.getFollowersCount());

                account.setSubscriberCount(
                                event.getSubscriberCount());

                account.setTotalViews(
                                event.getTotalViews());

                account.setTotalLikes(
                                event.getTotalLikes());

                account.setTotalComments(
                                event.getTotalComments());

                account.setViewSubscriptionRatio(
                                event.getViewSubscriptionRatio());

                account.setViewCommentRatio(
                                event.getViewCommentRatio());

                account.setEngagementRate(
                                event.getEngagementRate());

                account.setGenuineInfluencerScore(
                                event.getGenuineInfluencerScore());

                account.setInfluencerRating(
                                event.getInfluencerRating());

                account.setStatus(
                                event.getStatus());

                account.setUpdatedAt(
                                LocalDateTime.now());

                repository.save(account);

                InfluencerProfilePublishEvent publishEvent = new InfluencerProfilePublishEvent(
                                account.getUserId(),
                                account.getStatus());

                try {
                        publisher.publishInfluencerProfileUpdate(publishEvent);
                } catch (Exception e) {
                        System.out.println("send event to user for update influencer profile : " + e.getMessage());
                }

                System.out.println(
                                "Social media account updated : "
                                                + account.getId());
        }

        @Transactional
        public ResponseDTO becomeInfluencer(BecomeInfluencerDTO dto) {
                try {
                        UserDetailsDTO userDetailsDTO = (UserDetailsDTO) SecurityContextHolder.getContext()
                                        .getAuthentication().getPrincipal();

                        List<SocialMediaAccount> socialMediaAccounts = repository
                                        .findByUserId(userDetailsDTO.getUserId());

                        if (socialMediaAccounts == null)
                                throw new NotFoundException("Social Media account not found");

                        for (SocialMediaAccount account : socialMediaAccounts) {
                                publisher.publishValidateInfluencer(account);
                        }
                } catch (Exception e) {
                        return new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),e.getMessage());
                }
                return new ResponseDTO(HttpStatus.OK.value(),"your social media account are under review");
        }
}