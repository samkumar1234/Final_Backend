package com.esports.project.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.esports.project.DTO.FilePatchDTO;
import com.esports.project.DTO.FileResponseDTO;
import com.esports.project.DTO.FileUploadDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.Repository.FilesRepository;
import com.esports.project.config.FileStorageProperties;
import com.esports.project.entity.Files;
import com.esports.project.enums.FileType;
import com.esports.project.enums.OwnerType;
import com.esports.project.exception.CustomException;
import com.esports.project.exception.NotFoundException;

@Service
public class FilesService {

    private static final Set<String> ALLOWED_SORT_FIELDS = Set.of(
            "originalFileName",
            "fileType",
            "ownerType",
            "ownerId",
            "fileSize",
            "createdAt",
            "updatedAt"
    );

    private final FilesRepository filesRepository;
    private final Path storageRoot;

    public FilesService(
            FilesRepository filesRepository,
            FileStorageProperties storageProperties) {

        this.filesRepository = filesRepository;

        this.storageRoot = Paths.get(storageProperties.getRootPath())
                .toAbsolutePath()
                .normalize();

        try {
            java.nio.file.Files.createDirectories(this.storageRoot);
        } catch (IOException exception) {
            throw new IllegalStateException(
                    "Could not initialize storage directory",
                    exception);
        }
    }

    @Transactional
    public FileResponseDTO createFile(
            MultipartFile multipartFile,
            FileUploadDTO dto) {

        validateUploadedFile(multipartFile);

        UserDetailsDTO currentUser = getCurrentUser();

        String originalFileName = sanitizeFileName(
                multipartFile.getOriginalFilename());

        String storedFileName = generateStoredFileName(originalFileName);

        String relativePath = buildRelativePath(
                dto.getOwnerType(),
                dto.getOwnerId(),
                dto.getFileType(),
                storedFileName);

        Path destination = resolveStoragePath(relativePath);

        try {
            java.nio.file.Files.createDirectories(destination.getParent());

            try (InputStream inputStream = multipartFile.getInputStream()) {
                java.nio.file.Files.copy(
                        inputStream,
                        destination,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            throw new CustomException(
                    "Unable to store file: " + originalFileName);
        }

        Files file = new Files();
        file.setOriginalFileName(originalFileName);
        file.setStoredFileName(storedFileName);
        file.setFileType(dto.getFileType());
        file.setOwnerType(dto.getOwnerType());
        file.setOwnerId(dto.getOwnerId());
        file.setMimeType(getMimeType(multipartFile));
        file.setFileSize(multipartFile.getSize());
        file.setStoragePath(relativePath);
        file.setUploadedByUserId(currentUser.getUserId());

        try {
            Files savedFile = filesRepository.save(file);
            return mapToResponse(savedFile);
        } catch (RuntimeException exception) {
            deleteDiskFileSilently(destination);
            throw exception;
        }
    }

    @Transactional(readOnly = true)
    public Page<FileResponseDTO> getAllFiles(
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Pageable pageable = createPageable(
                page,
                size,
                sortBy,
                sortDir);

        return filesRepository.findAll(pageable)
                .map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public FileResponseDTO getFileById(String id) {
        return mapToResponse(findFile(id));
    }

    @Transactional(readOnly = true)
    public Page<FileResponseDTO> getFilesByUploadedUser(
            String userId,
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Pageable pageable = createPageable(
                page,
                size,
                sortBy,
                sortDir);

        return filesRepository.findByUploadedByUserId(
                        userId,
                        pageable)
                .map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public Page<FileResponseDTO> getFilesByType(
            FileType fileType,
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Pageable pageable = createPageable(
                page,
                size,
                sortBy,
                sortDir);

        return filesRepository.findByFileType(fileType, pageable)
                .map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public Page<FileResponseDTO> getFilesByOwner(
            OwnerType ownerType,
            String ownerId,
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Pageable pageable = createPageable(
                page,
                size,
                sortBy,
                sortDir);

        return filesRepository.findByOwnerTypeAndOwnerId(
                        ownerType,
                        ownerId,
                        pageable)
                .map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public List<FileResponseDTO> searchByFileName(String fileName) {

        if (!StringUtils.hasText(fileName)) {
            throw new CustomException("Search file name cannot be empty");
        }

        return filesRepository
                .findByOriginalFileNameContainingIgnoreCase(fileName.trim())
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    /**
     * Replaces the physical file but keeps the same database ID.
     */
    @Transactional
    public FileResponseDTO replaceFile(
            String id,
            MultipartFile multipartFile,
            FileUploadDTO dto) {

        validateUploadedFile(multipartFile);

        Files existingFile = findFile(id);
        validateFileOwnership(existingFile);

        Path oldFilePath = resolveStoragePath(
                existingFile.getStoragePath());

        String originalFileName = sanitizeFileName(
                multipartFile.getOriginalFilename());

        String storedFileName = generateStoredFileName(originalFileName);

        String relativePath = buildRelativePath(
                dto.getOwnerType(),
                dto.getOwnerId(),
                dto.getFileType(),
                storedFileName);

        Path newFilePath = resolveStoragePath(relativePath);

        try {
            java.nio.file.Files.createDirectories(newFilePath.getParent());

            try (InputStream inputStream = multipartFile.getInputStream()) {
                java.nio.file.Files.copy(
                        inputStream,
                        newFilePath,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            existingFile.setOriginalFileName(originalFileName);
            existingFile.setStoredFileName(storedFileName);
            existingFile.setFileType(dto.getFileType());
            existingFile.setOwnerType(dto.getOwnerType());
            existingFile.setOwnerId(dto.getOwnerId());
            existingFile.setMimeType(getMimeType(multipartFile));
            existingFile.setFileSize(multipartFile.getSize());
            existingFile.setStoragePath(relativePath);
            existingFile.setUpdatedAt(LocalDateTime.now());

            Files updatedFile = filesRepository.save(existingFile);

            if (!oldFilePath.equals(newFilePath)) {
                deleteDiskFileSilently(oldFilePath);
            }

            return mapToResponse(updatedFile);

        } catch (IOException exception) {
            deleteDiskFileSilently(newFilePath);

            throw new CustomException(
                    "Unable to replace file: " + originalFileName);
        }
    }

    /**
     * Updates only business metadata.
     */
    @Transactional
    public FileResponseDTO patchFile(
            String id,
            FilePatchDTO dto) {

        Files file = findFile(id);
        validateFileOwnership(file);

        FileType newFileType = dto.getFileType() != null
                ? dto.getFileType()
                : file.getFileType();

        OwnerType newOwnerType = dto.getOwnerType() != null
                ? dto.getOwnerType()
                : file.getOwnerType();

        String newOwnerId = StringUtils.hasText(dto.getOwnerId())
                ? dto.getOwnerId().trim()
                : file.getOwnerId();

        boolean pathChanged =
                newFileType != file.getFileType()
                || newOwnerType != file.getOwnerType()
                || !newOwnerId.equals(file.getOwnerId());

        if (pathChanged) {
            String newRelativePath = buildRelativePath(
                    newOwnerType,
                    newOwnerId,
                    newFileType,
                    file.getStoredFileName());

            Path oldPath = resolveStoragePath(file.getStoragePath());
            Path newPath = resolveStoragePath(newRelativePath);

            try {
                java.nio.file.Files.createDirectories(newPath.getParent());

                java.nio.file.Files.move(
                        oldPath,
                        newPath,
                        StandardCopyOption.REPLACE_EXISTING);

                file.setStoragePath(newRelativePath);
            } catch (IOException exception) {
                throw new CustomException(
                        "Unable to move file to the updated storage path");
            }
        }

        file.setFileType(newFileType);
        file.setOwnerType(newOwnerType);
        file.setOwnerId(newOwnerId);
        file.setUpdatedAt(LocalDateTime.now());

        return mapToResponse(filesRepository.save(file));
    }

    @Transactional(readOnly = true)
    public FileDownloadResult downloadFile(String id) {

        Files file = findFile(id);

        Path filePath = resolveStoragePath(file.getStoragePath());

        try {
            Resource resource = new UrlResource(filePath.toUri());

            if (!resource.exists() || !resource.isReadable()) {
                throw new NotFoundException(
                        "Physical file not found for file id: " + id);
            }

            return new FileDownloadResult(
                    resource,
                    file.getOriginalFileName(),
                    file.getMimeType(),
                    file.getFileSize());

        } catch (IOException exception) {
            throw new CustomException(
                    "Unable to read file with id: " + id);
        }
    }

    @Transactional
    public void deleteFile(String id) {

        Files file = findFile(id);
        validateFileOwnership(file);

        Path physicalPath = resolveStoragePath(
                file.getStoragePath());

        try {
            boolean deleted = java.nio.file.Files.deleteIfExists(
                    physicalPath);

            if (!deleted) {
                throw new NotFoundException(
                        "Physical file does not exist: "
                                + file.getOriginalFileName());
            }

            filesRepository.delete(file);

            deleteEmptyParentDirectories(physicalPath.getParent());

        } catch (IOException exception) {
            throw new CustomException(
                    "Unable to delete physical file: "
                            + file.getOriginalFileName());
        }
    }

    private Files findFile(String id) {
        return filesRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "File not found with id: " + id));
    }

    private void validateFileOwnership(Files file) {

        UserDetailsDTO currentUser = getCurrentUser();

        if (!file.getUploadedByUserId().equals(currentUser.getUserId())) {
            throw new CustomException(
                    "You are not allowed to modify this file");
        }
    }

    private UserDetailsDTO getCurrentUser() {

        Object principal = SecurityContextHolder.getContext()
                .getAuthentication()
                .getPrincipal();

        if (!(principal instanceof UserDetailsDTO userDetails)) {
            throw new CustomException(
                    "Authenticated user details are unavailable");
        }

        return userDetails;
    }

    private void validateUploadedFile(MultipartFile file) {

        if (file == null || file.isEmpty()) {
            throw new CustomException("Uploaded file cannot be empty");
        }

        if (!StringUtils.hasText(file.getOriginalFilename())) {
            throw new CustomException("File name is required");
        }
    }

    private String sanitizeFileName(String originalFileName) {

        String cleanFileName = StringUtils.cleanPath(originalFileName);

        if (!StringUtils.hasText(cleanFileName)
                || cleanFileName.contains("..")
                || cleanFileName.contains("/")
                || cleanFileName.contains("\\")) {

            throw new CustomException("Invalid file name");
        }

        return cleanFileName;
    }

    private String generateStoredFileName(String originalFileName) {

        String extension = "";

        int extensionIndex = originalFileName.lastIndexOf('.');

        if (extensionIndex >= 0
                && extensionIndex < originalFileName.length() - 1) {

            extension = originalFileName
                    .substring(extensionIndex)
                    .toLowerCase();
        }

        return UUID.randomUUID() + extension;
    }

    private String buildRelativePath(
            OwnerType ownerType,
            String ownerId,
            FileType fileType,
            String storedFileName) {

        if (!StringUtils.hasText(ownerId)) {
            throw new CustomException("Owner ID cannot be empty");
        }

        String sanitizedOwnerId = sanitizePathSegment(ownerId);

        return Paths.get(
                        ownerType.name(),
                        sanitizedOwnerId,
                        fileType.name(),
                        storedFileName)
                .toString()
                .replace("\\", "/");
    }

    private String sanitizePathSegment(String value) {

        String sanitized = value.trim()
                .replaceAll("[^a-zA-Z0-9_-]", "_");

        if (!StringUtils.hasText(sanitized)) {
            throw new CustomException("Invalid storage path value");
        }

        return sanitized;
    }

    private Path resolveStoragePath(String relativePath) {

        Path resolvedPath = storageRoot
                .resolve(relativePath)
                .normalize();

        if (!resolvedPath.startsWith(storageRoot)) {
            throw new CustomException("Invalid storage path");
        }

        return resolvedPath;
    }

    private String getMimeType(MultipartFile file) {

        if (StringUtils.hasText(file.getContentType())) {
            return file.getContentType();
        }

        return "application/octet-stream";
    }

    private Pageable createPageable(
            int page,
            int size,
            String sortBy,
            String sortDir) {

        if (page < 0) {
            throw new CustomException("Page cannot be negative");
        }

        if (size < 1 || size > 100) {
            throw new CustomException(
                    "Page size must be between 1 and 100");
        }

        String safeSortBy = ALLOWED_SORT_FIELDS.contains(sortBy)
                ? sortBy
                : "createdAt";

        Sort.Direction direction =
                "asc".equalsIgnoreCase(sortDir)
                        ? Sort.Direction.ASC
                        : Sort.Direction.DESC;

        return PageRequest.of(
                page,
                size,
                Sort.by(direction, safeSortBy));
    }

    private FileResponseDTO mapToResponse(Files file) {

        return FileResponseDTO.builder()
                .id(file.getId())
                .originalFileName(file.getOriginalFileName())
                .fileType(file.getFileType())
                .ownerType(file.getOwnerType())
                .ownerId(file.getOwnerId())
                .mimeType(file.getMimeType())
                .fileSize(file.getFileSize())
                .uploadedByUserId(file.getUploadedByUserId())
                .createdAt(file.getCreatedAt())
                .updatedAt(file.getUpdatedAt())
                .downloadUrl("/media/files/"
                        + file.getId()
                        + "/download")
                .build();
    }

    private void deleteDiskFileSilently(Path path) {
        try {
            java.nio.file.Files.deleteIfExists(path);
        } catch (IOException ignored) {
            // Log this exception in production.
        }
    }

    private void deleteEmptyParentDirectories(Path directory) {

        Path currentDirectory = directory;

        while (currentDirectory != null
                && !currentDirectory.equals(storageRoot)) {

            try {
                if (!java.nio.file.Files.isDirectory(currentDirectory)) {
                    return;
                }

                try (var entries =
                             java.nio.file.Files.list(currentDirectory)) {

                    if (entries.findAny().isPresent()) {
                        return;
                    }
                }

                java.nio.file.Files.deleteIfExists(currentDirectory);
                currentDirectory = currentDirectory.getParent();

            } catch (IOException exception) {
                return;
            }
        }
    }

    public record FileDownloadResult(
            Resource resource,
            String originalFileName,
            String mimeType,
            Long fileSize) {
    }
}