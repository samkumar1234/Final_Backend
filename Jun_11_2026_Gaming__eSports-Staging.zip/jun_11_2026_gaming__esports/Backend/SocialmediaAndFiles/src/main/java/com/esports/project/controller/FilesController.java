package com.esports.project.controller;

import java.nio.charset.StandardCharsets;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.esports.project.DTO.FilePatchDTO;
import com.esports.project.DTO.FileResponseDTO;
import com.esports.project.DTO.FileUploadDTO;
import com.esports.project.enums.FileType;
import com.esports.project.enums.OwnerType;
import com.esports.project.exception.CustomException;
import com.esports.project.service.FilesService;
import com.esports.project.service.FilesService.FileDownloadResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/media/files")
public class FilesController {

        private final FilesService filesService;
        private final ObjectMapper objectMapper;

        public FilesController(FilesService filesService, ObjectMapper objectMapper) {
                this.filesService = filesService;
                this.objectMapper = objectMapper;
        }

        @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
        // @PreAuthorize("hasAuthority('FILE_WRITE')")
        public ResponseEntity<FileResponseDTO> createFile(
                        @RequestPart("file") MultipartFile file,
                        @RequestPart("data") String data) {
                FileUploadDTO dto;
                try {
                        dto = objectMapper.readValue(
                                        data,
                                        FileUploadDTO.class);
                } catch (JsonProcessingException exception) {
                        throw new CustomException(
                                        "Invalid JSON supplied in the data field");
                }

                if (dto.getFileType() == null) {
                        throw new CustomException("File type is required");
                }

                if (dto.getOwnerType() == null) {
                        throw new CustomException("Owner type is required");
                }

                if (dto.getOwnerId() == null || dto.getOwnerId().isBlank()) {
                        throw new CustomException("Owner ID is required");
                }
                FileResponseDTO createdFile = filesService.createFile(file, dto);

                return ResponseEntity
                                .status(HttpStatus.CREATED)
                                .body(createdFile);
        }

        @GetMapping
        // @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Page<FileResponseDTO>> getAllFiles(
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "createdAt") String sortBy,
                        @RequestParam(defaultValue = "desc") String sortDir) {

                return ResponseEntity.ok(
                                filesService.getAllFiles(
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/{id}")
        // @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<FileResponseDTO> getFileById(
                        @PathVariable String id) {

                return ResponseEntity.ok(
                                filesService.getFileById(id));
        }

        @GetMapping("/uploaded-by/{userId}")
        // @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Page<FileResponseDTO>> getFilesByUploadedUser(

                        @PathVariable String userId,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "createdAt") String sortBy,
                        @RequestParam(defaultValue = "desc") String sortDir) {

                return ResponseEntity.ok(
                                filesService.getFilesByUploadedUser(
                                                userId,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/type/{fileType}")
        // @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Page<FileResponseDTO>> getFilesByType(
                        @PathVariable FileType fileType,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "createdAt") String sortBy,
                        @RequestParam(defaultValue = "desc") String sortDir) {

                return ResponseEntity.ok(
                                filesService.getFilesByType(
                                                fileType,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/owner/{ownerType}/{ownerId}")
        // @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Page<FileResponseDTO>> getFilesByOwner(
                        @PathVariable OwnerType ownerType,
                        @PathVariable String ownerId,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "createdAt") String sortBy,
                        @RequestParam(defaultValue = "desc") String sortDir) {

                return ResponseEntity.ok(
                                filesService.getFilesByOwner(
                                                ownerType,
                                                ownerId,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/search")
        // @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<List<FileResponseDTO>> searchFile(
                        @RequestParam String fileName) {

                return ResponseEntity.ok(
                                filesService.searchByFileName(fileName));
        }

        @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
        // @PreAuthorize("hasAuthority('FILE_WRITE')")
        public ResponseEntity<FileResponseDTO> replaceFile(
                        @PathVariable String id,
                        @RequestPart("file") MultipartFile file,
                        @Valid @RequestPart("data") FileUploadDTO dto) {

                return ResponseEntity.ok(
                                filesService.replaceFile(id, file, dto));
        }

        @PatchMapping("/{id}")
        // @PreAuthorize("hasAuthority('FILE_WRITE')")
        public ResponseEntity<FileResponseDTO> patchFile(
                        @PathVariable String id,
                        @org.springframework.web.bind.annotation.RequestBody FilePatchDTO dto) {

                return ResponseEntity.ok(
                                filesService.patchFile(id, dto));
        }

        @GetMapping("/{id}/download")
        // @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Resource> downloadFile(
                        @PathVariable String id) {

                FileDownloadResult download = filesService.downloadFile(id);

                MediaType mediaType;

                try {
                        mediaType = MediaType.parseMediaType(
                                        download.mimeType());
                } catch (Exception exception) {
                        mediaType = MediaType.APPLICATION_OCTET_STREAM;
                }

                ContentDisposition disposition = ContentDisposition.attachment()
                                .filename(
                                                download.originalFileName(),
                                                StandardCharsets.UTF_8)
                                .build();

                return ResponseEntity.ok()
                                .contentType(mediaType)
                                .contentLength(download.fileSize())
                                .header(
                                                HttpHeaders.CONTENT_DISPOSITION,
                                                disposition.toString())
                                .body(download.resource());
        }

        @DeleteMapping("/{id}")
        // @PreAuthorize("hasAuthority('FILE_DELETE')")
        public ResponseEntity<Void> deleteFile(
                        @PathVariable String id) {

                filesService.deleteFile(id);

                return ResponseEntity.noContent().build();
        }
}