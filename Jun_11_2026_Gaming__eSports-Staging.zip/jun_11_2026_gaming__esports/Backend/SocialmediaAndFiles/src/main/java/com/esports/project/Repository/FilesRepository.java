package com.esports.project.Repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.project.entity.Files;
import com.esports.project.enums.FileType;
import com.esports.project.enums.OwnerType;

public interface FilesRepository extends JpaRepository<Files, String> {

    Page<Files> findByUploadedByUserId(
            String uploadedByUserId,
            Pageable pageable);

    Page<Files> findByFileType(
            FileType fileType,
            Pageable pageable);

    Page<Files> findByOwnerTypeAndOwnerId(
            OwnerType ownerType,
            String ownerId,
            Pageable pageable);

    Page<Files> findByOwnerType(
            OwnerType ownerType,
            Pageable pageable);

    List<Files> findByOriginalFileNameContainingIgnoreCase(
            String originalFileName);
}