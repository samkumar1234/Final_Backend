package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FilesDTO {

    private String fileName;

    private String fileType;

    private String bucketName;

    private String storagePath;

    private Long fileSize;

    private String userId;
}