package com.esports.project.DTO;

import com.esports.project.enums.FileType;
import com.esports.project.enums.OwnerType;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FileUploadDTO {

    @NotNull(message = "File type is required")
    private FileType fileType;

    @NotNull(message = "Owner type is required")
    private OwnerType ownerType;

    @NotBlank(message = "Owner ID is required")
    private String ownerId;
}
