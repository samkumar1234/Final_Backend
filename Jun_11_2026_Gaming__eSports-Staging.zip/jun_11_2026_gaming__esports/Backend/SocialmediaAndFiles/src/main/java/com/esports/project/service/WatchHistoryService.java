package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.DTO.WatchHistoryRequestDTO;
import com.esports.project.Repository.WatchHistoryRepository;
import com.esports.project.entity.WatchHistory;
import com.esports.project.exception.CustomException;
import com.esports.project.exception.NotFoundException;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

@Service
public class WatchHistoryService {

    private final WatchHistoryRepository watchHistoryRepository;

    public WatchHistoryService(
            WatchHistoryRepository watchHistoryRepository) {

        this.watchHistoryRepository = watchHistoryRepository;
    }

    public WatchHistory watchMatch(WatchHistoryRequestDTO dto) {

        if (watchHistoryRepository.existsByUserIdAndMatchId(
                dto.getUserId(),
                dto.getMatchId())) {

            throw new CustomException(
                    "Watch history already exists for this user and match");
        }
        

        WatchHistory watchHistory = new WatchHistory();
        UserDetailsDTO userDetailsDTO = (UserDetailsDTO)
                 SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                

        watchHistory.setUserId(userDetailsDTO.getUserId());

        watchHistory.setMatchId(dto.getMatchId());
        watchHistory.setCreatedAt(LocalDateTime.now());

        return watchHistoryRepository.save(watchHistory);
    }

    public Page<WatchHistory> getAllWatchHistory(
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(
                page,
                size,
                sort);

        return watchHistoryRepository.findAll(pageable);
    }

    public WatchHistory getWatchHistoryById(String id) {

        return watchHistoryRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Watch history not found with id: " + id));
    }

    public List<WatchHistory> getWatchHistoryByUserId(
            String userId) {

        return watchHistoryRepository.findByUserId(userId);
    }

    public List<WatchHistory> getWatchHistoryByMatchId(
            String matchId) {

        return watchHistoryRepository.findByMatchId(matchId);
    }

    public void deleteWatchHistory(String id) {

        WatchHistory watchHistory = watchHistoryRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Watch history not found with id: " + id));

        watchHistoryRepository.delete(watchHistory);
    }

    public Page<WatchHistory> getByUserId(
            String userId,
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(
                page,
                size,
                sort);

        return watchHistoryRepository.findByUserId(
                userId,
                pageable);
    }

    public Page<WatchHistory> getByMatchId(
            String matchId,
            int page,
            int size) {

        Pageable pageable = PageRequest.of(page, size);

        return watchHistoryRepository.findByMatchId(
                matchId,
                pageable);
    }
}