package com.esports.project.enums;

public enum OwnerType {
    USER,
    TEAM,
    TOURNAMENT,
    CAMPAIGN,
    GAME,
    SPONSOR
}
