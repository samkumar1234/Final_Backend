package com.esports.project.websocket;

import java.net.URI;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.service.JwtService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class PublisherBrokerClient {

    private final JwtService jwtService;

    private WebSocketSession session;

    private final ObjectMapper objectMapper =
            new ObjectMapper();

    @PostConstruct
    public void init() {

        connect();
    }

    private synchronized void connect() {

        try {

            if (session != null &&
                    session.isOpen()) {
                return;
            }

            String token =
                    jwtService.generateToken(
                            "socialmedia-service");

            StandardWebSocketClient client =
                    new StandardWebSocketClient();

            session = client.execute(
                    new TextWebSocketHandler() {
                    },
                    null,
                    URI.create(
                            "ws://localhost:8085/broker?token="
                                    + token))
                    .get();

            System.out.println(
                    "Publisher connected");

        } catch (Exception ex) {

            System.out.println(
                    "Broker unavailable");
        }
    }

    @Scheduled(fixedDelay = 6000)
    public void reconnect() {

        if (session == null ||
                !session.isOpen()) {

            System.out.println(
                    "Publisher reconnecting...");

            connect();
        }
    }

    public void publish(
            BrokerMessage message)
            throws Exception {

        if (session == null ||
                !session.isOpen()) {

            connect();
        }

        if (session == null ||
                !session.isOpen()) {

            throw new RuntimeException(
                    "Broker connection unavailable");
        }

        session.sendMessage(
                new TextMessage(
                        objectMapper.writeValueAsString(
                                message)));

        System.out.println(
                "Published -> "
                        + message.getTopic());
    }
}