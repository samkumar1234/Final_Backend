package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import com.esports.project.DTO.WatchHistoryRequestDTO;
import com.esports.project.Repository.WatchHistoryRepository;
import com.esports.project.entity.WatchHistory;
import com.esports.project.exception.CustomException;
import com.esports.project.exception.NotFoundException;

@ExtendWith(MockitoExtension.class)
class WatchHistoryServiceTest {

    @Mock
    private WatchHistoryRepository watchHistoryRepository;

    @InjectMocks
    private WatchHistoryService watchHistoryService;

    @Test
void shouldCreateWatchHistory() {

    WatchHistoryRequestDTO dto =
            new WatchHistoryRequestDTO();

    dto.setUserId("USER001");
    dto.setMatchId("MATCH001");

    WatchHistory watchHistory =
            new WatchHistory();

    watchHistory.setUserId("USER001");
    watchHistory.setMatchId("MATCH001");

    when(watchHistoryRepository
            .existsByUserIdAndMatchId(
                    "USER001",
                    "MATCH001"))
            .thenReturn(false);

    when(watchHistoryRepository.save(
            any(WatchHistory.class)))
            .thenReturn(watchHistory);

    WatchHistory result =
            watchHistoryService.watchMatch(dto);

    assertNotNull(result);
    assertEquals(
            "USER001",
            result.getUserId());

    verify(watchHistoryRepository)
            .save(any(WatchHistory.class));
}
@Test
void shouldThrowExceptionWhenWatchHistoryAlreadyExists() {

    WatchHistoryRequestDTO dto =
            new WatchHistoryRequestDTO();

    dto.setUserId("USER001");
    dto.setMatchId("MATCH001");

    when(watchHistoryRepository
            .existsByUserIdAndMatchId(
                    "USER001",
                    "MATCH001"))
            .thenReturn(true);

    assertThrows(
            CustomException.class,
            () -> watchHistoryService.watchMatch(dto));

    verify(watchHistoryRepository, never())
            .save(any(WatchHistory.class));
}
@Test
void shouldReturnWatchHistoryById() {

    WatchHistory watchHistory =
            new WatchHistory();

    watchHistory.setId("1");

    when(watchHistoryRepository.findById("1"))
            .thenReturn(
                    Optional.of(watchHistory));

    WatchHistory result =
            watchHistoryService
                    .getWatchHistoryById("1");

    assertNotNull(result);

    verify(watchHistoryRepository)
            .findById("1");
}
@Test
void shouldThrowExceptionWhenWatchHistoryNotFound() {

    when(watchHistoryRepository.findById("1"))
            .thenReturn(Optional.empty());

    assertThrows(
            NotFoundException.class,
            () -> watchHistoryService
                    .getWatchHistoryById("1"));

    verify(watchHistoryRepository)
            .findById("1");
}
@Test
void shouldReturnWatchHistoryByUserId() {

    List<WatchHistory> list =
            List.of(
                    new WatchHistory(),
                    new WatchHistory());

    when(watchHistoryRepository
            .findByUserId("USER001"))
            .thenReturn(list);

    List<WatchHistory> result =
            watchHistoryService
                    .getWatchHistoryByUserId(
                            "USER001");

    assertEquals(2, result.size());

    verify(watchHistoryRepository)
            .findByUserId("USER001");
}

@Test
void shouldReturnPaginatedWatchHistory() {

    Page<WatchHistory> page =
            new PageImpl<>(
                    List.of(
                            new WatchHistory(),
                            new WatchHistory()));

    when(watchHistoryRepository
            .findAll(any(Pageable.class)))
            .thenReturn(page);

    Page<WatchHistory> result =
            watchHistoryService
                    .getAllWatchHistory(
                            0,
                            10,
                            "createdAt",
                            "desc");

    assertEquals(
            2,
            result.getContent().size());

    verify(watchHistoryRepository)
            .findAll(any(Pageable.class));
}
@Test
void shouldReturnPaginatedWatchHistoryByUserId() {

    Page<WatchHistory> page =
            new PageImpl<>(
                    List.of(
                            new WatchHistory(),
                            new WatchHistory()));

    when(watchHistoryRepository.findByUserId(
            eq("USER001"),
            any(Pageable.class)))
            .thenReturn(page);

    Page<WatchHistory> result =
            watchHistoryService.getByUserId(
                    "USER001",
                    0,
                    10,
                    "createdAt",
                    "desc");

    assertEquals(
            2,
            result.getContent().size());

    verify(watchHistoryRepository)
            .findByUserId(
                    eq("USER001"),
                    any(Pageable.class));
}
@Test
void shouldReturnPaginatedWatchHistoryByMatchId() {

    Page<WatchHistory> page =
            new PageImpl<>(
                    List.of(
                            new WatchHistory()));

    when(watchHistoryRepository.findByMatchId(
            eq("MATCH001"),
            any(Pageable.class)))
            .thenReturn(page);

    Page<WatchHistory> result =
            watchHistoryService.getByMatchId(
                    "MATCH001",
                    0,
                    10);

    assertEquals(
            1,
            result.getContent().size());

    verify(watchHistoryRepository)
            .findByMatchId(
                    eq("MATCH001"),
                    any(Pageable.class));
}

}