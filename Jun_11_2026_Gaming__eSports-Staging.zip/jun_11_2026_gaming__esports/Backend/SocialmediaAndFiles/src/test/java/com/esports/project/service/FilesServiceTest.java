package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.esports.project.DTO.FilePatchDTO;
import com.esports.project.DTO.FileResponseDTO;
import com.esports.project.DTO.FileUploadDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.Repository.FilesRepository;
import com.esports.project.config.FileStorageProperties;
import com.esports.project.entity.Files;
import com.esports.project.enums.FileType;
import com.esports.project.enums.OwnerType;
import com.esports.project.exception.CustomException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.service.FilesService.FileDownloadResult;

@ExtendWith(MockitoExtension.class)
class FilesServiceTest {

    @TempDir
    Path tempDirectory;

    @Mock
    private FilesRepository repository;

    private FilesService service;

    private UserDetailsDTO currentUser;

    @BeforeEach
    void setUp() {

        FileStorageProperties storageProperties =
                new FileStorageProperties();

        storageProperties.setRootPath(
                tempDirectory.toString());

        service = new FilesService(
                repository,
                storageProperties);

        currentUser = new UserDetailsDTO(
                "USER001",
                "kamalesh",
                List.of("USER"),
                List.of(
                        "FILE_READ",
                        "FILE_WRITE",
                        "FILE_DELETE"));

        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(
                        currentUser,
                        null,
                        List.of());

        SecurityContextHolder.getContext()
                .setAuthentication(authentication);
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void shouldCreateFileAndStoreItOnLocalDisk() {

        MockMultipartFile multipartFile =
                new MockMultipartFile(
                        "file",
                        "profile.jpg",
                        "image/jpeg",
                        "profile-image-content"
                                .getBytes(StandardCharsets.UTF_8));

        FileUploadDTO dto = createUploadDTO();

        when(repository.save(any(Files.class)))
                .thenAnswer(invocation -> {

                    Files savedFile =
                            invocation.getArgument(0);

                    savedFile.setId("FILE001");
                    savedFile.setCreatedAt(
                            LocalDateTime.now());

                    return savedFile;
                });

        FileResponseDTO result =
                service.createFile(multipartFile, dto);

        ArgumentCaptor<Files> fileCaptor =
                ArgumentCaptor.forClass(Files.class);

        verify(repository).save(fileCaptor.capture());

        Files savedEntity = fileCaptor.getValue();

        assertNotNull(result);
        assertEquals("FILE001", result.getId());

        assertEquals(
                "profile.jpg",
                result.getOriginalFileName());

        assertEquals(
                FileType.PROFILE_PICTURE,
                result.getFileType());

        assertEquals(
                OwnerType.USER,
                result.getOwnerType());

        assertEquals(
                "USER001",
                result.getOwnerId());

        assertEquals(
                "USER001",
                result.getUploadedByUserId());

        assertEquals(
                "image/jpeg",
                result.getMimeType());

        assertNotNull(result.getDownloadUrl());

        assertEquals(
                "profile.jpg",
                savedEntity.getOriginalFileName());

        assertNotNull(
                savedEntity.getStoredFileName());

        assertEquals(
                "USER001",
                savedEntity.getUploadedByUserId());

        assertEquals(
                "image/jpeg",
                savedEntity.getMimeType());

        assertEquals(
                multipartFile.getSize(),
                savedEntity.getFileSize());

        assertTrue(
                savedEntity.getStoragePath()
                        .startsWith(
                                "USER/USER001/"
                                        + "PROFILE_PICTURE/"));

        assertFalse(
                savedEntity.getStoragePath()
                        .contains(tempDirectory.toString()));

        Path physicalFile =
                tempDirectory.resolve(
                        savedEntity.getStoragePath());

        assertTrue(
                java.nio.file.Files.exists(physicalFile));

        assertTrue(
                java.nio.file.Files.isRegularFile(physicalFile));
    }

    @Test
    void shouldCreatePhysicalFileWithExpectedContent()
            throws Exception {

        byte[] fileContent =
                "profile-image-content"
                        .getBytes(StandardCharsets.UTF_8);

        MockMultipartFile multipartFile =
                new MockMultipartFile(
                        "file",
                        "profile.jpg",
                        "image/jpeg",
                        fileContent);

        FileUploadDTO dto = createUploadDTO();

        when(repository.save(any(Files.class)))
                .thenAnswer(invocation -> {

                    Files file = invocation.getArgument(0);

                    file.setId("FILE001");
                    file.setCreatedAt(LocalDateTime.now());

                    return file;
                });

        service.createFile(multipartFile, dto);

        ArgumentCaptor<Files> fileCaptor =
                ArgumentCaptor.forClass(Files.class);

        verify(repository).save(fileCaptor.capture());

        Files savedEntity = fileCaptor.getValue();

        Path physicalFile =
                tempDirectory.resolve(
                        savedEntity.getStoragePath());

        assertTrue(
                java.nio.file.Files.exists(physicalFile));

        String storedContent =
                java.nio.file.Files.readString(
                        physicalFile,
                        StandardCharsets.UTF_8);

        assertEquals(
                "profile-image-content",
                storedContent);
    }

    @Test
    void shouldGenerateUniqueStoredFileName() {

        MockMultipartFile multipartFile =
                new MockMultipartFile(
                        "file",
                        "profile.jpg",
                        "image/jpeg",
                        "image-content"
                                .getBytes(StandardCharsets.UTF_8));

        when(repository.save(any(Files.class)))
                .thenAnswer(invocation -> {

                    Files file = invocation.getArgument(0);

                    file.setId("FILE001");
                    file.setCreatedAt(LocalDateTime.now());

                    return file;
                });

        service.createFile(
                multipartFile,
                createUploadDTO());

        ArgumentCaptor<Files> fileCaptor =
                ArgumentCaptor.forClass(Files.class);

        verify(repository).save(fileCaptor.capture());

        Files savedEntity = fileCaptor.getValue();

        assertNotNull(savedEntity.getStoredFileName());

        assertFalse(
                savedEntity.getStoredFileName()
                        .equals("profile.jpg"));

        assertTrue(
                savedEntity.getStoredFileName()
                        .endsWith(".jpg"));
    }

    @Test
    void shouldUseDefaultMimeTypeWhenMimeTypeIsMissing() {

        MockMultipartFile multipartFile =
                new MockMultipartFile(
                        "file",
                        "attachment.bin",
                        null,
                        "some-content"
                                .getBytes(StandardCharsets.UTF_8));

        when(repository.save(any(Files.class)))
                .thenAnswer(invocation -> {

                    Files file = invocation.getArgument(0);

                    file.setId("FILE001");
                    file.setCreatedAt(LocalDateTime.now());

                    return file;
                });

        FileResponseDTO result =
                service.createFile(
                        multipartFile,
                        createUploadDTO());

        assertEquals(
                "application/octet-stream",
                result.getMimeType());
    }

    @Test
    void shouldThrowExceptionWhenUploadedFileIsEmpty() {

        MockMultipartFile emptyFile =
                new MockMultipartFile(
                        "file",
                        "empty.jpg",
                        "image/jpeg",
                        new byte[0]);

        FileUploadDTO dto = createUploadDTO();

        assertThrows(
                CustomException.class,
                () -> service.createFile(
                        emptyFile,
                        dto));

        verify(repository, never())
                .save(any(Files.class));
    }

    @Test
    void shouldThrowExceptionWhenOriginalFileNameIsMissing() {

        MockMultipartFile multipartFile =
                new MockMultipartFile(
                        "file",
                        "",
                        "image/jpeg",
                        "image-content"
                                .getBytes(StandardCharsets.UTF_8));

        assertThrows(
                CustomException.class,
                () -> service.createFile(
                        multipartFile,
                        createUploadDTO()));

        verify(repository, never())
                .save(any(Files.class));
    }

    @Test
    void shouldRejectUnsafeOriginalFileName() {

        MockMultipartFile multipartFile =
                new MockMultipartFile(
                        "file",
                        "../unsafe-file.jpg",
                        "image/jpeg",
                        "image-content"
                                .getBytes(StandardCharsets.UTF_8));

        assertThrows(
                CustomException.class,
                () -> service.createFile(
                        multipartFile,
                        createUploadDTO()));

        verify(repository, never())
                .save(any(Files.class));
    }

    @Test
    void shouldReturnFileById() {

        Files file = createStoredFileEntity();

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(file));

        FileResponseDTO result =
                service.getFileById("FILE001");

        assertNotNull(result);
        assertEquals("FILE001", result.getId());

        assertEquals(
                "test.pdf",
                result.getOriginalFileName());

        assertEquals(
                FileType.DOCUMENT,
                result.getFileType());

        assertEquals(
                OwnerType.USER,
                result.getOwnerType());

        assertEquals(
                "USER001",
                result.getOwnerId());

        assertEquals(
                "/media/files/FILE001/download",
                result.getDownloadUrl());

        verify(repository)
                .findById("FILE001");
    }

    @Test
    void shouldThrowExceptionWhenFileNotFound() {

        when(repository.findById("UNKNOWN"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getFileById("UNKNOWN"));

        verify(repository)
                .findById("UNKNOWN");
    }

    @Test
    void shouldReturnPaginatedFiles() {

        Files firstFile = createStoredFileEntity();

        Files secondFile = createStoredFileEntity();
        secondFile.setId("FILE002");
        secondFile.setOriginalFileName("banner.jpg");
        secondFile.setStoredFileName("stored-banner.jpg");
        secondFile.setFileType(FileType.BANNER);
        secondFile.setMimeType("image/jpeg");

        Page<Files> repositoryPage =
                new PageImpl<>(
                        List.of(
                                firstFile,
                                secondFile));

        when(repository.findAll(any(Pageable.class)))
                .thenReturn(repositoryPage);

        Page<FileResponseDTO> result =
                service.getAllFiles(
                        0,
                        10,
                        "originalFileName",
                        "asc");

        assertEquals(
                2,
                result.getNumberOfElements());

        assertEquals(
                "test.pdf",
                result.getContent()
                        .get(0)
                        .getOriginalFileName());

        assertEquals(
                "banner.jpg",
                result.getContent()
                        .get(1)
                        .getOriginalFileName());

        verify(repository)
                .findAll(any(Pageable.class));
    }

    @Test
    void shouldUseCreatedAtWhenInvalidSortFieldProvided() {

        Page<Files> repositoryPage =
                new PageImpl<>(
                        List.of(
                                createStoredFileEntity()));

        when(repository.findAll(any(Pageable.class)))
                .thenReturn(repositoryPage);

        service.getAllFiles(
                0,
                10,
                "invalidField",
                "desc");

        ArgumentCaptor<Pageable> pageableCaptor =
                ArgumentCaptor.forClass(Pageable.class);

        verify(repository)
                .findAll(pageableCaptor.capture());

        Pageable pageable = pageableCaptor.getValue();

        assertNotNull(
                pageable.getSort()
                        .getOrderFor("createdAt"));

        assertTrue(
                pageable.getSort()
                        .getOrderFor("createdAt")
                        .isDescending());
    }

    @Test
    void shouldCreateAscendingPagination() {

        Page<Files> repositoryPage =
                new PageImpl<>(
                        List.of(
                                createStoredFileEntity()));

        when(repository.findAll(any(Pageable.class)))
                .thenReturn(repositoryPage);

        service.getAllFiles(
                1,
                20,
                "originalFileName",
                "asc");

        ArgumentCaptor<Pageable> pageableCaptor =
                ArgumentCaptor.forClass(Pageable.class);

        verify(repository)
                .findAll(pageableCaptor.capture());

        Pageable pageable = pageableCaptor.getValue();

        assertEquals(1, pageable.getPageNumber());
        assertEquals(20, pageable.getPageSize());

        assertTrue(
                pageable.getSort()
                        .getOrderFor("originalFileName")
                        .isAscending());
    }

    @Test
    void shouldThrowExceptionForNegativePage() {

        assertThrows(
                CustomException.class,
                () -> service.getAllFiles(
                        -1,
                        10,
                        "createdAt",
                        "desc"));

        verify(repository, never())
                .findAll(any(Pageable.class));
    }

    @Test
    void shouldThrowExceptionWhenPageSizeIsZero() {

        assertThrows(
                CustomException.class,
                () -> service.getAllFiles(
                        0,
                        0,
                        "createdAt",
                        "desc"));

        verify(repository, never())
                .findAll(any(Pageable.class));
    }

    @Test
    void shouldThrowExceptionWhenPageSizeExceedsMaximum() {

        assertThrows(
                CustomException.class,
                () -> service.getAllFiles(
                        0,
                        101,
                        "createdAt",
                        "desc"));

        verify(repository, never())
                .findAll(any(Pageable.class));
    }

    @Test
    void shouldReturnFilesByUploadedUserId() {

        Page<Files> repositoryPage =
                new PageImpl<>(
                        List.of(
                                createStoredFileEntity(),
                                createStoredFileEntity()));

        when(repository.findByUploadedByUserId(
                eq("USER001"),
                any(Pageable.class)))
                .thenReturn(repositoryPage);

        Page<FileResponseDTO> result =
                service.getFilesByUploadedUser(
                        "USER001",
                        0,
                        10,
                        "createdAt",
                        "desc");

        assertEquals(
                2,
                result.getNumberOfElements());

        verify(repository)
                .findByUploadedByUserId(
                        eq("USER001"),
                        any(Pageable.class));
    }

    @Test
    void shouldReturnFilesByType() {

        Page<Files> repositoryPage =
                new PageImpl<>(
                        List.of(
                                createStoredFileEntity()));

        when(repository.findByFileType(
                eq(FileType.DOCUMENT),
                any(Pageable.class)))
                .thenReturn(repositoryPage);

        Page<FileResponseDTO> result =
                service.getFilesByType(
                        FileType.DOCUMENT,
                        0,
                        10,
                        "createdAt",
                        "desc");

        assertEquals(
                1,
                result.getNumberOfElements());

        assertEquals(
                FileType.DOCUMENT,
                result.getContent()
                        .get(0)
                        .getFileType());

        verify(repository)
                .findByFileType(
                        eq(FileType.DOCUMENT),
                        any(Pageable.class));
    }

    @Test
    void shouldReturnFilesByOwner() {

        Page<Files> repositoryPage =
                new PageImpl<>(
                        List.of(
                                createStoredFileEntity()));

        when(repository.findByOwnerTypeAndOwnerId(
                eq(OwnerType.USER),
                eq("USER001"),
                any(Pageable.class)))
                .thenReturn(repositoryPage);

        Page<FileResponseDTO> result =
                service.getFilesByOwner(
                        OwnerType.USER,
                        "USER001",
                        0,
                        10,
                        "createdAt",
                        "desc");

        assertEquals(
                1,
                result.getNumberOfElements());

        assertEquals(
                OwnerType.USER,
                result.getContent()
                        .get(0)
                        .getOwnerType());

        assertEquals(
                "USER001",
                result.getContent()
                        .get(0)
                        .getOwnerId());

        verify(repository)
                .findByOwnerTypeAndOwnerId(
                        eq(OwnerType.USER),
                        eq("USER001"),
                        any(Pageable.class));
    }

    @Test
    void shouldSearchFileByOriginalFileName() {

        Files file = createStoredFileEntity();

        when(repository
                .findByOriginalFileNameContainingIgnoreCase(
                        "test"))
                .thenReturn(List.of(file));

        List<FileResponseDTO> result =
                service.searchByFileName("test");

        assertEquals(1, result.size());

        assertEquals(
                "test.pdf",
                result.get(0)
                        .getOriginalFileName());

        verify(repository)
                .findByOriginalFileNameContainingIgnoreCase(
                        "test");
    }

    @Test
    void shouldTrimSearchFileName() {

        when(repository
                .findByOriginalFileNameContainingIgnoreCase(
                        "test"))
                .thenReturn(
                        List.of(
                                createStoredFileEntity()));

        List<FileResponseDTO> result =
                service.searchByFileName("  test  ");

        assertEquals(1, result.size());

        verify(repository)
                .findByOriginalFileNameContainingIgnoreCase(
                        "test");
    }

    @Test
    void shouldThrowExceptionWhenSearchTextIsEmpty() {

        assertThrows(
                CustomException.class,
                () -> service.searchByFileName("  "));

        verify(repository, never())
                .findByOriginalFileNameContainingIgnoreCase(
                        any(String.class));
    }

    @Test
    void shouldPatchFileMetadataAndMovePhysicalFile()
            throws Exception {

        Files existing = createStoredFileEntity();

        Path oldPhysicalFile =
                tempDirectory.resolve(
                        existing.getStoragePath());

        java.nio.file.Files.createDirectories(
                oldPhysicalFile.getParent());

        java.nio.file.Files.writeString(
                oldPhysicalFile,
                "document-content",
                StandardCharsets.UTF_8);

        FilePatchDTO dto = new FilePatchDTO();
        dto.setFileType(FileType.DELIVERABLE);
        dto.setOwnerType(OwnerType.CAMPAIGN);
        dto.setOwnerId("CAMPAIGN001");

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(existing));

        when(repository.save(any(Files.class)))
                .thenAnswer(
                        invocation ->
                                invocation.getArgument(0));

        FileResponseDTO result =
                service.patchFile(
                        "FILE001",
                        dto);

        assertEquals(
                FileType.DELIVERABLE,
                result.getFileType());

        assertEquals(
                OwnerType.CAMPAIGN,
                result.getOwnerType());

        assertEquals(
                "CAMPAIGN001",
                result.getOwnerId());

        assertNotNull(result.getUpdatedAt());

        Path newPhysicalFile =
                tempDirectory
                        .resolve("CAMPAIGN")
                        .resolve("CAMPAIGN001")
                        .resolve("DELIVERABLE")
                        .resolve(
                                existing.getStoredFileName());

        assertFalse(
                java.nio.file.Files.exists(
                        oldPhysicalFile));

        assertTrue(
                java.nio.file.Files.exists(
                        newPhysicalFile));

        assertEquals(
                "document-content",
                java.nio.file.Files.readString(
                        newPhysicalFile,
                        StandardCharsets.UTF_8));

        verify(repository)
                .save(existing);
    }

    @Test
    void shouldPreserveExistingValuesWhenPatchFieldsAreNull()
            throws Exception {

        Files existing = createStoredFileEntity();

        Path physicalFile =
                tempDirectory.resolve(
                        existing.getStoragePath());

        java.nio.file.Files.createDirectories(
                physicalFile.getParent());

        java.nio.file.Files.writeString(
                physicalFile,
                "content",
                StandardCharsets.UTF_8);

        FilePatchDTO dto = new FilePatchDTO();

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(existing));

        when(repository.save(any(Files.class)))
                .thenAnswer(
                        invocation ->
                                invocation.getArgument(0));

        FileResponseDTO result =
                service.patchFile(
                        "FILE001",
                        dto);

        assertEquals(
                FileType.DOCUMENT,
                result.getFileType());

        assertEquals(
                OwnerType.USER,
                result.getOwnerType());

        assertEquals(
                "USER001",
                result.getOwnerId());

        assertTrue(
                java.nio.file.Files.exists(
                        physicalFile));

        verify(repository)
                .save(existing);
    }

    @Test
    void shouldThrowExceptionWhenPatchingAnotherUsersFile() {

        Files existing = createStoredFileEntity();

        existing.setUploadedByUserId(
                "OTHER_USER");

        FilePatchDTO dto = new FilePatchDTO();
        dto.setFileType(FileType.DELIVERABLE);

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(existing));

        assertThrows(
                CustomException.class,
                () -> service.patchFile(
                        "FILE001",
                        dto));

        verify(repository, never())
                .save(any(Files.class));
    }

    @Test
    void shouldThrowExceptionWhenPatchingFileNotFound() {

        when(repository.findById("UNKNOWN"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.patchFile(
                        "UNKNOWN",
                        new FilePatchDTO()));

        verify(repository, never())
                .save(any(Files.class));
    }

    @Test
    void shouldReplacePhysicalFile()
            throws Exception {

        Files existing = createStoredFileEntity();

        Path oldFile =
                tempDirectory.resolve(
                        existing.getStoragePath());

        java.nio.file.Files.createDirectories(
                oldFile.getParent());

        java.nio.file.Files.writeString(
                oldFile,
                "old-file-content",
                StandardCharsets.UTF_8);

        MockMultipartFile newMultipartFile =
                new MockMultipartFile(
                        "file",
                        "updated-banner.png",
                        "image/png",
                        "new-file-content"
                                .getBytes(
                                        StandardCharsets.UTF_8));

        FileUploadDTO dto = new FileUploadDTO();
        dto.setFileType(FileType.BANNER);
        dto.setOwnerType(OwnerType.TOURNAMENT);
        dto.setOwnerId("TOURNAMENT001");

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(existing));

        when(repository.save(any(Files.class)))
                .thenAnswer(
                        invocation ->
                                invocation.getArgument(0));

        FileResponseDTO result =
                service.replaceFile(
                        "FILE001",
                        newMultipartFile,
                        dto);

        assertEquals(
                "updated-banner.png",
                result.getOriginalFileName());

        assertEquals(
                "image/png",
                result.getMimeType());

        assertEquals(
                FileType.BANNER,
                result.getFileType());

        assertEquals(
                OwnerType.TOURNAMENT,
                result.getOwnerType());

        assertEquals(
                "TOURNAMENT001",
                result.getOwnerId());

        assertFalse(
                java.nio.file.Files.exists(oldFile));

        Path newFile =
                tempDirectory.resolve(
                        existing.getStoragePath());

        assertTrue(
                java.nio.file.Files.exists(newFile));

        assertEquals(
                "new-file-content",
                java.nio.file.Files.readString(
                        newFile,
                        StandardCharsets.UTF_8));

        verify(repository)
                .save(existing);
    }

    @Test
    void shouldThrowExceptionWhenReplacingAnotherUsersFile()
            throws Exception {

        Files existing = createStoredFileEntity();

        existing.setUploadedByUserId(
                "OTHER_USER");

        Path oldFile =
                tempDirectory.resolve(
                        existing.getStoragePath());

        java.nio.file.Files.createDirectories(
                oldFile.getParent());

        java.nio.file.Files.writeString(
                oldFile,
                "old-content",
                StandardCharsets.UTF_8);

        MockMultipartFile newFile =
                new MockMultipartFile(
                        "file",
                        "replacement.pdf",
                        "application/pdf",
                        "replacement-content"
                                .getBytes(
                                        StandardCharsets.UTF_8));

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(existing));

        assertThrows(
                CustomException.class,
                () -> service.replaceFile(
                        "FILE001",
                        newFile,
                        createUploadDTO()));

        assertTrue(
                java.nio.file.Files.exists(oldFile));

        verify(repository, never())
                .save(any(Files.class));
    }

    @Test
    void shouldDownloadPhysicalFile()
            throws Exception {

        Files file = createStoredFileEntity();

        Path physicalFile =
                tempDirectory.resolve(
                        file.getStoragePath());

        java.nio.file.Files.createDirectories(
                physicalFile.getParent());

        java.nio.file.Files.writeString(
                physicalFile,
                "download-content",
                StandardCharsets.UTF_8);

        file.setFileSize(
                java.nio.file.Files.size(
                        physicalFile));

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(file));

        FileDownloadResult result =
                service.downloadFile("FILE001");

        assertNotNull(result);
        assertNotNull(result.resource());

        assertTrue(
                result.resource().exists());

        assertTrue(
                result.resource().isReadable());

        assertEquals(
                "test.pdf",
                result.originalFileName());

        assertEquals(
                "application/pdf",
                result.mimeType());

        assertEquals(
                file.getFileSize(),
                result.fileSize());

        String downloadedContent;

        try (var inputStream =
                     result.resource().getInputStream()) {

            downloadedContent =
                    new String(
                            inputStream.readAllBytes(),
                            StandardCharsets.UTF_8);
        }

        assertEquals(
                "download-content",
                downloadedContent);
    }

    @Test
    void shouldThrowExceptionWhenPhysicalDownloadFileIsMissing() {

        Files file = createStoredFileEntity();

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(file));

        assertThrows(
                NotFoundException.class,
                () -> service.downloadFile("FILE001"));
    }

    @Test
    void shouldDeleteDatabaseRecordAndPhysicalFile()
            throws Exception {

        Files file = createStoredFileEntity();

        Path physicalFile =
                tempDirectory.resolve(
                        file.getStoragePath());

        java.nio.file.Files.createDirectories(
                physicalFile.getParent());

        java.nio.file.Files.writeString(
                physicalFile,
                "file-content",
                StandardCharsets.UTF_8);

        assertTrue(
                java.nio.file.Files.exists(
                        physicalFile));

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(file));

        service.deleteFile("FILE001");

        assertFalse(
                java.nio.file.Files.exists(
                        physicalFile));

        verify(repository)
                .delete(file);
    }

    @Test
    void shouldThrowExceptionWhenDeletingAnotherUsersFile()
            throws Exception {

        Files file = createStoredFileEntity();

        file.setUploadedByUserId(
                "OTHER_USER");

        Path physicalFile =
                tempDirectory.resolve(
                        file.getStoragePath());

        java.nio.file.Files.createDirectories(
                physicalFile.getParent());

        java.nio.file.Files.writeString(
                physicalFile,
                "file-content",
                StandardCharsets.UTF_8);

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(file));

        assertThrows(
                CustomException.class,
                () -> service.deleteFile("FILE001"));

        assertTrue(
                java.nio.file.Files.exists(
                        physicalFile));

        verify(repository, never())
                .delete(any(Files.class));
    }

    @Test
    void shouldThrowExceptionWhenDeletingFileNotFound() {

        when(repository.findById("UNKNOWN"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.deleteFile("UNKNOWN"));

        verify(repository, never())
                .delete(any(Files.class));
    }

    @Test
    void shouldThrowExceptionWhenPhysicalFileDoesNotExistDuringDelete() {

        Files file = createStoredFileEntity();

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(file));

        assertThrows(
                NotFoundException.class,
                () -> service.deleteFile("FILE001"));

        verify(repository, never())
                .delete(any(Files.class));
    }

    @Test
    void shouldThrowExceptionWhenSecurityPrincipalIsUnavailable()
            throws Exception {

        SecurityContextHolder.clearContext();

        Files file = createStoredFileEntity();

        Path physicalFile =
                tempDirectory.resolve(
                        file.getStoragePath());

        java.nio.file.Files.createDirectories(
                physicalFile.getParent());

        java.nio.file.Files.writeString(
                physicalFile,
                "content",
                StandardCharsets.UTF_8);

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(file));

        assertThrows(
                CustomException.class,
                () -> service.deleteFile("FILE001"));

        verify(repository, never())
                .delete(any(Files.class));
    }

    @Test
    void shouldThrowExceptionWhenPrincipalHasWrongType()
            throws Exception {

        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(
                        "anonymous-user",
                        null,
                        List.of());

        SecurityContextHolder.getContext()
                .setAuthentication(authentication);

        Files file = createStoredFileEntity();

        Path physicalFile =
                tempDirectory.resolve(
                        file.getStoragePath());

        java.nio.file.Files.createDirectories(
                physicalFile.getParent());

        java.nio.file.Files.writeString(
                physicalFile,
                "content",
                StandardCharsets.UTF_8);

        when(repository.findById("FILE001"))
                .thenReturn(Optional.of(file));

        assertThrows(
                CustomException.class,
                () -> service.deleteFile("FILE001"));

        verify(repository, never())
                .delete(any(Files.class));
    }

    private FileUploadDTO createUploadDTO() {

        FileUploadDTO dto = new FileUploadDTO();

        dto.setFileType(
                FileType.PROFILE_PICTURE);

        dto.setOwnerType(
                OwnerType.USER);

        dto.setOwnerId(
                "USER001");

        return dto;
    }

    private Files createStoredFileEntity() {

        Files file = new Files();

        file.setId("FILE001");

        file.setOriginalFileName(
                "test.pdf");

        file.setStoredFileName(
                "stored-test.pdf");

        file.setFileType(
                FileType.DOCUMENT);

        file.setOwnerType(
                OwnerType.USER);

        file.setOwnerId(
                "USER001");

        file.setMimeType(
                "application/pdf");

        file.setFileSize(
                100L);

        file.setStoragePath(
                "USER/USER001/DOCUMENT/stored-test.pdf");

        file.setUploadedByUserId(
                "USER001");

        file.setCreatedAt(
                LocalDateTime.now());

        return file;
    }
}