package com.esports.BrokerApplication.auth;


import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationInterceptor
        implements HandlerInterceptor {

    private final JwtService jwtService;

    @Override
    public boolean preHandle(
            HttpServletRequest request,
            HttpServletResponse response,
            Object handler)
            throws Exception {

        String authHeader =
                request.getHeader("Authorization");

        if (authHeader == null ||
                !authHeader.startsWith("Bearer ")) {

            response.sendError(401);
            return false;
        }

        String token =
                authHeader.substring(7);

        if (!jwtService.validate(token)) {

            response.sendError(401);
            return false;
        }

        Claims claims =
                jwtService.extractClaims(token);

        String tokenType =
                claims.get("token_type", String.class);

        if (!"SERVICE".equals(tokenType)) {

            response.sendError(403);
            return false;
        }

        String serviceName =
                claims.getSubject();

        request.setAttribute(
                "servicePrincipal",
                new ServicePrincipal(serviceName));

        return true;
    }
}
