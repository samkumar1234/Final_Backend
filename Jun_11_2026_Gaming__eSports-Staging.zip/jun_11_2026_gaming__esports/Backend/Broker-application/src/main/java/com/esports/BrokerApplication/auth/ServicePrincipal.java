package com.esports.BrokerApplication.auth;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ServicePrincipal {
    private String serviceName;

}
