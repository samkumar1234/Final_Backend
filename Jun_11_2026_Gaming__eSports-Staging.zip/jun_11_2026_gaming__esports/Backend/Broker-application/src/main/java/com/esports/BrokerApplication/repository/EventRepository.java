package com.esports.BrokerApplication.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.BrokerApplication.entity.EventEntity;

public interface EventRepository
        extends JpaRepository<EventEntity, Long> {
        List<EventEntity> findByTopicAndIdGreaterThanOrderByIdAsc(
                                        String topic,
                                        Long offset);
}
