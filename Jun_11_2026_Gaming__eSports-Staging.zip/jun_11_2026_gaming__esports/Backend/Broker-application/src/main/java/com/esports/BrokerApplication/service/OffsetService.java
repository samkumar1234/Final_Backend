package com.esports.BrokerApplication.service;

import com.esports.BrokerApplication.entity.*;
import com.esports.BrokerApplication.repository.ConsumerOffsetRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OffsetService {

        private final ConsumerOffsetRepository repository;

        public void saveOffset(
                        String serviceName,
                        String topic,
                        Long offset) {

                ConsumerOffsetId id = new ConsumerOffsetId(
                                serviceName,
                                topic);

                ConsumerOffsetEntity entity = ConsumerOffsetEntity.builder()
                                .id(id)
                                .lastOffset(offset)
                                .build();

                repository.save(entity);
        }

        public Long getOffset(
                        String serviceName,
                        String topic) {

                return repository.findById(
                                new ConsumerOffsetId(
                                                serviceName,
                                                topic))
                                .map(
                                                ConsumerOffsetEntity::getLastOffset)
                                .orElse(0L);
        }
}