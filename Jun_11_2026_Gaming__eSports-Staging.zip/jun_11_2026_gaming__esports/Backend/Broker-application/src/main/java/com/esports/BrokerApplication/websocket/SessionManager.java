package com.esports.BrokerApplication.websocket;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class SessionManager {

    private final Map<String, WebSocketSession> sessions =
            new ConcurrentHashMap<>();

    public void register(
            String serviceName,
            WebSocketSession session) {

        sessions.put(serviceName, session);
    }

    public void remove(
            String serviceName) {

        sessions.remove(serviceName);
    }

    public WebSocketSession getSession(
            String serviceName) {

        return sessions.get(serviceName);
    }

    public Map<String, WebSocketSession> getSessions() {

        return sessions;
    }
}