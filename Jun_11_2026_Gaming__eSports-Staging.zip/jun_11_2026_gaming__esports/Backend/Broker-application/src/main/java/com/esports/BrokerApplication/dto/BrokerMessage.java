package com.esports.BrokerApplication.dto;


import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class BrokerMessage {
    private String userId;
    private String type;
    private String topic;
    private Long offset;
    private JsonNode payload;
}
