package com.esports.BrokerApplication.websocket;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

@Service
public class RegistrationService {

    private final Map<String, LocalDateTime> onlineServices =
            new ConcurrentHashMap<>();

    public void register(String serviceName) {

        onlineServices.put(
                serviceName,
                LocalDateTime.now());
    }

    public void disconnect(String serviceName) {

        onlineServices.remove(serviceName);
    }

    public Map<String, LocalDateTime> getOnlineServices() {

        return onlineServices;
    }
}