package com.esports.BrokerApplication.websocket;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.esports.BrokerApplication.dto.BrokerMessage;
import com.esports.BrokerApplication.entity.EventEntity;
import com.esports.BrokerApplication.service.EventService;
import com.esports.BrokerApplication.service.HeartbeatService;
import com.esports.BrokerApplication.service.OffsetService;
import com.esports.BrokerApplication.service.ReplayService;
import com.esports.BrokerApplication.service.TopicService;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class BrokerWebSocketHandler
                extends TextWebSocketHandler {

        private final SessionManager sessionManager;
        private final RegistrationService registrationService;
        private final OffsetService offsetService;
        private final EventService eventService;
        private final ReplayService replayService;
        private final TopicService topicService;
        private final HeartbeatService heartbeatService;

        private final ObjectMapper objectMapper = new ObjectMapper();

        @Override
        public void afterConnectionEstablished(
                        WebSocketSession session)
                        throws Exception {

                String serviceName =
                                  (String) session
                                        .getAttributes()
                                        .get("serviceName");

                sessionManager.register(
                                serviceName,
                                session);

                registrationService.register(
                                serviceName);

                session.sendMessage(
                                new TextMessage(
                                                "Connected to Broker"));

                System.out.println(
                                serviceName + " connected");
                heartbeatService.updateHeartbeat(serviceName);
        }

        @Override
        protected void handleTextMessage(
                        WebSocketSession session,
                        TextMessage message)
                        throws Exception {

                String serviceName =
                                  (String) session
                                        .getAttributes()
                                        .get("serviceName");

                System.out.println(
                                "MESSAGE RECEIVED: "
                                                + message.getPayload());

                BrokerMessage brokerMessage = objectMapper.readValue(
                                message.getPayload(),
                                BrokerMessage.class);

                System.out.println(
                                "TYPE: "
                                                + brokerMessage.getType());

                switch (brokerMessage.getType()) {

                        case "SUBSCRIBE" ->
                                handleSubscribe(
                                                serviceName,
                                                brokerMessage);

                        case "PUBLISH" ->
                                handlePublish(
                                                serviceName,
                                                brokerMessage);

                        case "ACK" ->
                                handleAck(
                                                serviceName,
                                                brokerMessage);
                        // case "HEARTBEAT" ->handleHeartbeat(serviceName);
                }
        }
//         private void handleHeartbeat(
//         String serviceName) {

//         heartbeatService
//                 .updateHeartbeat(
//                         serviceName);

//         System.out.println(
//                 "HEARTBEAT -> "
//                         + serviceName);
// }

        private void handleSubscribe(
                        String serviceName,
                        BrokerMessage message)
                        throws Exception {

                topicService.subscribe(
                                serviceName,
                                message.getTopic());

                replayMissedEvents(
                                serviceName,
                                message.getTopic());
        }

        private void replayMissedEvents(
                        String serviceName,
                        String topic)
                        throws Exception {

                List<EventEntity> events = replayService.replayEvents(
                                serviceName,
                                topic);

                WebSocketSession session = sessionManager.getSession(
                                serviceName);

                for (EventEntity event : events) {

                        BrokerMessage replay = new BrokerMessage();

                        replay.setType("REPLAY");

                        replay.setTopic(
                                        event.getTopic());

                        replay.setOffset(
                                        event.getId());

                        replay.setPayload(
                                        objectMapper.readTree(
                                                        event.getPayload()));

                        session.sendMessage(
                                        new TextMessage(
                                                        objectMapper.writeValueAsString(
                                                                        replay)));
                }

                System.out.println(
                                "Replayed "
                                                + events.size()
                                                + " events to "
                                                + serviceName);
        }

        private void handlePublish(
                        String publisher,
                        BrokerMessage message)
                        throws Exception {

                EventEntity savedEvent = eventService.saveEvent(
                                message.getTopic(),
                                publisher,
                                message.getPayload().toString());

                message.setOffset(
                                savedEvent.getId());

                Set<String> subscribers = topicService.getSubscribers(
                                message.getTopic());

                for (String subscriber : subscribers) {

                        WebSocketSession target = sessionManager.getSession(
                                        subscriber);

                        if (target != null &&
                                        target.isOpen()) {

                                target.sendMessage(
                                                new TextMessage(
                                                                objectMapper.writeValueAsString(
                                                                                message)));
                        }
                }

                System.out.println(
                                "Stored Event Offset = "
                                                + savedEvent.getId());
        }

        @Override
        public void afterConnectionClosed(
                        WebSocketSession session,
                        CloseStatus status) {

                String serviceName =
                                  (String) session
                                        .getAttributes()
                                        .get("serviceName");

                sessionManager.remove(
                                serviceName);

                registrationService.disconnect(
                                serviceName);

                System.out.println(
                                serviceName
                                                + " disconnected");
        }

        private void handleAck(
                        String serviceName,
                        BrokerMessage message) {

                offsetService.saveOffset(
                                serviceName,
                                message.getTopic(),
                                message.getOffset());

                System.out.println(
                                serviceName +
                                                " ACKED offset " +
                                                message.getOffset());
        }

}