package com.esports.BrokerApplication.entity;

import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class ConsumerOffsetId
        implements Serializable {

    private String serviceName;

    private String topic;
}