package com.esports.BrokerApplication.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class TopicService {

        private final Map<String, Set<String>> subscriptions = new ConcurrentHashMap<>();

        public void subscribe(
                        String serviceName,
                        String topic) {

                subscriptions
                                .computeIfAbsent(
                                                topic,
                                                k -> ConcurrentHashMap.newKeySet())
                                .add(serviceName);

                log.info(
                                "{} subscribed to {}",
                                serviceName,
                                topic);
        }

        public Set<String> getSubscribers(
                        String topic) {

                return subscriptions.getOrDefault(
                                topic,
                                Set.of());
        }

        public Map<String, Set<String>> getAllTopics() {

                return subscriptions;
        }

        public Set<String> getTopicsForService(
                        String serviceName) {
                Set<String> topics = new HashSet<>();
                subscriptions.forEach((topic, services) -> {

                        if (services.contains(serviceName)) {

                                topics.add(topic);
                        }
                });

                return topics;
        }
}
