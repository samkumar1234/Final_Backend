package com.esports.BrokerApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.BrokerApplication.entity.RegisteredServiceEntity;

public interface RegisteredServiceRepository
        extends JpaRepository<
                RegisteredServiceEntity,
                String> {
}
