package com.esports.BrokerApplication.service;

import com.esports.BrokerApplication.entity.EventEntity;
import com.esports.BrokerApplication.repository.EventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class EventService {

    private final EventRepository eventRepository;

    public EventEntity saveEvent(
            String topic,
            String publisher,
            String payload) {

        EventEntity event =
                EventEntity.builder()
                        .topic(topic)
                        .publisher(publisher)
                        .payload(payload)
                        .createdAt(LocalDateTime.now())
                        .build();

        return eventRepository.save(event);
    }
}