package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentAnnouncementRequestDTO {
    private String title;
    private String content;
    private String tournamentId;
}