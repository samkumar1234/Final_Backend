package com.esports.project.DTO;

import java.math.BigDecimal;

import com.esports.project.enums.PriceCategory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentPriceUpdateDTO {

    private PriceCategory prizeCategory;

    private Integer rankOrder;

    private BigDecimal prizeAmount;

    private String prizeDescription;
}
