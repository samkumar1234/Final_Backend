package com.esports.project.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.project.entity.TeamInvitation;
import com.esports.project.enums.InvitationStatus;

public interface TeamInvitationRepository
        extends JpaRepository<TeamInvitation, String> {

    List<TeamInvitation> findByTeamIdOrderBySentAtDesc(
            String teamId
    );

    List<TeamInvitation> findByReceiverIdOrderBySentAtDesc(
            String receiverId
    );

    List<TeamInvitation> findByStatusOrderBySentAtDesc(
            InvitationStatus status
    );

    List<TeamInvitation> findByTeamIdAndStatusOrderBySentAtDesc(
            String teamId,
            InvitationStatus status
    );

    List<TeamInvitation> findByReceiverIdAndStatusOrderBySentAtDesc(
            String receiverId,
            InvitationStatus status
    );

    boolean existsByTeamIdAndReceiverIdAndStatus(
            String teamId,
            String receiverId,
            InvitationStatus status
    );

    Optional<TeamInvitation> findByIdAndReceiverId(
            String invitationId,
            String receiverId
    );

    Optional<TeamInvitation> findByIdAndSenderId(
            String invitationId,
            String senderId
    );
}