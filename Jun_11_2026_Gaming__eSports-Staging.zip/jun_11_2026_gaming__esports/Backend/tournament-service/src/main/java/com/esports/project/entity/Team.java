package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "teams", 
        uniqueConstraints = {
             @UniqueConstraint(
            name = "uk_team",
            columnNames = {
                "tournament_id",
                "user_id"
            }
        )
        },
        indexes = {
        @Index(name = "idx_team_user_id", columnList = "user_id")
})
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "team_name", nullable = false, length = 100)
    private String teamName;

    @Column(name = "file_id")
    private String fileId;

    /*
     * Team owner or team leader ID.
     */
    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "tournament_id", nullable = false)
    private String tournamentId;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    /*
     * Current team members.
     */
    @OneToMany(mappedBy = "team", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @JsonManagedReference(value = "team-members")
    private List<TeamMember> teamMembers = new ArrayList<>();

    /*
     * A team can have multiple registrations because it can
     * register for different tournaments.
     *
     * The tournament registration table prevents this team
     * from registering twice for the same tournament.
     */
    @OneToMany(mappedBy = "team", fetch = FetchType.LAZY)
    @JsonManagedReference(value = "team-registration")
    private List<TournamentRegistration> tournamentRegistrations = new ArrayList<>();

    @PrePersist
    public void onCreate() {
        LocalDateTime now = LocalDateTime.now();

        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public void addTeamMember(
            TeamMember teamMember) {
        teamMembers.add(teamMember);
        teamMember.setTeam(this);
    }

    public void removeTeamMember(
            TeamMember teamMember) {
        teamMembers.remove(teamMember);
        teamMember.setTeam(null);
    }
}