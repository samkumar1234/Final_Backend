package com.esports.project.DTO;

import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.StatusMaster;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRegistrationResponseDTO {

    private String id;

    private String tournamentId;

    private String teamId;

    private String teamName;

    private String registeredBy;

    private StatusMaster registrationStatus;

    private LocalDateTime registrationDate;

    private LocalDateTime respondedAt;

    private String rejectionReason;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
    private List<TournamentRegistrationParticipantDTO> participants;
}