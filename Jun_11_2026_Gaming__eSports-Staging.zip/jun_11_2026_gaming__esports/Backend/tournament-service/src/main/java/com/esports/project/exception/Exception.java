package com.esports.project.exception;

public class Exception extends CustomException {
    public Exception(String message){
        super(message);
    }
}
