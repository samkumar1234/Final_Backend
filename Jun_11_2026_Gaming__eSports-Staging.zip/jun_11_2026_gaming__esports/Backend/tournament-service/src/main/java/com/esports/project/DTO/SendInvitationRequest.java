package com.esports.project.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class SendInvitationRequest{

    @NotBlank(message = "Receiver ID is required")
    private String receiverId;

    @NotBlank(message = "Receiver name is required")
    @Size(
        max = 100,
        message = "Receiver name cannot exceed 100 characters"
    )
    private String receiverName;
}