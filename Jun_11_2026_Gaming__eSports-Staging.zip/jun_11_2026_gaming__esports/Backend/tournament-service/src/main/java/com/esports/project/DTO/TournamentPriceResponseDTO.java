package com.esports.project.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.PriceCategory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentPriceResponseDTO {

    private String id;

    private PriceCategory prizeCategory;

    private Integer rankOrder;

    private BigDecimal prizeAmount;

    private String prizeDescription;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private String tournamentId;

    private String tournamentName;
}
