package com.esports.project.enums;

public enum TournamentType {
    SINGLE_ELIMINATION(TournamentCategory.BRACKETS),
    DOUBLE_ELIMINATION(TournamentCategory.BRACKETS),
    ROUND_ROBIN(TournamentCategory.BRACKETS),
    POINT(TournamentCategory.LEADERBOARD),
    RANK(TournamentCategory.LEADERBOARD);

    private final TournamentCategory category;

    TournamentType(TournamentCategory category) {
            this.category = category;
        }
    
        public String getCategory(){
        return category.toString();
    }
}
