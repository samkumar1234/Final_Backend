package com.esports.project.DTO;

import java.util.List;

import lombok.Data;

@Data
public class ParticipantDetails{

    public ParticipantDetails(String teamId,List<String> participantIds){
        this.teamId = teamId;
        this.participantIds = participantIds;
    }
    private String teamId;
    private List<String> participantIds;
}
