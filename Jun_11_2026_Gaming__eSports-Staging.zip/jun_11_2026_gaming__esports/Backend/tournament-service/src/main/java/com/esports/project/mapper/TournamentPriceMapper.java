package com.esports.project.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.TournamentPriceRequestDTO;
import com.esports.project.DTO.TournamentPriceResponseDTO;
import com.esports.project.DTO.TournamentPriceUpdateDTO;
import com.esports.project.entity.TournamentPrice;

@Mapper(
    componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface TournamentPriceMapper {

    TournamentPrice toEntity(
            TournamentPriceRequestDTO dto);

    @Mapping(target = "tournamentId",
            source = "tournament.id")
    @Mapping(target = "tournamentName",
            source = "tournament.name")
    TournamentPriceResponseDTO toResponseDTO(
            TournamentPrice price);

    void updatePriceFromDTO(
            TournamentPriceUpdateDTO dto,
            @MappingTarget TournamentPrice price);
}