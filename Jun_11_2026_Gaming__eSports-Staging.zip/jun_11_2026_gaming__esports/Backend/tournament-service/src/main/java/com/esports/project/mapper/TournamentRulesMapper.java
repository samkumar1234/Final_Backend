package com.esports.project.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.TournamentRulesRequestDTO;
import com.esports.project.DTO.TournamentRulesResponseDTO;
import com.esports.project.DTO.TournamentRulesUpdateDTO;
import com.esports.project.entity.TournamentRules;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TournamentRulesMapper {

    TournamentRules toEntity(
            TournamentRulesRequestDTO dto);

    @Mapping(
            target = "tournamentId",
            source = "tournament.id")
    @Mapping(
            target = "tournamentName",
            source = "tournament.name")
    TournamentRulesResponseDTO toResponseDTO(
            TournamentRules rule);

    void updateRuleFromDTO(
            TournamentRulesUpdateDTO dto,
            @MappingTarget TournamentRules rule);
}