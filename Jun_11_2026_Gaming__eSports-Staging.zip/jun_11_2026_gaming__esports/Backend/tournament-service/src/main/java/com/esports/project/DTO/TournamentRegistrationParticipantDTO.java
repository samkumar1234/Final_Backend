package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.enums.TeamPosition;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TournamentRegistrationParticipantDTO {

    private String id;

    private String tournamentId;

    private String registrationId;

    private String teamId;

    private String userId;

    private String username;

    private TeamPosition teamPosition;

    private LocalDateTime createdAt;
}