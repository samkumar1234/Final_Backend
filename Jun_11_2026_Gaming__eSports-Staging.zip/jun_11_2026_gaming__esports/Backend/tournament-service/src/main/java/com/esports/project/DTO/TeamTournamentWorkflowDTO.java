package com.esports.project.DTO;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.esports.project.enums.TeamPosition;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TeamTournamentWorkflowDTO {

    private String id;

    private String tournamentId;

    private String teamName;

    private String fileId;

    private String leaderId;

    private String leaderName;

    private TeamPosition currentUserPosition;

    private Integer totalMembers;

    private List<TeamMemberDTO> members =
            new ArrayList<>();

    private List<TeamInvitationDTO> invitations =
            new ArrayList<>();

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
}