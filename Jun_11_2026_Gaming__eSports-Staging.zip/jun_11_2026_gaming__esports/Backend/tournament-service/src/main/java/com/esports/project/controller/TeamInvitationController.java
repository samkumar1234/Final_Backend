package com.esports.project.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.SendInvitationRequest;
import com.esports.project.DTO.TeamInvitationDTO;
import com.esports.project.DTO.UpdateInvitationStatusRequest;
import com.esports.project.enums.InvitationStatus;
import com.esports.project.service.TeamInvitationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/teams")
@Validated
public class TeamInvitationController {

    private final TeamInvitationService
            teamInvitationService;

    public TeamInvitationController(
            TeamInvitationService teamInvitationService
    ) {
        this.teamInvitationService =
                teamInvitationService;
    }

    // @PreAuthorize("hasAuthority('PLAYER')")
    @PostMapping("/{teamId}/invitations")
    @ResponseStatus(HttpStatus.CREATED)
    public TeamInvitationDTO sendInvitation(
            @PathVariable String teamId,

            @Valid
            @RequestBody
            SendInvitationRequest request
    ) {
        return teamInvitationService.sendInvitation(
                teamId,
                request
        );
    }

    /*
     * Only the team owner can view invitations
     * associated with the team.
     *
     * Examples:
     * GET /teams/{teamId}/invitations
     * GET /teams/{teamId}/invitations?status=PENDING
     */
    @GetMapping("/{teamId}/invitations")
    public List<TeamInvitationDTO> getTeamInvitations(
            @PathVariable String teamId,

            @RequestParam(required = false)
            InvitationStatus status
    ) {
        return teamInvitationService.getTeamInvitations(
                teamId,
                status
        );
    }

    /*
     * Returns invitations received by the
     * currently authenticated user.
     *
     * Examples:
     * GET /teams/invitations/my
     * GET /teams/invitations/my?status=PENDING
     */
    @GetMapping("/invitations/my")
    public List<TeamInvitationDTO> getMyInvitations(
            @RequestParam(required = false)
            InvitationStatus status
    ) {
        return teamInvitationService.getMyInvitations(
                status
        );
    }

    /*
     * Only the invitation receiver can accept
     * or reject an invitation.
     */
    // @PreAuthorize("hasAuthority('PLAYER')")
    @PatchMapping("/invitations/{invitationId}/status")
    public TeamInvitationDTO updateInvitationStatus(
            @PathVariable String invitationId,
            @Valid
            @RequestBody
            UpdateInvitationStatusRequest request
    ) {
        return teamInvitationService.updateInvitationStatus(
                invitationId,
                request
        );
    }

    /*
     * Only the invitation sender can delete
     * a pending invitation.
     */
    // @PreAuthorize("hasAuthority('PLAYER')")
    @DeleteMapping("/invitations/{invitationId}")
    public ResponseEntity<Void> deleteInvitation(
            @PathVariable String invitationId
    ) {
        teamInvitationService.deleteInvitation(
                invitationId
        );

        return ResponseEntity.noContent().build();
    }
}