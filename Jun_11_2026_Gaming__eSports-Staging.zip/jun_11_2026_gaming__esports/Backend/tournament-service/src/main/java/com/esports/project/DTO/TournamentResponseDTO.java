package com.esports.project.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.SeedType;
import com.esports.project.enums.StatusMaster;
import com.esports.project.enums.TournamentCategory;
import com.esports.project.enums.TournamentType;
import com.esports.project.enums.TournamentVerification;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentResponseDTO {

    private String id;
    private String name;
    private String description;

    private LocalDateTime registrationStartDate;
    private LocalDateTime registrationEndDate;

    private LocalDateTime tournamentStartDate;
    private LocalDateTime tournamentEndDate;

    private TournamentCategory tournamentCategory;
    private TournamentType tournamentType;

    private Integer maximumTeams;
    private Integer maximumPlayersPerTeam;

    private SeedType seedingTypeId;
    private BigDecimal entryFee;

    private TournamentVerification verificationRequired;

    private StatusMaster status;

    private Boolean isLocked;
    private Boolean isDeleted;

    private String userId;
    private String fileId;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}