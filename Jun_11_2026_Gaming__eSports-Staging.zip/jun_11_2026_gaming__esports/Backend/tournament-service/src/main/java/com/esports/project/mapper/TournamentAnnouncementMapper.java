package com.esports.project.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.TournamentAnnouncementRequestDTO;
import com.esports.project.DTO.TournamentAnnouncementResponseDTO;
import com.esports.project.DTO.TournamentAnnouncementUpdateDTO;
import com.esports.project.entity.TournamentAnnouncement;

@Mapper(
    componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface TournamentAnnouncementMapper {

    TournamentAnnouncement toEntity(
            TournamentAnnouncementRequestDTO dto);

    @Mapping(target = "tournamentId", source = "tournament.id")
    @Mapping(target = "tournamentName", source = "tournament.name")
    TournamentAnnouncementResponseDTO toResponseDTO(
            TournamentAnnouncement announcement);

    void updateAnnouncementFromDto(
            TournamentAnnouncementUpdateDTO dto,
            @MappingTarget TournamentAnnouncement announcement);
}