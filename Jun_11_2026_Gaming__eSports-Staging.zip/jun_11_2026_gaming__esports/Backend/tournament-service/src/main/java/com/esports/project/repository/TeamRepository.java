package com.esports.project.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.esports.project.entity.Team;

public interface TeamRepository extends JpaRepository<Team, String> {

    boolean existsByTeamNameIgnoreCase(String teamName);

    boolean existsByTeamNameIgnoreCaseAndIdNot(
            String teamName,
            String id
    );

    Page<Team> findByTeamNameContainingIgnoreCase(
            String teamName,
            Pageable pageable
    );

    List<Team> findByUserIdOrderByCreatedAtDesc(
            String userId
    );

    Optional<Team> findByIdAndUserId(
            String teamId,
            String userId
    );

    @Query("""
                    SELECT DISTINCT team
                    FROM Team team
                    LEFT JOIN FETCH team.teamMembers member
                    WHERE team.tournamentId = :tournamentId
                    AND team.userId = :userId
                    """)
    Optional<Team> findMyTournamentTeamWithMembers(
                    @Param("tournamentId") String tournamentId,
                    @Param("userId") String userId

    );
}