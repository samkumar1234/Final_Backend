package com.esports.project.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.SeedType;
import com.esports.project.enums.TournamentCategory;
import com.esports.project.enums.TournamentType;
import com.esports.project.enums.TournamentVerification;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRequestDTO {

    @NotBlank(message = "Tournament name is required")
    private String name;

    @NotBlank(message = "Description is required")
    private String description;

    @NotNull(message = "Registration start date is required")
    private LocalDateTime registrationStartDate;

    @NotNull(message = "Registration end date is required")
    private LocalDateTime registrationEndDate;

    @NotNull(message = "Tournament start date is required")
    private LocalDateTime tournamentStartDate;

    @NotNull(message = "Tournament end date is required")
    private LocalDateTime tournamentEndDate;

    @NotNull(message = "Tournament category is required")
    private TournamentCategory tournamentCategory;

    @NotNull(message = "Tournament type is required")
    private TournamentType tournamentType;

    @NotNull(message = "Maximum teams is required")
    @Min(value = 2, message = "Minimum 2 teams required")
    private Integer maximumTeams;

    @NotNull(message = "Maximum players per team is required")
    @Min(value = 1, message = "Minimum 1 player required")
    private Integer maximumPlayersPerTeam;

    @NotNull(message = "Seeding type is required")
    private SeedType seedingTypeId;

    @NotNull(message = "Entry fee is required")
    @DecimalMin(value = "0.0", message = "Entry fee cannot be negative")
    private BigDecimal entryFee;

    @NotNull(message = "Verification type is required")
    private TournamentVerification verificationRequired;

    private String fileId;
}