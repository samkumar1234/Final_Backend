package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.enums.InvitationStatus;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TeamInvitationDTO{

    private  String id;

    private  String teamId;

    private String teamName;

    private String senderId;

    private String senderName;

    private String receiverId;

    private String receiverName;

    private InvitationStatus status;

    private LocalDateTime sentAt;

    private LocalDateTime respondedAt;
}