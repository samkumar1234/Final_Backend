package com.esports.project.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
@Data
public class CreateTeamRequest{

    @NotBlank(message = "Team name is required")
    @Size(
        min = 3,
        max = 100,
        message = "Team name must contain between 3 and 100 characters"
    )
    private String teamName;

    @NotBlank(message = "Tournament Id is required")
    @Size(
        min = 3,
        max = 100,
        message = "Tournament ID must contain between 3 and 100 characters"
    )
    private String tournamentId;

    @Size(
        max = 255,
        message = "File ID cannot exceed 255 characters"
    )
    private String fileId = "test file";

}