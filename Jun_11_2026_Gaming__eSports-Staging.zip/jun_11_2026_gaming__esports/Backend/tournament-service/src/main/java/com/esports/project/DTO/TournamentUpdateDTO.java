package com.esports.project.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.SeedType;
import com.esports.project.enums.TournamentVerification;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentUpdateDTO {

    private String name;
    private String description;

    private LocalDateTime registrationEndDate;

    private LocalDateTime tournamentStartDate;
    private LocalDateTime tournamentEndDate;

    private Integer maximumTeams;
    private Integer maximumPlayersPerTeam;

    private BigDecimal entryFee;

    private SeedType seedingTypeId;

    private TournamentVerification verificationRequired;

    private String fileId;
}
