package com.esports.project.mapper;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.TournamentRegistrationRequestDTO;
import com.esports.project.DTO.TournamentRegistrationResponseDTO;
import com.esports.project.DTO.TournamentRegistrationUpdateDTO;
import com.esports.project.entity.TournamentRegistration;

@Mapper(
    componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE,
    uses = {
        TournamentRegistrationParticipantMapper.class
    }
)
public interface TournamentRegistrationMapper {

    /*
     * Tournament, team, and participants are loaded and assigned
     * inside the service.
     */
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "tournament", ignore = true)
    @Mapping(target = "team", ignore = true)
    @Mapping(target = "participants", ignore = true)
    @Mapping(target = "registeredBy", ignore = true)
    @Mapping(target = "registrationStatus", ignore = true)
    @Mapping(target = "registrationDate", ignore = true)
    @Mapping(target = "respondedAt", ignore = true)
    @Mapping(target = "rejectionReason", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    TournamentRegistration toEntity(
            TournamentRegistrationRequestDTO dto
    );

    @Mapping(
        target = "tournamentId",
        source = "tournament.id"
    )
    @Mapping(
        target = "teamId",
        source = "team.id"
    )
    @Mapping(
        target = "teamName",
        source = "team.teamName"
    )
    TournamentRegistrationResponseDTO toResponseDTO(
            TournamentRegistration registration
    );

    @BeanMapping(
        nullValuePropertyMappingStrategy =
                NullValuePropertyMappingStrategy.IGNORE
    )
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "tournament", ignore = true)
    @Mapping(target = "team", ignore = true)
    @Mapping(target = "participants", ignore = true)
    @Mapping(target = "registeredBy", ignore = true)
    @Mapping(target = "registrationStatus", ignore = true)
    @Mapping(target = "registrationDate", ignore = true)
    @Mapping(target = "respondedAt", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    void updateRegistrationFromDTO(
            TournamentRegistrationUpdateDTO dto,
            @MappingTarget TournamentRegistration registration
    );
}