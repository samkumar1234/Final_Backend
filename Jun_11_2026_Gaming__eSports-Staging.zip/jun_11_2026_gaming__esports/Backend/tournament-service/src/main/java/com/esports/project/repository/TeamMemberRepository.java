package com.esports.project.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.Team;
import com.esports.project.entity.TeamMember;

@Repository
public interface TeamMemberRepository
        extends JpaRepository<TeamMember, String> {

    /*
     * Find all members belonging to a Team entity.
     */
    List<TeamMember> findByTeam(
            Team team
    );

    /*
     * Find all members using the team's ID.
     *
     * TeamMember.team.id
     */
    List<TeamMember> findByTeam_Id(
            String teamId
    );

    /*
     * Check whether a particular user is already
     * a member of the specified team.
     */
    boolean existsByTeam_IdAndUserId(
            String teamId,
            String userId
    );

    /*
     * Return a team member by team ID and user ID.
     */
    Optional<TeamMember> findByTeam_IdAndUserId(
            String teamId,
            String userId
    );

    /*
     * Count members in a team.
     */
    long countByTeam_Id(
            String teamId
    );

    /*
     * Find all teams where a user is a member.
     */
    List<TeamMember> findByUserId(
            String userId
    );

    /*
     * Search members by username.
     */
    List<TeamMember> findByUsernameContainingIgnoreCase(
            String username
    );

    /*
     * Find multiple members of a specified team.
     * Useful for bulk membership validation.
     */
    List<TeamMember> findByTeam_IdAndUserIdIn(
            String teamId,
            Collection<String> userIds
    );

    /*
     * Check whether any of the supplied users
     * belongs to the specified team.
     */
    boolean existsByTeam_IdAndUserIdIn(
            String teamId,
            Collection<String> userIds
    );

    /*
     * Delete a particular user from a team.
     */
    void deleteByTeam_IdAndUserId(
            String teamId,
            String userId
    );
}