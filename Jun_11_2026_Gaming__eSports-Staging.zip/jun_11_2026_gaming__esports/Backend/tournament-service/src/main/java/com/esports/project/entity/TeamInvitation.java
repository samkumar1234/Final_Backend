package com.esports.project.entity;

import java.time.LocalDateTime;

import com.esports.project.enums.InvitationStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(
    name = "team_invitations",
    indexes = {
        @Index(
            name = "idx_invitation_team_id",
            columnList = "team_id"
        ),
        @Index(
            name = "idx_invitation_receiver_id",
            columnList = "receiver_id"
        ),
        @Index(
            name = "idx_invitation_status",
            columnList = "status"
        )
    }
)
public class TeamInvitation {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "team_id", nullable = false)
    private String teamId;

    @Column(name = "team_name", nullable = false)
    private String teamName;

    @Column(name = "sender_id", nullable = false)
    private String senderId;

    @Column(name = "sender_name", nullable = false)
    private String senderName;

    @Column(name = "receiver_id", nullable = false)
    private String receiverId;

    @Column(name = "receiver_name", nullable = false)
    private String receiverName;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private InvitationStatus status;

    @Column(name = "sent_at", nullable = false, updatable = false)
    private LocalDateTime sentAt;

    @Column(name = "responded_at")
    private LocalDateTime respondedAt;

    @PrePersist
    public void onCreate() {
        if (sentAt == null) {
            sentAt = LocalDateTime.now();
        }

        if (status == null) {
            status = InvitationStatus.PENDING;
        }
    }
}