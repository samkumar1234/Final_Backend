package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class MyTournamentTeamResponse {

    private Boolean teamExists;
    private TeamTournamentWorkflowDTO team;

}