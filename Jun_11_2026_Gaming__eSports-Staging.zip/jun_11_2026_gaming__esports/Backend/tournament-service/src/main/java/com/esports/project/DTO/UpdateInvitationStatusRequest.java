package com.esports.project.DTO;

import com.esports.project.enums.InvitationStatus;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UpdateInvitationStatusRequest{

    @NotNull(message = "Invitation status is required")
    private InvitationStatus status;

}