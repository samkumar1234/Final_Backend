package com.esports.project.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentRegistrationRequestDTO;
import com.esports.project.DTO.TournamentRegistrationResponseDTO;
import com.esports.project.DTO.TournamentRegistrationUpdateDTO;
import com.esports.project.enums.StatusMaster;
import com.esports.project.service.TournamentRegistrationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tournament/registration")
public class TournamentRegistrationController {

    private final TournamentRegistrationService tournamentRegistrationService;

    public TournamentRegistrationController(
            TournamentRegistrationService tournamentRegistrationService) {
        this.tournamentRegistrationService = tournamentRegistrationService;
    }

    /*
     * Register Team For Tournament
     */
    @PostMapping
//     @PreAuthorize("hasAuthority('TOURNAMENT_REGISTRATION_CREATE')")
    public ResponseEntity<TournamentRegistrationResponseDTO> createRegistration(
            @Valid @RequestBody TournamentRegistrationRequestDTO requestDTO) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tournamentRegistrationService
                        .createRegistration(requestDTO));
    }

    /*
     * Get Registration By Id
     */
    @GetMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_REGISTRATION_VIEW')")
    public ResponseEntity<TournamentRegistrationResponseDTO> getRegistrationById(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentRegistrationService
                        .getRegistrationById(id));
    }

    /*
     * Get All Registrations For A Tournament
     */
    @GetMapping("/tournament/{tournamentId}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_REGISTRATION_VIEW')")
    public ResponseEntity<List<TournamentRegistrationResponseDTO>>
            getTournamentRegistrations(
                    @PathVariable String tournamentId) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentRegistrationService
                        .getTournamentRegistrations(tournamentId));
    }

    /*
     * Update Registration Status
     * (APPROVED / REJECTED / ACTIVE etc.)
     */
    @PatchMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_REGISTRATION_UPDATE')")
    public ResponseEntity<TournamentRegistrationResponseDTO>
            updateRegistration(
                    @PathVariable String id,
                    @RequestBody TournamentRegistrationUpdateDTO updateDTO) {

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(tournamentRegistrationService
                        .updateRegistration(
                                id,
                                updateDTO));
    }

    /*
     * Delete Registration
     */
    @DeleteMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_REGISTRATION_DELETE')")
    public ResponseEntity<ResponseDTO> deleteRegistration(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentRegistrationService
                        .deleteRegistration(id));
    }

    /*
     * Filter Registrations
     */
    @GetMapping("/filter")
//     @PreAuthorize("hasAuthority('TOURNAMENT_REGISTRATION_VIEW')")
    public Page<TournamentRegistrationResponseDTO> filterRegistrations(

            @RequestParam(required = false) String tournamentId,

            @RequestParam(required = false) String teamId,

            @RequestParam(required = false) String registrationStatus,

            @RequestParam(defaultValue = "0") int page,

            @RequestParam(defaultValue = "10") int size) {

        return tournamentRegistrationService
                .filterRegistrations(
                        tournamentId,
                        teamId,
                        registrationStatus,
                        PageRequest.of(page, size));
    }

    @GetMapping("/update-status/{id}")
    public ResponseEntity<ResponseDTO> updateStatus(@PathVariable String id,@RequestParam(required = true) StatusMaster status){
        return ResponseEntity.status(HttpStatus.OK).body(tournamentRegistrationService.updateStatus(status, id));
    }
}
