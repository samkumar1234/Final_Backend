package com.esports.project.DTO;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WebSocketInfoResponse {

    private String websocketUrl;
    private String service;
    private String publishDestination;
    private String subscribeDestination;
    private boolean jwtRequired;
}
