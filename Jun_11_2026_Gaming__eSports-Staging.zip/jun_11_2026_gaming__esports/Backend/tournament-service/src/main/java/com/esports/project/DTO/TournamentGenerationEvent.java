package com.esports.project.DTO;


import java.util.ArrayList;
import java.util.List;

import com.esports.project.enums.SeedType;
import com.esports.project.enums.TournamentType;

import lombok.Data;

@Data
public class TournamentGenerationEvent {

    public TournamentGenerationEvent(String id, SeedType seedingTypeId, TournamentType tournamentType,String tournamentName) {
        this.tournamentId = id;
        this.seedType = seedingTypeId;
        this.tournamentType = tournamentType;
        this.tournamentName = tournamentName;
    }
    private String tournamentId;
    private String tournamentName;
    private SeedType seedType;
    private TournamentType tournamentType;
    private List<ParticipantDetails> participants = new ArrayList<>();

}

