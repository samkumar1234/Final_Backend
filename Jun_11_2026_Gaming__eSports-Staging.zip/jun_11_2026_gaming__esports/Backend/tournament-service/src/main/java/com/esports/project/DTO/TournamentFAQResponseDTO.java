package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.enums.StatusMaster;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentFAQResponseDTO {

    private String id;

    private String question;

    private String answer;

    private StatusMaster status;

    private String userId;

    private String tournamentId;

    private String tournamentName;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
}