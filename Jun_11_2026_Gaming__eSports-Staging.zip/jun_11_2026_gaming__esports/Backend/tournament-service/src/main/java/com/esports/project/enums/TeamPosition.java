package com.esports.project.enums;

public enum TeamPosition {
    LEADER,
    MEMBER
}
