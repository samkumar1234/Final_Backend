package com.esports.project.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.TournamentRegistrationParticipantDTO;
import com.esports.project.entity.TournamentRegistrationParticipant;

@Mapper(
    componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface TournamentRegistrationParticipantMapper {

    @Mapping(
        target = "registrationId",
        source = "registration.id"
    )
    TournamentRegistrationParticipantDTO toResponseDTO(
            TournamentRegistrationParticipant participant
    );

    List<TournamentRegistrationParticipantDTO> toResponseDTOList(
            List<TournamentRegistrationParticipant> participants
    );
}