package com.esports.project.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentFAQRequestDTO;
import com.esports.project.DTO.TournamentFAQResponseDTO;
import com.esports.project.DTO.TournamentFAQUpdateDTO;
import com.esports.project.service.TournamentFAQService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tournament/faq")
public class TournamentFAQController {

    private final TournamentFAQService tournamentFAQService;

    public TournamentFAQController(
            TournamentFAQService tournamentFAQService) {
        this.tournamentFAQService = tournamentFAQService;
    }

    /*
     * Create FAQ Question
     * Tournament registered users can create questions.
     */
    @PostMapping
//     @PreAuthorize("hasAuthority('TOURNAMENT_FAQ_CREATE')")
    public ResponseEntity<TournamentFAQResponseDTO> createFAQ(
            @Valid @RequestBody TournamentFAQRequestDTO requestDTO) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tournamentFAQService.createFAQ(requestDTO));
    }

    /*
     * Get FAQ By Id
     */
    @GetMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_FAQ_VIEW')")
    public ResponseEntity<TournamentFAQResponseDTO> getFAQById(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentFAQService.getFAQById(id));
    }

    /*
     * Get All FAQs For A Tournament
     */
    @GetMapping("/tournament/{tournamentId}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_FAQ_VIEW')")
    public ResponseEntity<Page<TournamentFAQResponseDTO>>
            getTournamentFAQs(
                    @PathVariable String tournamentId,
                    @RequestParam(defaultValue = "0") int page,
                    @RequestParam(defaultValue = "10") int size) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentFAQService.getTournamentFAQs(
                        tournamentId,
                        PageRequest.of(page, size)));
    }

    /*
     * Tournament Host Answers FAQ
     */
    @PatchMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_FAQ_ANSWER')")
    public ResponseEntity<TournamentFAQResponseDTO> answerFAQ(
            @PathVariable String id,
            @RequestBody TournamentFAQUpdateDTO updateDTO) {

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(tournamentFAQService.answerFAQ(
                        id,
                        updateDTO));
    }

    /*
     * Delete FAQ
     */
    @DeleteMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_FAQ_DELETE')")
    public ResponseEntity<ResponseDTO> deleteFAQ(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentFAQService.deleteFAQ(id));
    }

    /*
     * Filter FAQs
     */
    @GetMapping("/filter")
//     @PreAuthorize("hasAuthority('TOURNAMENT_FAQ_VIEW')")
    public Page<TournamentFAQResponseDTO> filterFAQ(
            @RequestParam(required = false) String tournamentId,
            @RequestParam(required = false) String question,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return tournamentFAQService.filterFAQ(
                tournamentId,
                question,
                status,
                PageRequest.of(page, size));
    }
}