package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(
    name = "tournament_registrations",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_registration_tournament_team",
            columnNames = {
                "tournament_id",
                "team_id"
            }
        )
    },
    indexes = {
        @Index(
            name = "idx_registration_tournament_id",
            columnList = "tournament_id"
        ),
        @Index(
            name = "idx_registration_team_id",
            columnList = "team_id"
        ),
        @Index(
            name = "idx_registration_status",
            columnList = "registration_status"
        )
    }
)
public class TournamentRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    @Column(
        name = "registration_status",
        nullable = false
    )
    private StatusMaster registrationStatus;

    @Column(
        name = "registration_date",
        nullable = false,
        updatable = false
    )
    private LocalDateTime registrationDate;

    @Column(
        name = "created_at",
        nullable = false,
        updatable = false
    )
    private LocalDateTime createdAt;

    @Column(
        name = "updated_at",
        nullable = false
    )
    private LocalDateTime updatedAt;

    /*
     * The user who submitted the team registration.
     */
    @Column(
        name = "registered_by",
        nullable = false
    )
    private String registeredBy;

    /*
     * Optional organizer response information.
     */
    @Column(name = "responded_at")
    private LocalDateTime respondedAt;

    @Column(
        name = "rejection_reason",
        length = 500
    )
    private String rejectionReason;

    /*
     * Multiple registrations can belong to one tournament.
     */
    @ManyToOne(
        fetch = FetchType.LAZY,
        optional = false
    )
    @JoinColumn(
        name = "tournament_id",
        nullable = false
    )
    @JsonBackReference(value = "tournament-registration")
    private Tournament tournament;

    /*
     * Multiple tournament registrations can belong to one team.
     *
     * A team can register for different tournaments, but the
     * unique constraint prevents the same team from registering
     * twice for the same tournament.
     */
    @ManyToOne(
        fetch = FetchType.LAZY,
        optional = false
    )
    @JoinColumn(
        name = "team_id",
        nullable = false
    )
    @JsonBackReference(value = "team-registration")
    private Team team;

    /*
     * Snapshot of the users included in this registration.
     */
    @OneToMany(
        mappedBy = "registration",
        cascade = CascadeType.ALL,
        orphanRemoval = true,
        fetch = FetchType.LAZY
    )
    @JsonManagedReference(value = "registration-participants")
    private List<TournamentRegistrationParticipant> participants =
            new ArrayList<>();

    @PrePersist
    public void onCreate() {
        LocalDateTime now = LocalDateTime.now();

        if (registrationDate == null) {
            registrationDate = now;
        }

        if (createdAt == null) {
            createdAt = now;
        }

        updatedAt = now;

        /*
         * Replace PENDING if your StatusMaster uses
         * another constant such as REQUESTED.
         */
        if (registrationStatus == null) {
            registrationStatus = StatusMaster.PENDING;
        }
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public void addParticipant(
            TournamentRegistrationParticipant participant
    ) {
        participants.add(participant);
        participant.setRegistration(this);
    }

    public void removeParticipant(
            TournamentRegistrationParticipant participant
    ) {
        participants.remove(participant);
        participant.setRegistration(null);
    }
}