package com.esports.project.entity;

import java.time.LocalDateTime;

import com.esports.project.enums.TeamPosition;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(
    name = "team_members",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_team_member",
            columnNames = {
                "team_id",
                "user_id"
            }
        )
    },
    indexes = {
        @Index(
            name = "idx_team_member_team_id",
            columnList = "team_id"
        ),
        @Index(
            name = "idx_team_member_user_id",
            columnList = "user_id"
        )
    }
)
public class TeamMember {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(
        name = "user_id",
        nullable = false
    )
    private String userId;

    @Column(
        name = "username",
        nullable = false,
        length = 100
    )
    private String username;

    @Enumerated(EnumType.STRING)
    @Column(
        name = "position",
        nullable = false
    )
    private TeamPosition position;

    @Column(
        name = "joined_at",
        nullable = false,
        updatable = false
    )
    private LocalDateTime joinedAt;

    @Column(
        name = "created_at",
        nullable = false,
        updatable = false
    )
    private LocalDateTime createdAt;

    @Column(
        name = "updated_at",
        nullable = false
    )
    private LocalDateTime updatedAt;

    @ManyToOne(
        fetch = FetchType.LAZY,
        optional = false
    )
    @JoinColumn(
        name = "team_id",
        nullable = false
    )
    @JsonBackReference(value = "team-members")
    private Team team;

    @PrePersist
    public void onCreate() {
        LocalDateTime now = LocalDateTime.now();

        if (joinedAt == null) {
            joinedAt = now;
        }

        if (createdAt == null) {
            createdAt = now;
        }

        updatedAt = now;
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}