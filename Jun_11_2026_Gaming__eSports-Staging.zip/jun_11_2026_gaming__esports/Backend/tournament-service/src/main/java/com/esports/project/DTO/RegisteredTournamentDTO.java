package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.enums.StatusMaster;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegisteredTournamentDTO {

    private TournamentResponseDTO tournament;

    private String registrationId;

    private StatusMaster registrationStatus;

    private LocalDateTime registrationDate;

    private LocalDateTime respondedAt;

    private String rejectionReason;

    private String teamId;

    private String teamName;

    private Integer totalMembers;
}