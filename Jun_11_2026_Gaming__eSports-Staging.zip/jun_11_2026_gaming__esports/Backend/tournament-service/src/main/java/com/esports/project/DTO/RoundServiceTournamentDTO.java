package com.esports.project.DTO;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoundServiceTournamentDTO {
    private LocalDateTime tournamentStartDate;
    private LocalDateTime tournamentEndDate;
}
