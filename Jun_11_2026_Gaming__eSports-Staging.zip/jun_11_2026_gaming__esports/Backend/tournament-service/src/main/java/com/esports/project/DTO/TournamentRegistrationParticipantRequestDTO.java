package com.esports.project.DTO;

import com.esports.project.enums.TeamPosition;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRegistrationParticipantRequestDTO {

    @NotBlank(message = "User ID is required")
    private String userId;

    @NotBlank(message = "Username is required")
    @Size(
        max = 100,
        message = "Username cannot exceed 100 characters"
    )
    private String username;

    @NotNull(message = "Team position is required")
    private TeamPosition teamPosition;
}