package com.esports.project.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.CreateTeamRequest;
import com.esports.project.DTO.MyTournamentTeamResponse;
import com.esports.project.DTO.TeamDTO;
import com.esports.project.DTO.UpdateTeamRequest;
import com.esports.project.service.TeamService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

@RestController
@RequestMapping("/teams")
@Validated
public class TeamController {

        private final TeamService teamService;

        public TeamController(
                        TeamService teamService) {
                this.teamService = teamService;
        }

        // @PreAuthorize("hasAuthority('PLAYER')")
        @PostMapping
        @ResponseStatus(HttpStatus.CREATED)
        public TeamDTO createTeam(
                        @Valid @RequestBody CreateTeamRequest request) {
                return teamService.createTeam(request);
        }

        @GetMapping("/my")
        public List<TeamDTO> getMyTeams() {
                return teamService.getMyTeams();
        }

        @GetMapping("/search")
        public Page<TeamDTO> searchTeams(
                        @RequestParam @NotBlank(message = "Team name is required") String teamName,

                        @RequestParam(defaultValue = "0") @Min(value = 0, message = "Page cannot be negative") int page,

                        @RequestParam(defaultValue = "10") @Min(value = 1, message = "Size must be at least 1") @Max(value = 100, message = "Size cannot exceed 100") int size) {
                return teamService.searchTeams(
                                teamName,
                                page,
                                size);
        }

        @GetMapping("/my/tournament/{tournamentId}")
        public ResponseEntity<MyTournamentTeamResponse> getMyTeamForTournament(
                        @PathVariable String tournamentId) {

                MyTournamentTeamResponse team = teamService
                                .getMyTeamForTournament(
                                                tournamentId);

                return ResponseEntity.ok(
                                team);
        }

        @GetMapping("/{teamId}")
        public TeamDTO getTeamById(
                        @PathVariable String teamId) {
                return teamService.getTeamById(teamId);
        }

        @GetMapping
        public Page<TeamDTO> getAllTeams(
                        @RequestParam(defaultValue = "0") @Min(value = 0, message = "Page cannot be negative") int page,

                        @RequestParam(defaultValue = "10") @Min(value = 1, message = "Size must be at least 1") @Max(value = 100, message = "Size cannot exceed 100") int size) {
                return teamService.getAllTeams(
                                page,
                                size);
        }

        // @PreAuthorize("hasAuthority('PLAYER')")
        @PatchMapping("/{teamId}")
        public TeamDTO updateTeam(
                        @PathVariable String teamId,
                        @Valid @RequestBody UpdateTeamRequest request) {
                return teamService.updateTeam(
                                teamId,
                                request);
        }

        // @PreAuthorize("hasAuthority('PLAYER')")
        @DeleteMapping("/{teamId}")
        public ResponseEntity<Void> deleteTeam(
                        @PathVariable String teamId) {
                teamService.deleteTeam(teamId);

                return ResponseEntity.noContent().build();
        }
}