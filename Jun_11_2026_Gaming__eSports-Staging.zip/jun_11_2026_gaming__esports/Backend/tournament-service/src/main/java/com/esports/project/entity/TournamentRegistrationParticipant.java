package com.esports.project.entity;

import java.time.LocalDateTime;

import com.esports.project.enums.TeamPosition;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tournament_registration_participants", uniqueConstraints = {
        @UniqueConstraint(name = "uk_tournament_user_participant", columnNames = {
                "tournament_id",
                "user_id"
        })
}, indexes = {
        @Index(name = "idx_participant_registration_id", columnList = "registration_id"),
        @Index(name = "idx_participant_tournament_id", columnList = "tournament_id"),
        @Index(name = "idx_participant_user_id", columnList = "user_id"),
        @Index(name = "idx_participant_team_id", columnList = "team_id")
})
public class TournamentRegistrationParticipant {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    /*
     * Registration to which this participant belongs.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "registration_id", nullable = false)
    @JsonBackReference(value = "registration-participants")
    private TournamentRegistration registration;

    /*
     * These values are intentionally stored directly.
     *
     * They create a historical snapshot and support the
     * tournament_id + user_id unique constraint.
     */
    @Column(name = "tournament_id", nullable = false, updatable = false)
    private String tournamentId;

    @Column(name = "team_id", nullable = false, updatable = false)
    private String teamId;

    @Column(name = "user_id", nullable = false, updatable = false)
    private String userId;

    @Column(name = "username", nullable = false, updatable = false, length = 100)
    private String username;

    @Column(name = "team_position", updatable = false, length = 50)
    private TeamPosition teamPosition;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    public void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
}