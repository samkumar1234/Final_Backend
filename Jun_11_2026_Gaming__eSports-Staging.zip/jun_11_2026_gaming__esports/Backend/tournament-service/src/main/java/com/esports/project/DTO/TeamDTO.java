package com.esports.project.DTO;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TeamDTO{

    private String id;

    private String teamName;

    private String fileId;
    private String tournamentId;
    private String userId;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
}