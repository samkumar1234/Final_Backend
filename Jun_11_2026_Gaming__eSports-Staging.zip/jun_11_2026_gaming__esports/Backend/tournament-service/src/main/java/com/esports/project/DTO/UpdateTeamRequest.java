package com.esports.project.DTO;

import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateTeamRequest{

    @Size(
        min = 3,
        max = 100,
        message = "Team name must contain between 3 and 100 characters"
    )
    private String teamName;

    @Size(
        max = 255,
        message = "File ID cannot exceed 255 characters"
    )
    private String fileId;
}