package com.esports.project.enums;

public enum StatusMaster {
    ONGOING,
    UPCOMMING,
    CANCELLED,
    POSTPONDED,
    PENDING,
    APPROVED,
    REJECTED
}
