package com.esports.project.DTO;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserTournamentResponseDTO {

    private List<RegisteredTournamentDTO> registeredTournaments;

    private List<TournamentResponseDTO> allTournaments;

}