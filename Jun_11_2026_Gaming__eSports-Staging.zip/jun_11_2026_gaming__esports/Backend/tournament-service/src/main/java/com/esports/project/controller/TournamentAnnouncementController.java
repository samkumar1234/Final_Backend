package com.esports.project.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentAnnouncementRequestDTO;
import com.esports.project.DTO.TournamentAnnouncementResponseDTO;
import com.esports.project.DTO.TournamentAnnouncementUpdateDTO;
import com.esports.project.service.TournamentAnnouncementService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tournament/announcement")
public class TournamentAnnouncementController {

        private final TournamentAnnouncementService tournamentAnnouncementService;

        public TournamentAnnouncementController(
                        TournamentAnnouncementService tournamentAnnouncementService) {
                this.tournamentAnnouncementService = tournamentAnnouncementService;
        }

        /*
         * Create Announcement
         */
        @PostMapping
        // @PreAuthorize("hasAuthority('TOURNAMENT_ANNOUNCEMENT_CREATE')")
        public ResponseEntity<TournamentAnnouncementResponseDTO> createAnnouncement(
                        @Valid @RequestBody TournamentAnnouncementRequestDTO requestDTO) {

                return ResponseEntity.status(HttpStatus.CREATED)
                                .body(tournamentAnnouncementService.createAnnouncement(requestDTO));
        }

        /*
         * Get Announcement By Id
         */
        @GetMapping("/{id}")
        // @PreAuthorize("hasAuthority('TOURNAMENT_ANNOUNCEMENT_VIEW')")
        public ResponseEntity<TournamentAnnouncementResponseDTO> getAnnouncementById(
                        @PathVariable String id) {

                return ResponseEntity.status(HttpStatus.OK)
                                .body(tournamentAnnouncementService.getAnnouncementById(id));
        }

        /*
         * Get All Announcements For Tournament
         */
        @GetMapping("/tournament/{tournamentId}")
        // @PreAuthorize("hasAuthority('TOURNAMENT_ANNOUNCEMENT_VIEW')")
        public ResponseEntity<List<TournamentAnnouncementResponseDTO>> getAnnouncementsByTournamentId(
                        @PathVariable String tournamentId) {

                return ResponseEntity.status(HttpStatus.OK)
                                .body(tournamentAnnouncementService
                                                .getAnnouncementsByTournamentId(tournamentId));
        }

        /*
         * Update Announcement
         */
        @PatchMapping("/{id}")
        // @PreAuthorize("hasAuthority('TOURNAMENT_ANNOUNCEMENT_UPDATE')")
        public ResponseEntity<TournamentAnnouncementResponseDTO> updateAnnouncement(
                        @PathVariable String id,
                        @RequestBody TournamentAnnouncementUpdateDTO updateDTO) {

                return ResponseEntity.status(HttpStatus.ACCEPTED)
                                .body(tournamentAnnouncementService
                                                .updateAnnouncement(id, updateDTO));
        }

        /*
         * Delete Announcement
         */
        @DeleteMapping("/{id}")
        // @PreAuthorize("hasAuthority('TOURNAMENT_ANNOUNCEMENT_DELETE')")
        public ResponseEntity<ResponseDTO> deleteAnnouncement(
                        @PathVariable String id) {

                return ResponseEntity.status(HttpStatus.OK)
                                .body(tournamentAnnouncementService
                                                .deleteAnnouncement(id));
        }

        /*
         * Tournament Announcements With Pagination
         */
        @GetMapping("/tournament/{tournamentId}/page")
        // @PreAuthorize("hasAuthority('TOURNAMENT_ANNOUNCEMENT_VIEW')")
        public Page<TournamentAnnouncementResponseDTO> getTournamentAnnouncements(
                        @PathVariable String tournamentId,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size) {

                return tournamentAnnouncementService.getTournamentAnnouncements(
                                tournamentId,
                                PageRequest.of(page, size));
        }

        /*
         * Filter Announcements
         */
        @GetMapping("/filter")
        // @PreAuthorize("hasAuthority('TOURNAMENT_ANNOUNCEMENT_VIEW')")
        public Page<TournamentAnnouncementResponseDTO> filterAnnouncements(
                        @RequestParam(required = false) String title,
                        @RequestParam(required = false) String tournamentId,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size) {

                return tournamentAnnouncementService.filterAnnouncements(
                                title,
                                tournamentId,
                                PageRequest.of(page, size));
        }
}