package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.enums.RulesCategory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRulesResponseDTO {

    private String id;

    private RulesCategory category;

    private String ruleText;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private String tournamentId;

    private String tournamentName;
}
