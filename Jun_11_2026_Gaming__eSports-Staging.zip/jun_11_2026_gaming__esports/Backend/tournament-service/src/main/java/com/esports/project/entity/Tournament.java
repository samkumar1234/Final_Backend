package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.SeedType;
import com.esports.project.enums.StatusMaster;
import com.esports.project.enums.TournamentCategory;
import com.esports.project.enums.TournamentType;
import com.esports.project.enums.TournamentVerification;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tournaments")
public class Tournament {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String name;
    private String description;
    private LocalDateTime registrationStartDate;
    private LocalDateTime registrationEndDate;
    private LocalDateTime tournamentStartDate;
    private LocalDateTime tournamentEndDate;

    private Boolean isLocked;

    @Enumerated(EnumType.STRING)
    private TournamentCategory tournamentCategory;

    @Enumerated(EnumType.STRING)
    private TournamentType tournamentType;


    private Integer maximumTeams;
    private Integer maximumPlayersPerTeam;

    @Enumerated(EnumType.STRING)
    private SeedType seedingTypeId;
    private BigDecimal entryFee;

    @Enumerated(EnumType.STRING)
    private TournamentVerification verificationRequired;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // forign key mapping
    @Column(name = "user_id")
    private String userId;

    @Column(name = "file_id")
    private String fileId;
    
    private Boolean isDeleted;


    // tournament rules

    @OneToMany(mappedBy = "tournament",fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
    @JsonManagedReference(value = "tournament-rules")
    private List<TournamentRules> tournamentRules;

    // registred Teams mapping

    @OneToMany(mappedBy = "tournament",fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
    @JsonManagedReference(value = "tournament-registration")
    private List<TournamentRegistration> tournamentRegistrations;

    // announcement mapping

    @OneToMany(mappedBy = "tournament",fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
    @JsonManagedReference(value = "tournament-announcement")
    private List<TournamentAnnouncement> tournamentAnnouncements;

    // Tournament FAQ

    @OneToMany(mappedBy = "tournament",fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
    @JsonManagedReference(value = "tournament-faq")
    private List<TournamentFAQ> tournamentFAQs;

    // tournament price mapping

    @OneToMany(mappedBy = "tournament",cascade = CascadeType.REMOVE)
    @JsonManagedReference(value = "tournament-price")
    private List<TournamentPrice> tournamentPrices;  
    
    @PrePersist
    public void beforeSave(){
        this.isDeleted = false;
        this.isLocked = false;
    }
}
