package com.esports.project.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.TournamentFAQRequestDTO;
import com.esports.project.DTO.TournamentFAQResponseDTO;
import com.esports.project.DTO.TournamentFAQUpdateDTO;
import com.esports.project.entity.TournamentFAQ;

@Mapper(
    componentModel = "spring"
    ,unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface TournamentFAQMapper {

    TournamentFAQ toEntity(
            TournamentFAQRequestDTO dto);

    @Mapping(target = "tournamentId", source = "tournament.id")
    @Mapping(target = "tournamentName", source = "tournament.name")
    TournamentFAQResponseDTO toResponseDTO(
            TournamentFAQ faq);

    void updateFAQFromDto(
            TournamentFAQUpdateDTO dto,
            @MappingTarget TournamentFAQ faq);
}