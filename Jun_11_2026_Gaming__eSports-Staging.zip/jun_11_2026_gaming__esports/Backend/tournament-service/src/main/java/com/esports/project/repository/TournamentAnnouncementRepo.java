package com.esports.project.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.TournamentAnnouncement;

@Repository
public interface TournamentAnnouncementRepo extends
        JpaRepository<TournamentAnnouncement, String>,
        JpaSpecificationExecutor<TournamentAnnouncement> {

    List<TournamentAnnouncement> findByTournament_Id(
            String tournamentId);

    Page<TournamentAnnouncement> findByTournament_Id(
            String tournamentId,
            Pageable pageable);
}