package com.esports.project.service.generation.factory;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.enums.TournamentFormat;
import com.esports.project.service.generation.strategy.RoundRobinGenerationStrategy;
import com.esports.project.service.generation.strategy.SingleEliminationGenerationStrategy;
import com.esports.project.service.generation.strategy.TournamentGenerationStrategy;

@ExtendWith(MockitoExtension.class)
class TournamentGenerationFactoryTest {

    @Mock
    private SingleEliminationGenerationStrategy singleElimination;

    @Mock
    private RoundRobinGenerationStrategy roundRobin;

    @InjectMocks
    private TournamentGenerationFactory tournamentGenerationFactory;

    @Test
    void getStrategyForSingleEliminationTest() {

        TournamentGenerationStrategy strategy =
                tournamentGenerationFactory.getStrategy(
                        TournamentFormat.SINGLE_ELIMINATION);

        assertNotNull(strategy);
        assertEquals(singleElimination, strategy);
    }

    @Test
    void getStrategyForRoundRobinTest() {

        TournamentGenerationStrategy strategy =
                tournamentGenerationFactory.getStrategy(
                        TournamentFormat.ROUND_ROBIN);

        assertNotNull(strategy);
        assertEquals(roundRobin, strategy);
    }

    @Test
    void shouldReturnSameSingleEliminationInstance() {

        TournamentGenerationStrategy strategy1 =
                tournamentGenerationFactory.getStrategy(
                        TournamentFormat.SINGLE_ELIMINATION);

        TournamentGenerationStrategy strategy2 =
                tournamentGenerationFactory.getStrategy(
                        TournamentFormat.SINGLE_ELIMINATION);

        assertEquals(strategy1, strategy2);
    }

    @Test
    void shouldReturnSameRoundRobinInstance() {

        TournamentGenerationStrategy strategy1 =
                tournamentGenerationFactory.getStrategy(
                        TournamentFormat.ROUND_ROBIN);

        TournamentGenerationStrategy strategy2 =
                tournamentGenerationFactory.getStrategy(
                        TournamentFormat.ROUND_ROBIN);

        assertEquals(strategy1, strategy2);
    }

    @Test
    void shouldNotReturnRoundRobinForSingleElimination() {

        TournamentGenerationStrategy strategy =
                tournamentGenerationFactory.getStrategy(
                        TournamentFormat.SINGLE_ELIMINATION);

        assertNotNull(strategy);
        org.junit.jupiter.api.Assertions.assertNotEquals(
                roundRobin,
                strategy);
    }

    @Test
    void shouldNotReturnSingleEliminationForRoundRobin() {

        TournamentGenerationStrategy strategy =
                tournamentGenerationFactory.getStrategy(
                        TournamentFormat.ROUND_ROBIN);

        assertNotNull(strategy);
        org.junit.jupiter.api.Assertions.assertNotEquals(
                singleElimination,
                strategy);
    }
}