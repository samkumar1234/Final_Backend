package com.esports.project.service.generation.factory;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.enums.seedType;
import com.esports.project.service.generation.seeding.ManualSeedingStrategy;
import com.esports.project.service.generation.seeding.RandomSeedingStrategy;
import com.esports.project.service.generation.strategy.SeedingStrategy;

@ExtendWith(MockitoExtension.class)
class SeedingStrategyFactoryTest {

    @Mock
    private RandomSeedingStrategy randomStrategy;

    @Mock
    private ManualSeedingStrategy manualStrategy;

    @InjectMocks
    private SeedingStrategyFactory seedingStrategyFactory;

    @Test
    void getStrategyForRandomTest() {

        SeedingStrategy strategy =
                seedingStrategyFactory.getStrategy(seedType.RANDOM);

        assertNotNull(strategy);
        assertEquals(randomStrategy, strategy);
    }

    @Test
    void getStrategyForManualTest() {

        SeedingStrategy strategy =
                seedingStrategyFactory.getStrategy(seedType.MANUAL);

        assertNotNull(strategy);
        assertEquals(manualStrategy, strategy);
    }

    @Test
    void shouldReturnSameRandomStrategyInstance() {

        SeedingStrategy strategy1 =
                seedingStrategyFactory.getStrategy(seedType.RANDOM);

        SeedingStrategy strategy2 =
                seedingStrategyFactory.getStrategy(seedType.RANDOM);

        assertEquals(strategy1, strategy2);
    }

    @Test
    void shouldReturnSameManualStrategyInstance() {

        SeedingStrategy strategy1 =
                seedingStrategyFactory.getStrategy(seedType.MANUAL);

        SeedingStrategy strategy2 =
                seedingStrategyFactory.getStrategy(seedType.MANUAL);

        assertEquals(strategy1, strategy2);
    }
}