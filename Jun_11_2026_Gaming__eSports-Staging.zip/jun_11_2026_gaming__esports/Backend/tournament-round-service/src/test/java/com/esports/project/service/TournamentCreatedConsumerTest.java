// package com.esports.project.service;

// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.Mockito.doThrow;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// import com.esports.project.DTO.BrokerMessage;
// import com.esports.project.DTO.TournamentGenerationEvent;
// import com.esports.project.service.generation.TournamentGenerationService;
// import com.fasterxml.jackson.databind.ObjectMapper;

// @ExtendWith(MockitoExtension.class)
// class TournamentCreatedConsumerTest {

//     @Mock
//     private TournamentGenerationService tournamentGenerationService;

//     @Mock
//     private ObjectMapper objectMapper;

//     @InjectMocks
//     private TournamentCreatedConsumer tournamentCreatedConsumer;

//     @Test
//     void consumeTest() {

//         BrokerMessage brokerMessage = new BrokerMessage();
//         Object payload = new Object();
//         brokerMessage.setPayload(payload);

//         TournamentGenerationEvent event =
//                 new TournamentGenerationEvent();

//         when(objectMapper.convertValue(
//                 payload,
//                 TournamentGenerationEvent.class))
//                 .thenReturn(event);

//         tournamentCreatedConsumer.consume(brokerMessage);

//         verify(objectMapper)
//                 .convertValue(
//                         payload,
//                         TournamentGenerationEvent.class);

//         verify(tournamentGenerationService)
//                 .generate(event);
//     }

//     @Test
//     void consumeWithNullPayloadTest() {

//         BrokerMessage brokerMessage = new BrokerMessage();
//         brokerMessage.setPayload(null);

//         TournamentGenerationEvent event =
//                 new TournamentGenerationEvent();

//         when(objectMapper.convertValue(
//                 null,
//                 TournamentGenerationEvent.class))
//                 .thenReturn(event);

//         tournamentCreatedConsumer.consume(brokerMessage);

//         verify(tournamentGenerationService)
//                 .generate(event);
//     }

//     @Test
//     void consumeShouldThrowExceptionWhenObjectMapperFails() {

//         BrokerMessage brokerMessage = new BrokerMessage();
//         Object payload = new Object();
//         brokerMessage.setPayload(payload);

//         when(objectMapper.convertValue(
//                 payload,
//                 TournamentGenerationEvent.class))
//                 .thenThrow(new RuntimeException("Conversion Error"));

//         assertThrows(
//                 RuntimeException.class,
//                 () -> tournamentCreatedConsumer.consume(brokerMessage));
//     }

//     @Test
//     void consumeShouldThrowExceptionWhenGenerationFails() {

//         BrokerMessage brokerMessage = new BrokerMessage();
//         Object payload = new Object();
//         brokerMessage.setPayload(payload);

//         TournamentGenerationEvent event =
//                 new TournamentGenerationEvent();

//         when(objectMapper.convertValue(
//                 payload,
//                 TournamentGenerationEvent.class))
//                 .thenReturn(event);

//         doThrow(new RuntimeException("Generation Error"))
//                 .when(tournamentGenerationService)
//                 .generate(event);

//         assertThrows(
//                 RuntimeException.class,
//                 () -> tournamentCreatedConsumer.consume(brokerMessage));
//     }

//     @Test
//     void consumeShouldInvokeDependenciesOnce() {

//         BrokerMessage brokerMessage = new BrokerMessage();
//         Object payload = new Object();
//         brokerMessage.setPayload(payload);

//         TournamentGenerationEvent event =
//                 new TournamentGenerationEvent();

//         when(objectMapper.convertValue(
//                 payload,
//                 TournamentGenerationEvent.class))
//                 .thenReturn(event);

//         tournamentCreatedConsumer.consume(brokerMessage);

//         verify(objectMapper, times(1))
//                 .convertValue(
//                         payload,
//                         TournamentGenerationEvent.class);

//         verify(tournamentGenerationService, times(1))
//                 .generate(event);
//     }
// }