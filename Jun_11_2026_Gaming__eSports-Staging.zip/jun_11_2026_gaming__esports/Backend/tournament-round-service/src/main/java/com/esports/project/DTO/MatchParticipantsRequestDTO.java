package com.esports.project.DTO;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MatchParticipantsRequestDTO {
    private String teamId;
    private List<String> participantIds;
    private String matchDetailsId;
}
