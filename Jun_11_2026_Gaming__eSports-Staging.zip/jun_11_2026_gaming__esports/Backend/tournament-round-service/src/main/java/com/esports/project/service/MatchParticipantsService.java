package com.esports.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.MatchParticipantsRequestDTO;
import com.esports.project.DTO.MatchParticipantsResponseDTO;
import com.esports.project.DTO.MatchParticipantsUpdateDTO;
import com.esports.project.DTO.ResponseDTO;
import com.esports.project.entity.MatchDetails;
import com.esports.project.entity.MatchParticipants;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.MatchParticipantsMapper;
import com.esports.project.repository.MatchDetailsRepo;
import com.esports.project.repository.MatchParticipantsRepo;

@Service
public class MatchParticipantsService {

    private final MatchParticipantsRepo matchParticipantsRepo;
    private final MatchDetailsRepo matchDetailsRepo;
    private final MatchParticipantsMapper matchParticipantsMapper;

    @Autowired
    public MatchParticipantsService(
            MatchParticipantsRepo matchParticipantsRepo,
            MatchDetailsRepo matchDetailsRepo,
            MatchParticipantsMapper matchParticipantsMapper) {

        this.matchParticipantsRepo = matchParticipantsRepo;
        this.matchDetailsRepo = matchDetailsRepo;
        this.matchParticipantsMapper = matchParticipantsMapper;
    }

    /*
     * Create Participant
     */
    public MatchParticipantsResponseDTO createParticipant(
            MatchParticipantsRequestDTO requestDTO) {

        MatchDetails matchDetails = matchDetailsRepo
                .findById(requestDTO.getMatchDetailsId())
                .orElseThrow(() -> new NotFoundException(
                        "Match details not found with id : "
                                + requestDTO.getMatchDetailsId()));

        MatchParticipants participant =
                matchParticipantsMapper.toEntity(requestDTO);

        participant.setMatchDetails(matchDetails);

        if (participant.getStatus() == null) {
            participant.setStatus(StatusMaster.ACTIVE);
        }

        validateParticipant(participant);

        return matchParticipantsMapper.toResponseDTO(
                matchParticipantsRepo.save(participant));
    }

    /*
     * Get Participant By Id
     */
    public MatchParticipantsResponseDTO getParticipantById(
            String id) {

        MatchParticipants participant =
                matchParticipantsRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Participant not found with id : "
                                                + id));

        return matchParticipantsMapper
                .toResponseDTO(participant);
    }

    /*
     * Get Participants By Match Id
     */
    public List<MatchParticipantsResponseDTO>
    getParticipantsByMatchId(
            String matchId) {

        return matchParticipantsRepo
                .findByMatchDetails_Id(matchId)
                .stream()
                .map(matchParticipantsMapper::toResponseDTO)
                .toList();
    }

    /*
     * Update Participant
     */
    public MatchParticipantsResponseDTO updateParticipant(
            String id,
            MatchParticipantsUpdateDTO updateDTO) {

        MatchParticipants participant =
                matchParticipantsRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Participant not found with id : "
                                                + id));

        matchParticipantsMapper
                .updateParticipantFromDTO(
                        updateDTO,
                        participant);

        validateParticipant(participant);

        return matchParticipantsMapper.toResponseDTO(
                matchParticipantsRepo.save(participant));
    }

    /*
     * Delete Participant
     */
    public ResponseDTO deleteParticipant(
            String id) {

        MatchParticipants participant =
                matchParticipantsRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Participant not found with id : "
                                                + id));

        matchParticipantsRepo.delete(participant);

        return new ResponseDTO(
                HttpStatus.OK.value(),
                "Participant deleted successfully");
    }

    /*
     * Validation
     */
    private void validateParticipant(
            MatchParticipants participant) {

        if (participant.getTeamId() == null
                || participant.getTeamId().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Team Id is required");
        }

        if (participant.getMatchDetails() == null) {

            throw new IllegalArgumentException(
                    "Match details is required");
        }

        if (participant.getStatus() == null) {

            throw new IllegalArgumentException(
                    "Status is required");
        }
    }
}