package com.esports.project.mapper;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.MatchDetailsRequestDTO;
import com.esports.project.DTO.MatchDetailsResponseDTO;
import com.esports.project.DTO.MatchDetailsUpdateDTO;
import com.esports.project.entity.MatchDetails;

@Mapper(componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MatchDetailsMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "roundDetails", ignore = true)
    @Mapping(target = "matchParticipants", ignore = true)
    MatchDetails toEntity(
            MatchDetailsRequestDTO dto);

    @Mapping(
            target = "roundId",
            source = "roundDetails.id")
    @Mapping(
            target = "participantCount",
            expression = "java(matchDetails.getMatchParticipants() != null ? matchDetails.getMatchParticipants().size() : 0)")
    MatchDetailsResponseDTO toResponseDTO(
            MatchDetails matchDetails);

    @BeanMapping(
            nullValuePropertyMappingStrategy =
                    NullValuePropertyMappingStrategy.IGNORE)
    void updateMatchFromDTO(
            MatchDetailsUpdateDTO dto,
            @MappingTarget MatchDetails matchDetails);
}
