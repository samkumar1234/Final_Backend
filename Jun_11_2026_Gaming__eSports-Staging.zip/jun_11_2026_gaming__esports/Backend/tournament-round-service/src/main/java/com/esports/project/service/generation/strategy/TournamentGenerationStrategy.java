package com.esports.project.service.generation.strategy;

import com.esports.project.DTO.ParticipantDetails;
import com.esports.project.DTO.TournamentGenerationEvent;

import java.util.List;


public interface TournamentGenerationStrategy {

    void generate(
            TournamentGenerationEvent event,
            List<ParticipantDetails> participants);
}