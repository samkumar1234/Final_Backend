package com.esports.project.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.MatchDetailsRequestDTO;
import com.esports.project.DTO.MatchDetailsResponseDTO;
import com.esports.project.DTO.MatchDetailsUpdateDTO;
import com.esports.project.DTO.ResponseDTO;
import com.esports.project.service.MatchDetailsService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/round/match")
public class MatchDetailsController {

    private final MatchDetailsService matchDetailsService;

    public MatchDetailsController(
            MatchDetailsService matchDetailsService) {
        this.matchDetailsService = matchDetailsService;
    }

    /*
     * Create Match
     */
    @PostMapping
//     @PreAuthorize("hasAuthority('MATCH_CREATE')")
    public ResponseEntity<MatchDetailsResponseDTO> createMatch(
            @Valid @RequestBody MatchDetailsRequestDTO requestDTO) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(matchDetailsService.createMatch(requestDTO));
    }

    /*
     * Get Match By Id
     */
    @GetMapping("/{id}")
//     @PreAuthorize("hasAuthority('MATCH_VIEW')")
    public ResponseEntity<MatchDetailsResponseDTO> getMatchById(
            @PathVariable String id) {

        return ResponseEntity.ok(
                matchDetailsService.getMatchById(id));
    }

    /*
     * Get Matches By Round Id
     */
    @GetMapping("/round/{roundId}")
//     @PreAuthorize("hasAuthority('MATCH_VIEW')")
    public ResponseEntity<List<MatchDetailsResponseDTO>>
            getMatchesByRoundId(
                    @PathVariable String roundId) {

        return ResponseEntity.ok(
                matchDetailsService.getMatchesByRoundId(roundId));
    }

    /*
     * Update Match
     */
    @PatchMapping("/{id}")
//     @PreAuthorize("hasAuthority('MATCH_UPDATE')")
    public ResponseEntity<MatchDetailsResponseDTO> updateMatch(
            @PathVariable String id,
            @RequestBody MatchDetailsUpdateDTO updateDTO) {

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(matchDetailsService.updateMatch(
                        id,
                        updateDTO));
    }

    /*
     * Delete Match
     */
    @DeleteMapping("/{id}")
//     @PreAuthorize("hasAuthority('MATCH_DELETE')")
    public ResponseEntity<ResponseDTO> deleteMatch(
            @PathVariable String id) {

        return ResponseEntity.ok(
                matchDetailsService.deleteMatch(id));
    }
}