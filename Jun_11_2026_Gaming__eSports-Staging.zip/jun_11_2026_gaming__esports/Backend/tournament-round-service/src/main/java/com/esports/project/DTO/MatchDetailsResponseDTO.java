package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.enums.StatusMaster;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MatchDetailsResponseDTO {
    private String id;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private StatusMaster status;
    private String gameCode;
    private String roundId;
    private Integer participantCount;
}
