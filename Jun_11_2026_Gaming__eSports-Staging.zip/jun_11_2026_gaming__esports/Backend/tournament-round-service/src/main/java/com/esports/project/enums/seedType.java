package com.esports.project.enums;

public enum seedType {
    RANDOM,
    MANUAL
}
