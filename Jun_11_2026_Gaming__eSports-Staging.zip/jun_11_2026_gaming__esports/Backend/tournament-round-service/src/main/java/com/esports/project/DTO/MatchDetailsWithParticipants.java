package com.esports.project.DTO;

import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.StatusMaster;

import lombok.Data;

@Data
public class MatchDetailsWithParticipants{
    private String id;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private StatusMaster status;
    private String gameCode;
    private String roundId;
    private List<MatchParticipantsResponseDTO> participants;
}