package com.esports.project.service.generation.strategy;

import java.util.List;

import com.esports.project.DTO.ParticipantDetails;


public interface SeedingStrategy {
    List<ParticipantDetails> process(
            List<ParticipantDetails> participants);
}
