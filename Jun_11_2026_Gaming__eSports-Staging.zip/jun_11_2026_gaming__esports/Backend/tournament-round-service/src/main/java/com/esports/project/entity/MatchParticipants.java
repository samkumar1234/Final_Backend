package com.esports.project.entity;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "match_participants")
public class MatchParticipants {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

    private String teamId;

    @JdbcTypeCode(SqlTypes.ARRAY)
    @Column(name = "participant_ids")
    private List<String> participantIds = new ArrayList<>();

    /*
     * Relationship mapping
     */

    // match Details mapping

    @ManyToOne
    @JoinColumn(name = "match_details_id")
    @JsonBackReference(value = "match-details-participants")
    private MatchDetails matchDetails;

}
