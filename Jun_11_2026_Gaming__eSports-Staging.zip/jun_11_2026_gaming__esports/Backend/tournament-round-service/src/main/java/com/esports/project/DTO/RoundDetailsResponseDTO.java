package com.esports.project.DTO;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoundDetailsResponseDTO {
    private String id;
    private String roundName;
    private Integer maximumParticipants;
    private Integer qualifyingCount;
    private String tournamentId;
    private LocalDateTime createdAt;
}
