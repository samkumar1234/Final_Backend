package com.esports.project.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.service.generation.TournamentGenerationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class TournamentCreatedConsumer {

    private final TournamentGenerationService tournamentGenerationService;
    private final ObjectMapper objectMapper;
    private final EventPublisher publisher;

    public void consume(BrokerMessage message) {

        System.out.println(
                "Tournament Created Event Received");

        TournamentGenerationEvent event =
                objectMapper.convertValue(
                        message.getPayload(),
                        TournamentGenerationEvent.class);

        tournamentGenerationService.generate(event);

        try {
            NotificationEventDTO notification = new NotificationEventDTO(message.getUserId(), "Brackets Generated", "Brackets generated for the tournament : " + event.getTournamentName() + " which have seed type : " + event.getSeedType() + " for type : " + event.getTournamentType());
            List<String> participants = event.getParticipants().stream().flatMap(e -> e.getParticipantIds().stream()).toList();
            sendNotification(participants, "Brackets Generated", "Brackets generated for the tournament : " + event.getTournamentName() + " which have seed type : " + event.getSeedType() + " for type : " + event.getTournamentType());
            publisher.publishNotification(notification);
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
        
        System.out.println("Event Message" + event.toString());
    }

    private void sendNotification(List<String> id,String title,String message){

        id.forEach(e -> {
            NotificationEventDTO notification = new NotificationEventDTO(
                                                        e,
                                                        title,
                                                        message);

                                        try {
                                                publisher.publishNotification(notification);
                                        } catch (Exception ex) {
                                                System.out.println("Notifivation Publisher : " + ex.getMessage());
                                        }
        });
        
    }
}