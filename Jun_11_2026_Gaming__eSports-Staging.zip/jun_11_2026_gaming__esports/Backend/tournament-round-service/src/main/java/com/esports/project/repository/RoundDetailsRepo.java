package com.esports.project.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.RoundDetails;

@Repository
public interface RoundDetailsRepo extends
        JpaRepository<RoundDetails, String>,
        JpaSpecificationExecutor<RoundDetails> {

    Page<RoundDetails> findByTournamentId(
            String tournamentId,
            Pageable pageable);

    @EntityGraph(attributePaths = {
    "matchDetails",
    "matchDetails.matchParticipants"
})
List<RoundDetails> findByTournamentId(String tournamentId);

}
