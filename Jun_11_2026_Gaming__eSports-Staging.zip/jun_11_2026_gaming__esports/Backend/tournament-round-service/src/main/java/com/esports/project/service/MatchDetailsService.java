package com.esports.project.service;

import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.MatchDetailsRequestDTO;
import com.esports.project.DTO.MatchDetailsResponseDTO;
import com.esports.project.DTO.MatchDetailsUpdateDTO;
import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.DTO.ResponseDTO;
import com.esports.project.entity.MatchDetails;
import com.esports.project.entity.MatchParticipants;
import com.esports.project.entity.RoundDetails;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.MatchDetailsMapper;
import com.esports.project.repository.MatchDetailsRepo;
import com.esports.project.repository.MatchParticipantsRepo;
import com.esports.project.repository.RoundDetailsRepo;

@Service
public class MatchDetailsService {

    private final MatchDetailsRepo matchDetailsRepo;
    private final RoundDetailsRepo roundDetailsRepo;
    private final MatchDetailsMapper matchDetailsMapper;
        private final MatchParticipantsRepo matchParticipantsRepo;
        private final EventPublisher publisher;

    @Autowired
    public MatchDetailsService(
            MatchDetailsRepo matchDetailsRepo,
            RoundDetailsRepo roundDetailsRepo,
            MatchDetailsMapper matchDetailsMapper,
                        MatchParticipantsRepo matchParticipantsRepo,
                        EventPublisher publisher) {

        this.matchDetailsRepo = matchDetailsRepo;
        this.roundDetailsRepo = roundDetailsRepo;
        this.matchDetailsMapper = matchDetailsMapper;
                        this.matchParticipantsRepo = matchParticipantsRepo;
                this.publisher = publisher;
    }

    /*
     * Create Match
     */
    public MatchDetailsResponseDTO createMatch(
            MatchDetailsRequestDTO requestDTO) {

        RoundDetails roundDetails = roundDetailsRepo
                .findById(requestDTO.getRoundId())
                .orElseThrow(() -> new NotFoundException(
                        "Round not found with id : "
                                + requestDTO.getRoundId()));

        MatchDetails matchDetails =
                matchDetailsMapper.toEntity(requestDTO);

        matchDetails.setRoundDetails(roundDetails);

        if (matchDetails.getStatus() == null) {
            matchDetails.setStatus(StatusMaster.ACTIVE);
        }

        validateMatch(matchDetails);

        MatchDetails savedMatch = 
                matchDetailsRepo.save(matchDetails);

        return matchDetailsMapper.toResponseDTO(savedMatch);
    }

    /*
     * Get Match By Id
     */
    public MatchDetailsResponseDTO getMatchById(
            String id) {

        MatchDetails matchDetails = matchDetailsRepo
                .findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Match not found with id : " + id));

        return matchDetailsMapper.toResponseDTO(matchDetails);
    }

    /*
     * Get Matches By Round Id
     */
    public List<MatchDetailsResponseDTO>
            getMatchesByRoundId(String roundId) {

        return matchDetailsRepo
                .findByRoundDetails_Id(roundId)
                .stream()
                .map(matchDetailsMapper::toResponseDTO)
                .toList();
    }

    /*
     * Update Match
     */
    public MatchDetailsResponseDTO updateMatch(
            String id,
            MatchDetailsUpdateDTO updateDTO) {

        MatchDetails matchDetails = matchDetailsRepo
                .findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Match not found with id : " + id));

        matchDetailsMapper.updateMatchFromDTO(
                updateDTO,
                matchDetails);

        validateMatch(matchDetails);

        MatchDetails savedMatch = matchDetailsRepo.save(matchDetails);
        String message = "Match start and end Date is Updated";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        if(updateDTO.getGameCode() != null) message = "Your Came code for the match is created by the Organizer. The match starts at " + matchDetails.getStartTime().format(formatter) + " and end in " + matchDetails.getEndTime().format(formatter);
        sendNotification(savedMatch.getId(), "Match Updated..!", message);
        
        return matchDetailsMapper.toResponseDTO(savedMatch);
    }

    /*
     * Delete Match
     */
    public ResponseDTO deleteMatch(String id) {

        MatchDetails matchDetails = matchDetailsRepo
                .findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Match not found with id : " + id));

        matchDetailsRepo.delete(matchDetails);

        sendNotification(matchDetails.getId(), "Match Deleted","Match deleted by the organizer");

        return new ResponseDTO(
                HttpStatus.OK.value(),
                "Match deleted successfully");
    }

    /*
     * Validation
     */
    private void validateMatch(
            MatchDetails matchDetails) {

        if (matchDetails.getRoundDetails() == null) {
            throw new IllegalArgumentException(
                    "Round is required");
        }

        if (matchDetails.getStartTime() == null) {
            throw new IllegalArgumentException(
                    "Start time is required");
        }
    }

    
        private void sendNotification(
                        String id,
                        String title,
                        String message) {

                List<MatchParticipants> matchParticipants = matchParticipantsRepo.findByMatchDetails_Id(id);

                // System.out.println(matchParticipants.get(0).getParticipantIds());

                matchParticipants.stream()
                                .flatMap(e -> e.getParticipantIds().stream())
                                .distinct()
                                .forEach(userId -> {

                                        NotificationEventDTO notification = new NotificationEventDTO(
                                                        userId,
                                                        title,
                                                        message);

                                        try {
                                                publisher.publishNotification(notification);
                                        } catch (Exception e) {
                                                System.out.println("Notifivation Publisher : " + e.getMessage());
                                        }
                                });
        }


}