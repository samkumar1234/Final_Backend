package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.MatchDetailsWithParticipants;
import com.esports.project.DTO.MatchParticipantsResponseDTO;
import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.RoundDetailsRequestDTO;
import com.esports.project.DTO.RoundDetailsResponseDTO;
import com.esports.project.DTO.RoundDetailsUpdateDTO;
import com.esports.project.DTO.RoundDetailsWithMatchDTO;
import com.esports.project.entity.MatchDetails;
import com.esports.project.entity.MatchParticipants;
import com.esports.project.entity.RoundDetails;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.RoundDetailsMapper;
import com.esports.project.repository.RoundDetailsRepo;

@Service
public class RoundDetailsService {

        private final RoundDetailsRepo roundDetailsRepo;
        private final RoundDetailsMapper roundDetailsMapper;

        @Autowired
        public RoundDetailsService(
                        RoundDetailsRepo roundDetailsRepo,
                        RoundDetailsMapper roundDetailsMapper) {

                this.roundDetailsRepo = roundDetailsRepo;
                this.roundDetailsMapper = roundDetailsMapper;

        }

        /*
         * Create Round
         */
        public RoundDetailsResponseDTO createRound(
                        RoundDetailsRequestDTO requestDTO) {

                RoundDetails round = roundDetailsMapper.toEntity(requestDTO);

                round.setCreatedAt(LocalDateTime.now());

                validateRound(round);

                return roundDetailsMapper.toResponseDTO(
                                roundDetailsRepo.save(round));
        }

        /*
         * Get Round By Id
         */
        public RoundDetailsResponseDTO getRoundById(
                        String id) {

                RoundDetails round = roundDetailsRepo.findById(id)
                                .orElseThrow(() -> new NotFoundException(
                                                "Round not found with id : "
                                                                + id));

                return roundDetailsMapper.toResponseDTO(round);
        }

        /*
         * Get Rounds By Tournament Id
         */
        public List<RoundDetailsResponseDTO> getRoundsByTournamentId(
                        String tournamentId) {

                List<RoundDetails> rounds = roundDetailsRepo.findByTournamentId(
                                tournamentId);

                return rounds.stream()
                                .map(roundDetailsMapper::toResponseDTO)
                                .toList();
        }

        /*
         * Update Round
         */
        public RoundDetailsResponseDTO updateRound(
                        String id,
                        RoundDetailsUpdateDTO updateDTO) {

                RoundDetails round = roundDetailsRepo.findById(id)
                                .orElseThrow(() -> new NotFoundException(
                                                "Round not found with id : "
                                                                + id));

                roundDetailsMapper.updateRoundFromDTO(
                                updateDTO,
                                round);

                validateRound(round);

                return roundDetailsMapper.toResponseDTO(
                                roundDetailsRepo.save(round));
        }

        /*
         * Delete Round
         */
        public ResponseDTO deleteRound(
                        String id) {

                RoundDetails round = roundDetailsRepo.findById(id)
                                .orElseThrow(() -> new NotFoundException(
                                                "Round not found with id : "
                                                                + id));

                roundDetailsRepo.delete(round);

                return new ResponseDTO(
                                HttpStatus.OK.value(),
                                "Round deleted successfully");
        }

        /*
         * Validation
         */
        private void validateRound(
                        RoundDetails round) {

                if (round.getRoundName() == null
                                || round.getRoundName().trim().isEmpty()) {

                        throw new IllegalArgumentException(
                                        "Round name is required");
                }

                if (round.getMaximumParticipants() == null
                                || round.getMaximumParticipants() <= 0) {

                        throw new IllegalArgumentException(
                                        "Maximum participants must be greater than 0");
                }

                if (round.getQualifyingCount() == null
                                || round.getQualifyingCount() <= 0) {

                        throw new IllegalArgumentException(
                                        "Qualifying count must be greater than 0");
                }

                if (round.getQualifyingCount() > round.getMaximumParticipants()) {

                        throw new IllegalArgumentException(
                                        "Qualifying count cannot be greater than maximum participants");
                }

                if (round.getTournamentId() == null
                                || round.getTournamentId().isBlank()) {

                        throw new IllegalArgumentException(
                                        "Tournament Id is required");
                }
        }

        public List<RoundDetailsWithMatchDTO> getWholeRoundByTournamentId(String id, String teamId) {

                // UserDetailsDTO user = (UserDetailsDTO)
                // SecurityContextHolder.getContext().getAuthentication().getPrincipal();

                List<RoundDetails> roundDetails = roundDetailsRepo.findByTournamentId(id);

                if (roundDetails == null) {
                        roundDetails = new ArrayList<>();
                }

                List<RoundDetailsWithMatchDTO> response = new ArrayList<>();

                for (RoundDetails round : roundDetails) {

                        RoundDetailsWithMatchDTO roundDTO = new RoundDetailsWithMatchDTO();
                        roundDTO.setId(round.getId());
                        roundDTO.setRoundName(round.getRoundName());
                        roundDTO.setMaximumParticipants(round.getMaximumParticipants());
                        roundDTO.setQualifyingCount(round.getQualifyingCount());
                        roundDTO.setTournamentId(round.getTournamentId());
                        roundDTO.setCreatedAt(round.getCreatedAt());

                        List<MatchDetailsWithParticipants> matchDTOList = new ArrayList<>();

                        if (round.getMatchDetails() != null) {

                                for (MatchDetails match : round.getMatchDetails()) {

                                        MatchDetailsWithParticipants matchDTO = new MatchDetailsWithParticipants();

                                        matchDTO.setId(match.getId());
                                        matchDTO.setStartTime(match.getStartTime());
                                        matchDTO.setEndTime(match.getEndTime());
                                        matchDTO.setStatus(match.getStatus());

                                        boolean isParticipant = false;

                                        if (match.getRoundDetails() != null) {
                                                matchDTO.setRoundId(match.getRoundDetails().getId());
                                        }

                                        List<MatchParticipantsResponseDTO> participantDTOList = new ArrayList<>();

                                        if (match.getMatchParticipants() != null) {

                                                for (MatchParticipants participant : match.getMatchParticipants()) {

                                                        MatchParticipantsResponseDTO participantDTO = new MatchParticipantsResponseDTO();

                                                        participantDTO.setId(participant.getId());
                                                        participantDTO.setStatus(participant.getStatus());
                                                        participantDTO.setTeamId(participant.getTeamId());

                                                        if (teamId == null || teamId.equals(participant.getTeamId())) {
                                                                isParticipant = true;
                                                        }

                                                        if (participant.getMatchDetails() != null) {
                                                                participantDTO.setMatchDetailsId(
                                                                                participant.getMatchDetails().getId());
                                                        }

                                                        participantDTOList.add(participantDTO);
                                                }
                                        }

                                        if (isParticipant)
                                                matchDTO.setGameCode(match.getGameCode());
                                        else
                                                matchDTO.setGameCode("You are not participating in this match");

                                        matchDTO.setParticipants(participantDTOList);
                                        matchDTOList.add(matchDTO);
                                }
                        }

                        roundDTO.setMatches(matchDTOList);
                        response.add(roundDTO);
                }

                return response;
        }

}
