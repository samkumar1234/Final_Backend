package com.esports.project.DTO;

import com.esports.project.enums.StatusMaster;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MatchParticipantsResponseDTO {
    private String id;
    private StatusMaster status;
    private String teamId;
    private String matchDetailsId;
}
