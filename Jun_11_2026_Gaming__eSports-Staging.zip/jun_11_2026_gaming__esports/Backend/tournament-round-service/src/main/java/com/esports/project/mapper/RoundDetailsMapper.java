package com.esports.project.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.RoundDetailsRequestDTO;
import com.esports.project.DTO.RoundDetailsResponseDTO;
import com.esports.project.DTO.RoundDetailsUpdateDTO;
import com.esports.project.entity.RoundDetails;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface RoundDetailsMapper {

    RoundDetails toEntity(
            RoundDetailsRequestDTO dto);

    RoundDetailsResponseDTO toResponseDTO(
            RoundDetails roundDetails);

    void updateRoundFromDTO(
            RoundDetailsUpdateDTO dto,
            @MappingTarget RoundDetails roundDetails);
}
