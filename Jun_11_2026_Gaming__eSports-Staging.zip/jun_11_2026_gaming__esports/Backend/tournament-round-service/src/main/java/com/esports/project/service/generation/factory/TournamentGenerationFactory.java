package com.esports.project.service.generation.factory;

import org.springframework.stereotype.Service;

import com.esports.project.enums.TournamentFormat;
import com.esports.project.service.generation.strategy.RoundRobinGenerationStrategy;
import com.esports.project.service.generation.strategy.SingleEliminationGenerationStrategy;
import com.esports.project.service.generation.strategy.TournamentGenerationStrategy;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TournamentGenerationFactory {

    private final SingleEliminationGenerationStrategy singleElimination;
    private final RoundRobinGenerationStrategy roundRobin;

    public TournamentGenerationStrategy getStrategy(
            TournamentFormat format) {

        System.out.println("Factory : 222222222222222222222222" + format.toString());

        return switch (format) {

            case SINGLE_ELIMINATION -> singleElimination;

            case ROUND_ROBIN -> roundRobin;
        };
    }
}
