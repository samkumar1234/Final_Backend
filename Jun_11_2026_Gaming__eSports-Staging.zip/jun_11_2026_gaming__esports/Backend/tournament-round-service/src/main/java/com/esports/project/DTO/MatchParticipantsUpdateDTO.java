package com.esports.project.DTO;

import com.esports.project.enums.StatusMaster;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MatchParticipantsUpdateDTO {

    private StatusMaster status;
}