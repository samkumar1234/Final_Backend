package com.esports.project.DTO;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ParticipantDetails{
    public ParticipantDetails(String teamId){
        this.teamId = teamId;
        this.participantIds = new ArrayList<>();
    }
    private String teamId;
    private List<String> participantIds;
}
