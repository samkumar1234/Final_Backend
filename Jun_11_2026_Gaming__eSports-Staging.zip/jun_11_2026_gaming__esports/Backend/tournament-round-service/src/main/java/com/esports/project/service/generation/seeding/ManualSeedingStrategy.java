package com.esports.project.service.generation.seeding;

import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.ParticipantDetails;
import com.esports.project.service.generation.strategy.SeedingStrategy;

@Service
public class ManualSeedingStrategy
        implements SeedingStrategy {

    @Override
    public List<ParticipantDetails> process(
            List<ParticipantDetails> participants) {

        return participants;
    }
}