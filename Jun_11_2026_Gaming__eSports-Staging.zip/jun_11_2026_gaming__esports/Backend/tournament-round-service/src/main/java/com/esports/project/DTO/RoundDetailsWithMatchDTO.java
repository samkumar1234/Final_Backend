package com.esports.project.DTO;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoundDetailsWithMatchDTO {
    private String id;
    private String roundName;
    private Integer maximumParticipants;
    private Integer qualifyingCount;
    private String tournamentId;
    private LocalDateTime createdAt;
    private List<MatchDetailsWithParticipants> matches;
}
