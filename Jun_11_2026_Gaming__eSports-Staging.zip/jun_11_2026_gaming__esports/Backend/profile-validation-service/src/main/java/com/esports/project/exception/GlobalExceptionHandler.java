package com.esports.project.exception;

import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.esports.project.DTO.ExceptionDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@ControllerAdvice
public class GlobalExceptionHandler {
    
    public GlobalExceptionHandler(HttpSession httpSession){}


    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ExceptionDTO> handleNotFoundException(final NotFoundException exception,HttpServletRequest request){
        ExceptionDTO exceptionMessage = new ExceptionDTO(
                                            HttpStatus.NOT_FOUND.value(),
                                            HttpStatus.NOT_FOUND.getReasonPhrase(),
                                            exception.getMessage(),
                                            request.getRequestURI());

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(exceptionMessage);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ExceptionDTO> handleIllegalArgumentException(final IllegalArgumentException exception,HttpServletRequest request){
        ExceptionDTO exceptionMessage = new ExceptionDTO(
                                            HttpStatus.BAD_REQUEST.value(),
                                            HttpStatus.BAD_REQUEST.getReasonPhrase(),
                                            exception.getMessage(),
                                            request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exceptionMessage);
    }


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ExceptionDTO> handleValidationException(
            MethodArgumentNotValidException exception,
            HttpServletRequest request) {

        String errorMessage = exception.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .collect(Collectors.joining(", "));

        ExceptionDTO exceptionMessage = new ExceptionDTO(
                HttpStatus.BAD_REQUEST.value(),
                HttpStatus.BAD_REQUEST.getReasonPhrase(),
                errorMessage,
                request.getRequestURI());

        return ResponseEntity.badRequest().body(exceptionMessage);
    }
}
