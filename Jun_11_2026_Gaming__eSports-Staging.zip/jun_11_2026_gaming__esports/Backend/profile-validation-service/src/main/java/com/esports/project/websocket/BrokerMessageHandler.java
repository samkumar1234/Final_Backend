package com.esports.project.websocket;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.DTO.SocialMediaValidationEvent;
import com.esports.project.DTO.SocialMediaValidationResultEvent;
import com.esports.project.service.SocialMediaValidationPublisher;
import com.esports.project.service.SocialMediaValidationService;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class BrokerMessageHandler
        extends TextWebSocketHandler {

    private final SocialMediaValidationService validationService;
    private final SocialMediaValidationPublisher publisher;
    private final ObjectMapper objectMapper;

    @Override
    protected void handleTextMessage(
            WebSocketSession session,
            TextMessage message)
            throws Exception {

        String payload =
                message.getPayload();

        if (!payload.trim()
                .startsWith("{")) {
            return;
        }

        BrokerMessage brokerMessage =
                objectMapper.readValue(
                        payload,
                        BrokerMessage.class);

        if ("socialmedia.validateinfluencer"
                .equals(
                        brokerMessage.getTopic())) {

            SocialMediaValidationEvent event =
                    objectMapper.convertValue(
                            brokerMessage.getPayload(),
                            SocialMediaValidationEvent.class);

            SocialMediaValidationResultEvent result =
                    validationService.validate(event);

            publisher.publishValidationCompleted(result);

            BrokerMessage ack =
                    new BrokerMessage();

            ack.setType("ACK");
            ack.setTopic(
                    brokerMessage.getTopic());

            ack.setOffset(
                    brokerMessage.getOffset());

            session.sendMessage(
                    new TextMessage(
                            objectMapper.writeValueAsString(
                                    ack)));
        }
    }
}