package com.esports.project.service.mock;

import java.util.Map;

public class MockYoutubeAccounts {

    public static final Map<String, Long> ACCOUNTS =
            Map.of(
                    "mrbeast", 400_000_000L,
                    "pewdiepie", 110_000_000L,
                    "carryminati", 45_000_000L,
                    "techburner", 15_000_000L,
                    "bbkivines", 27_000_000L,
                    "markiplier", 38_000_000L,
                    "sidemen", 22_000_000L,
                    "jacksepticeye", 32_000_000L,
                    "ashishchanchlani", 31_000_000L,
                    "sandeepmaheshwari", 29_000_000L
            );

}
