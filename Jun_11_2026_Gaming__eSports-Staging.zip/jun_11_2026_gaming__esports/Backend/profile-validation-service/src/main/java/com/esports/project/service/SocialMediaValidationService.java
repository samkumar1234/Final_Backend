package com.esports.project.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.SocialMediaValidationEvent;
import com.esports.project.DTO.SocialMediaValidationResultEvent;
import com.esports.project.service.mock.MockInstagramAccounts;
import com.esports.project.service.mock.MockYoutubeAccounts;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SocialMediaValidationService {


    public SocialMediaValidationResultEvent validate(
            SocialMediaValidationEvent event) {

        SocialMediaValidationResultEvent result = new SocialMediaValidationResultEvent();

        result.setId(event.getId());

        if ("YOUTUBE".equalsIgnoreCase(
                event.getPlatform())) {

            validateYoutube(event, result);

        } else if ("INSTAGRAM".equalsIgnoreCase(
                event.getPlatform())) {

            validateInstagram(event, result);
        }

        System.out.println("result : " + result.toString());
        return result;
    }

    private void validateYoutube(
            SocialMediaValidationEvent event,
            SocialMediaValidationResultEvent result) {

        Long subscribers = MockYoutubeAccounts.ACCOUNTS
                .get(event.getAccountName());

        if (subscribers == null) {

            result.setStatus("FAILED");
            return;
        }

        result.setSubscriberCount(subscribers);
        result.setFollowersCount(subscribers);

        calculateMetrics(result);

        result.setStatus("VALIDATED");
    }

    private void validateInstagram(
            SocialMediaValidationEvent event,
            SocialMediaValidationResultEvent result) {

        Long followers = MockInstagramAccounts.ACCOUNTS
                .get(event.getAccountName());

        if (followers == null) {

            result.setStatus("FAILED");
            return;
        }

        result.setFollowersCount(followers);

        calculateMetrics(result);

        result.setStatus("VALIDATED");
    }

    private void calculateMetrics(
            SocialMediaValidationResultEvent result) {

        long followers = result.getFollowersCount();

        long views = followers * 12;

        long likes = followers / 5;

        long comments = followers / 50;

        result.setTotalViews(views);
        result.setTotalLikes(likes);
        result.setTotalComments(comments);

        BigDecimal engagementRate = BigDecimal.valueOf(
                (likes + comments) * 100.0
                        / followers);

        result.setEngagementRate(
                engagementRate);

        BigDecimal score = engagementRate.multiply(
                BigDecimal.valueOf(5));

        if (score.doubleValue() > 100) {
            score = BigDecimal.valueOf(100);
        }

        result.setGenuineInfluencerScore(score);

        if (score.doubleValue() >= 85) {

            result.setInfluencerRating(
                    "PLATINUM");

        } else if (score.doubleValue() >= 70) {

            result.setInfluencerRating(
                    "GOLD");

        } else if (score.doubleValue() >= 50) {

            result.setInfluencerRating(
                    "SILVER");

        } else {

            result.setInfluencerRating(
                    "BRONZE");
        }
    }
}
