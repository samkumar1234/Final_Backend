package com.esports.project.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SocialMediaValidationEvent {

    private String id;

    private String platform;

    private String accountName;

    private String profileUrl;

}
