package com.esports.project.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/user")
public class Test {

    @PreAuthorize("hasRole('PLAYER')")
    @GetMapping()
    public String getGreeting(){
        return "User end point";
    }
    
}
