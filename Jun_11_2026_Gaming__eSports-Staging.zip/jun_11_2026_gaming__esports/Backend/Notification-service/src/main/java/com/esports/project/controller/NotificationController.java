package com.esports.project.controller;

import java.util.List;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.esports.project.entity.Notification;
import com.esports.project.service.NotificationService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

//     @PostMapping
// public ResponseEntity<NotificationResponseDTO> create(
//         @Valid @RequestBody NotificationRequestDTO request) {

//     return ResponseEntity.ok(
//             notificationService.createNotification(request));
// }

    @GetMapping
    public ResponseEntity<List<Notification>> getAll() {

        return ResponseEntity.ok(
                notificationService.getAllNotifications());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Notification> getById(
            @PathVariable String id) {

        return ResponseEntity.ok(
                notificationService.getNotificationById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Notification> update(
            @PathVariable String id,
            @RequestBody Notification notification) {

        return ResponseEntity.ok(
                notificationService.updateNotification(id, notification));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(
            @PathVariable String id) {

        notificationService.deleteNotification(id);

        return ResponseEntity.ok("Notification deleted successfully");
    }

    @PatchMapping("/{id}/read")
    public ResponseEntity<Notification> markAsRead(
            @PathVariable String id) {

        return ResponseEntity.ok(
                notificationService.markAsRead(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Notification>> getByUser(
            @PathVariable String userId) {

        return ResponseEntity.ok(
                notificationService.getNotificationsByUser(userId));
    }
}