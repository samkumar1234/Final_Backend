package com.esports.project.DTO;

import lombok.Data;

@Data
public class NotificationEventDTO {
    private String userId;
    private String title;
    private String message;
}
