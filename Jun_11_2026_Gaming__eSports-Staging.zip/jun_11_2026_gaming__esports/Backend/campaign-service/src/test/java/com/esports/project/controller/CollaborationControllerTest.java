package com.esports.project.controller;

import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.esports.project.DTO.CollaborationRequestDTO;
import com.esports.project.DTO.CollaborationRequestInfluencerDTO;
import com.esports.project.entity.CollaborationRequest;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.GlobalExceptionHandler;
import com.esports.project.exception.NotFoundException;
import com.esports.project.service.interfaces.CollaborationService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class CollaborationControllerTest {

    private MockMvc mockMvc;

    private ObjectMapper objectMapper;

    @Mock
    private CollaborationService collaborationService;

    @InjectMocks
    private CollaborationController collaborationController;

    @BeforeEach
    void setUp() {

        objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();

        mockMvc = MockMvcBuilders
                .standaloneSetup(collaborationController)
                .setControllerAdvice(new GlobalExceptionHandler(null))
                .build();
    }

    private CollaborationRequest getCollaboration() {

        CollaborationRequest request =
                new CollaborationRequest();

        request.setId("1");
        request.setTitle("PUBG Collaboration");
        request.setDescription("Gaming promotion");
        request.setProposedAmount(
                new BigDecimal("5000"));
        request.setStatus(StatusMaster.PENDING);
        request.setCreatedAt(LocalDateTime.now());

        return request;
    }

    private CollaborationRequestDTO getBrandRequest() {

        CollaborationRequestDTO dto =
                new CollaborationRequestDTO();

        dto.setCampaignId("campaign1");
        dto.setUserId("user1");
        dto.setTitle("Brand Request");
        dto.setDescription("Description");
        dto.setProposedAmount(
                new BigDecimal("1000"));

        return dto;
    }

    private CollaborationRequestInfluencerDTO getInfluencerRequest() {

        CollaborationRequestInfluencerDTO dto =
                new CollaborationRequestInfluencerDTO();

        dto.setCampaignId("campaign1");
        dto.setTitle("Influencer Request");
        dto.setDescription("Description");
        dto.setProposedAmount(
                new BigDecimal("2000"));

        return dto;
    }

    @Test
    void createByBrand_Success() throws Exception {

        when(collaborationService.createByBrand(any()))
                .thenReturn(getCollaboration());

        mockMvc.perform(post("/api/collaborations/brand")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(
                                getBrandRequest())))
                .andExpect(status().isOk());
    }

    @Test
    void createByInfluencer_Success() throws Exception {

        when(collaborationService.createByInfluencer(any()))
                .thenReturn(getCollaboration());

        mockMvc.perform(post("/api/collaborations/influencer")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(
                                getInfluencerRequest())))
                .andExpect(status().isOk());
    }

    @Test
    void getById_Success() throws Exception {

        when(collaborationService.getById("1"))
                .thenReturn(getCollaboration());

        mockMvc.perform(
                get("/api/collaborations/1"))
                .andExpect(status().isOk());
    }

    @Test
    void getById_NotFound() throws Exception {

        when(collaborationService.getById("1"))
                .thenThrow(
                        new NotFoundException(
                                "Collaboration not found"));

        mockMvc.perform(
                get("/api/collaborations/1"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getSent_Success() throws Exception {

        when(collaborationService.getSent())
                .thenReturn(
                        List.of(getCollaboration()));

        mockMvc.perform(
                get("/api/collaborations/sent"))
                .andExpect(status().isOk());
    }

    @Test
    void getSent_EmptyList() throws Exception {

        when(collaborationService.getSent())
                .thenReturn(Collections.emptyList());

        mockMvc.perform(
                get("/api/collaborations/sent"))
                .andExpect(status().isOk());
    }

    @Test
    void getReceived_Success() throws Exception {

        when(collaborationService.getReceived())
                .thenReturn(
                        List.of(getCollaboration()));

        mockMvc.perform(
                get("/api/collaborations/received"))
                .andExpect(status().isOk());
    }

    @Test
    void getReceived_EmptyList() throws Exception {

        when(collaborationService.getReceived())
                .thenReturn(Collections.emptyList());

        mockMvc.perform(
                get("/api/collaborations/received"))
                .andExpect(status().isOk());
    }

    @Test
    void getByStatus_Success() throws Exception {

        when(collaborationService.getByStatus(
                StatusMaster.PENDING))
                .thenReturn(
                        List.of(getCollaboration()));

        mockMvc.perform(
                get("/api/collaborations/status/PENDING"))
                .andExpect(status().isOk());
    }

    @Test
    void getByCampaign_Success() throws Exception {

        when(collaborationService.getByCampaign(
                "campaign1"))
                .thenReturn(
                        List.of(getCollaboration()));

        mockMvc.perform(
                get("/api/collaborations/campaign/campaign1"))
                .andExpect(status().isOk());
    }

    @Test
    void getByCampaign_NotFound() throws Exception {

        when(collaborationService.getByCampaign(
                "campaign1"))
                .thenThrow(
                    new NotFoundException(
                            "Campaign not found"));

        mockMvc.perform(
                get("/api/collaborations/campaign/campaign1"))
                .andExpect(status().isNotFound());
    }

    @Test
    void accept_Success() throws Exception {

        CollaborationRequest request =
                getCollaboration();

        request.setStatus(StatusMaster.ACCEPTED);

        when(collaborationService.accept("1"))
                .thenReturn(request);

        mockMvc.perform(
                patch("/api/collaborations/1/accept"))
                .andExpect(status().isOk());
    }

    @Test
    void reject_Success() throws Exception {

        CollaborationRequest request =
                getCollaboration();

        request.setStatus(StatusMaster.REJECTED);

        when(collaborationService.reject("1"))
                .thenReturn(request);

        mockMvc.perform(
                patch("/api/collaborations/1/reject"))
                .andExpect(status().isOk());
    }

    @Test
    void complete_Success() throws Exception {

        CollaborationRequest request =
                getCollaboration();

        request.setStatus(
                StatusMaster.COMPLETED);

        when(collaborationService.complete("1"))
                .thenReturn(request);

        mockMvc.perform(
                patch("/api/collaborations/1/complete"))
                .andExpect(status().isOk());
    }

    @Test
    void accept_NotFound() throws Exception {

        when(collaborationService.accept("1"))
                .thenThrow(
                        new NotFoundException(
                                "Collaboration not found"));

        mockMvc.perform(
                patch("/api/collaborations/1/accept"))
                .andExpect(status().isNotFound());
    }

    @Test
    void reject_NotFound() throws Exception {

        when(collaborationService.reject("1"))
                .thenThrow(
                        new NotFoundException(
                                "Collaboration not found"));

        mockMvc.perform(
                patch("/api/collaborations/1/reject"))
                .andExpect(status().isNotFound());
    }

    @Test
    void complete_NotFound() throws Exception {

        when(collaborationService.complete("1"))
                .thenThrow(
                        new NotFoundException(
                                "Collaboration not found"));

        mockMvc.perform(
                patch("/api/collaborations/1/complete"))
                .andExpect(status().isNotFound());
    }

    @Test
    void delete_Success() throws Exception {

        doNothing().when(
                collaborationService)
                .delete("1");

        mockMvc.perform(
                delete("/api/collaborations/1"))
                .andExpect(status().isOk());
    }

    @Test
    void delete_NotFound() throws Exception {

        doNothing().when(
                collaborationService)
                .delete("1");

        mockMvc.perform(
                delete("/api/collaborations/1"))
                .andExpect(status().isOk());
    }
}