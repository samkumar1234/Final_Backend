package com.esports.project.controller;

import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.CampaignRequestDTO;
import com.esports.project.DTO.UpdateCampaignRequestDTO;
import com.esports.project.entity.Campaign;
import com.esports.project.enums.CampaignType;
import com.esports.project.service.interfaces.CampaignService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/campaigns")
@RequiredArgsConstructor
public class CampaignController {

	private final CampaignService campaignService;

	// public CampaignController(CampaignService campaignService) {
	//     this.campaignService = campaignService;
	// }

	// @PreAuthorize("hasAuthority('CAMPAIGN_CREATE')")
    @PostMapping
    public ResponseEntity<?> createCampaign(
            @RequestBody CampaignRequestDTO request) {

        return ResponseEntity.ok(
                campaignService.createCampaign(request));
    }

	// @PreAuthorize("hasAuthority('CAMPAIGN_READALL')")
    @GetMapping
    public ResponseEntity<?> getAllCampaigns() {

        return ResponseEntity.ok(
                campaignService.getAllCampaigns());
    }

	// @PreAuthorize("hasAuthority('CAMPAIGN_READBY_ID')")
    @GetMapping("/{campaignId}")
    public ResponseEntity<?> getCampaignById(
            @PathVariable String campaignId) {

        return ResponseEntity.ok(
                campaignService.getCampaignById(campaignId));
    }

	// @PreAuthorize("hasAuthority('CAMPAIGN_READBY_SELF')")
    @GetMapping("/my")
    public ResponseEntity<?> getMyCampaigns() {

        return ResponseEntity.ok(
                campaignService.getMyCampaigns());
    }

	// @PreAuthorize("hasAuthority('CAMPAIGN_READBY_TYPE')")
    @GetMapping("/type/{campaignType}")
    public ResponseEntity<?> getCampaignByType(
            @PathVariable CampaignType campaignType) {

        return ResponseEntity.ok(
                campaignService.getCampaignByType(campaignType));
    }

	// @PreAuthorize("hasAuthority('CAMPAIGN_READBY_TYPE_SELF')")
    @GetMapping("/my/type/{campaignType}")
    public ResponseEntity<?> getMyCampaignsByType(
            @PathVariable CampaignType campaignType) {

        return ResponseEntity.ok(
                campaignService.getMyCampaignsByType(campaignType));
    }

	// @PreAuthorize("hasAuthority('CAMPAIGN_UPDATE')")
    @PutMapping("/{campaignId}")
public ResponseEntity<Campaign> updateCampaign(
        @PathVariable String campaignId,
        @RequestBody UpdateCampaignRequestDTO request) {

    return ResponseEntity.ok(
            campaignService.updateCampaign(
                    campaignId,
                    request));
}

	// @PreAuthorize("hasAuthority('CAMPAIGN_DELETE')")
    @DeleteMapping("/{campaignId}")
    public ResponseEntity<?> deleteCampaign(
            @PathVariable String campaignId) {

        campaignService.deleteCampaign(campaignId);

        return ResponseEntity.ok("Campaign deleted");
    }
	// @PreAuthorize("hasAuthority('CAMPAIGN_ACTIVE')")
    @GetMapping("/active")
public ResponseEntity<?> getActiveCampaigns() {

    return ResponseEntity.ok(
            campaignService.getActiveCampaigns());
}
// @PreAuthorize("hasAuthority('CAMPAIGN_STATISTICS')")
@GetMapping("/my/statistics")
public ResponseEntity<?> getMyStatistics() {

    return ResponseEntity.ok(
            campaignService.getMyStatistics());
}
}