package com.esports.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.CollaborationRequest;
import com.esports.project.enums.StatusMaster;

@Repository
public interface CollaborationRepository
        extends JpaRepository<CollaborationRequest, String> {

    List<CollaborationRequest> findBySenderId(
            String senderId);

    List<CollaborationRequest> findByUserId(
            String userId);

    List<CollaborationRequest> findByStatus(
            StatusMaster status);

    List<CollaborationRequest> findBySenderIdAndStatus(
            String senderId,
            StatusMaster status);

    List<CollaborationRequest> findByUserIdAndStatus(
            String userId,
            StatusMaster status);

    List<CollaborationRequest> findByCampaignId(
            String campaignId);
            boolean existsByCampaignIdAndSenderId(
        String campaignId,
        String senderId);
}
