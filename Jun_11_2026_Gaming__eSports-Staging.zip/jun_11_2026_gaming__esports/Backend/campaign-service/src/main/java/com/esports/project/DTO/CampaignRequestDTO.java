package com.esports.project.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.CampaignType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CampaignRequestDTO {

    private CampaignType campaignType;

    private String campaignName;

    private LocalDateTime startDate;

    private LocalDateTime endDate;

    private String description;

    private BigDecimal totalBudget;

    private BigDecimal influencerCost;

    private BigDecimal additionalExpenses;
    
    

	public CampaignRequestDTO() {
		super();
	}

	public CampaignRequestDTO(CampaignType campaignType, String campaignName, LocalDateTime startDate,
			LocalDateTime endDate, String description, BigDecimal totalBudget, BigDecimal influencerCost,
			BigDecimal additionalExpenses) {
		super();
		this.campaignType = campaignType;
		this.campaignName = campaignName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.description = description;
		this.totalBudget = totalBudget;
		this.influencerCost = influencerCost;
		this.additionalExpenses = additionalExpenses;
	}

	public CampaignType getCampaignType() {
		return campaignType;
	}

	public void setCampaignType(CampaignType campaignType) {
		this.campaignType = campaignType;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getTotalBudget() {
		return totalBudget;
	}

	public void setTotalBudget(BigDecimal totalBudget) {
		this.totalBudget = totalBudget;
	}

	public BigDecimal getInfluencerCost() {
		return influencerCost;
	}

	public void setInfluencerCost(BigDecimal influencerCost) {
		this.influencerCost = influencerCost;
	}

	public BigDecimal getAdditionalExpenses() {
		return additionalExpenses;
	}

	public void setAdditionalExpenses(BigDecimal additionalExpenses) {
		this.additionalExpenses = additionalExpenses;
	}
    
    
}