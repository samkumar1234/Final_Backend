package com.esports.project.enums;

public enum StatusMaster {

    ACTIVE,
    INACTIVE,

    PENDING,
    ACCEPTED,
    REJECTED,
    COMPLETED
}