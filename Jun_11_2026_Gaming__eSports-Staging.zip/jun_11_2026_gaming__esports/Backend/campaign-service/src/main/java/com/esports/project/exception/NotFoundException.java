package com.esports.project.exception;

@SuppressWarnings("serial")
public class NotFoundException extends CustomException{
    public NotFoundException(String message){
        super(message);
    }
}
