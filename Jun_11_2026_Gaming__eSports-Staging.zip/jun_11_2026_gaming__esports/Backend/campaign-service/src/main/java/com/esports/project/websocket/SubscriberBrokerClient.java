package com.esports.project.websocket;

import java.net.URI;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.service.JwtService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class SubscriberBrokerClient {

    private final BrokerClientHandler handler;
    private final JwtService jwtService;

    private WebSocketSession session;

    private final ObjectMapper objectMapper =
            new ObjectMapper();

    private static final List<String> TOPICS =
            List.of();

    @PostConstruct
    public void init() {
        connect();
    }

    public synchronized void connect() {

        try {

            if (session != null &&
                    session.isOpen()) {
                return;
            }

            String token =
                    jwtService.generateToken(
                            "campaign-service");

            StandardWebSocketClient client =
                    new StandardWebSocketClient();

            session = client.execute(
                    handler,
                    null,
                    URI.create(
                            "ws://localhost:8085/broker?token="
                                    + token))
                    .get();

            for (String topic : TOPICS) {

                subscribe(topic);
            }

            System.out.println(
                    "Subscriber connected");

        } catch (Exception ex) {

            System.out.println(
                    "Broker unavailable");
        }
    }

    @Scheduled(fixedDelay = 6000)
    public void reconnect() {

        if (session == null ||
                !session.isOpen()) {

            System.out.println(
                    "Subscriber reconnecting...");

            connect();
        }
    }

    public void subscribe(
            String topic)
            throws Exception {

        BrokerMessage message =
                new BrokerMessage();

        message.setType("SUBSCRIBE");
        message.setTopic(topic);

        session.sendMessage(
                new TextMessage(
                        objectMapper.writeValueAsString(
                                message)));

        System.out.println(
                "Subscribed -> " + topic);
    }

    public void ack(
            String topic,
            Long offset)
            throws Exception {

        BrokerMessage ack =
                new BrokerMessage();

        ack.setType("ACK");
        ack.setTopic(topic);
        ack.setOffset(offset);

        session.sendMessage(
                new TextMessage(
                        objectMapper.writeValueAsString(
                                ack)));

        System.out.println(
                "ACK -> " + offset);
    }
}