package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CampaignStatisticsDTO {

    private long totalCampaigns;

    private long activeCampaigns;

    private long completedCampaigns;

    private long pendingCampaigns;

    private long inactiveCampaigns;

	public CampaignStatisticsDTO() {
		super();
	}

	public CampaignStatisticsDTO(long totalCampaigns, long activeCampaigns, long completedCampaigns,
			long pendingCampaigns, long inactiveCampaigns) {
		super();
		this.totalCampaigns = totalCampaigns;
		this.activeCampaigns = activeCampaigns;
		this.completedCampaigns = completedCampaigns;
		this.pendingCampaigns = pendingCampaigns;
		this.inactiveCampaigns = inactiveCampaigns;
	}

	public long getTotalCampaigns() {
		return totalCampaigns;
	}

	public void setTotalCampaigns(long totalCampaigns) {
		this.totalCampaigns = totalCampaigns;
	}

	public long getActiveCampaigns() {
		return activeCampaigns;
	}

	public void setActiveCampaigns(long activeCampaigns) {
		this.activeCampaigns = activeCampaigns;
	}

	public long getCompletedCampaigns() {
		return completedCampaigns;
	}

	public void setCompletedCampaigns(long completedCampaigns) {
		this.completedCampaigns = completedCampaigns;
	}

	public long getPendingCampaigns() {
		return pendingCampaigns;
	}

	public void setPendingCampaigns(long pendingCampaigns) {
		this.pendingCampaigns = pendingCampaigns;
	}

	public long getInactiveCampaigns() {
		return inactiveCampaigns;
	}

	public void setInactiveCampaigns(long inactiveCampaigns) {
		this.inactiveCampaigns = inactiveCampaigns;
	}
    
    
}