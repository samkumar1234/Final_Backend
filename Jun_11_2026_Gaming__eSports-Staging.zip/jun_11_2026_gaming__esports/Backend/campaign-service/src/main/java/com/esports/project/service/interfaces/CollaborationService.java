package com.esports.project.service.interfaces;

import java.util.List;

import com.esports.project.DTO.CollaborationRequestDTO;
import com.esports.project.DTO.CollaborationRequestInfluencerDTO;
import com.esports.project.entity.CollaborationRequest;
import com.esports.project.enums.StatusMaster;

public interface CollaborationService {

    CollaborationRequest createByBrand(
            CollaborationRequestDTO request);

    CollaborationRequest createByInfluencer(
            CollaborationRequestInfluencerDTO request);

    List<CollaborationRequest> getSent();

    List<CollaborationRequest> getReceived();

    List<CollaborationRequest> getByStatus(
            StatusMaster status);

    CollaborationRequest accept(
            String collaborationId);

    CollaborationRequest reject(
            String collaborationId);

    CollaborationRequest complete(
            String collaborationId);

    void delete(
            String collaborationId);

    CollaborationRequest getById(
            String collaborationId);

    List<CollaborationRequest> getByCampaign(
            String campaignId);
}
