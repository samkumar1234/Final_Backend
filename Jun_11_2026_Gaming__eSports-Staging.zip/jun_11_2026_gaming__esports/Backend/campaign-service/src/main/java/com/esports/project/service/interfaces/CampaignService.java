package com.esports.project.service.interfaces;

import java.util.List;

import com.esports.project.DTO.CampaignRequestDTO;
import com.esports.project.DTO.CampaignStatisticsDTO;
import com.esports.project.DTO.UpdateCampaignRequestDTO;
import com.esports.project.entity.Campaign;
import com.esports.project.enums.CampaignType;

public interface CampaignService {

    Campaign createCampaign(CampaignRequestDTO request);

    List<Campaign> getAllCampaigns();

    Campaign getCampaignById(String campaignId);

    List<Campaign> getMyCampaigns();

    List<Campaign> getCampaignByType(CampaignType campaignType);

    List<Campaign> getMyCampaignsByType(CampaignType campaignType);

    Campaign updateCampaign(
            String campaignId,
            UpdateCampaignRequestDTO request);

    void deleteCampaign(String campaignId);

    List<Campaign> getActiveCampaigns();

    CampaignStatisticsDTO getMyStatistics();
}