package com.esports.project.DTO;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CollaborationRequestInfluencerDTO {

    private String campaignId;

   
    private String title;

    private String description;

    private BigDecimal proposedAmount;

	public CollaborationRequestInfluencerDTO() {
		super();
	}

	public CollaborationRequestInfluencerDTO(String campaignId, String title, String description,
			BigDecimal proposedAmount) {
		super();
		this.campaignId = campaignId;
		this.title = title;
		this.description = description;
		this.proposedAmount = proposedAmount;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getProposedAmount() {
		return proposedAmount;
	}

	public void setProposedAmount(BigDecimal proposedAmount) {
		this.proposedAmount = proposedAmount;
	}
    
}