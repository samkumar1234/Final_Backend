package com.esports.project.enums;


public enum CampaignType{
    BRAND_AWARENESS,
    PRODUCT_PROMOTION,
    APP_INSTALL,
    TOURNAMENT_PROMOTION,
    EVENT_PROMOTION,
    GIVEAWAY,
}

