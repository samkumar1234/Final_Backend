package com.esports.project.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esports.project.DTO.CollaborationRequestDTO;
import com.esports.project.DTO.CollaborationRequestInfluencerDTO;
import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.Campaign;
import com.esports.project.entity.CollaborationRequest;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.UnauthorizedException;
import com.esports.project.repository.CampaignRepository;
import com.esports.project.repository.CollaborationRepository;
import com.esports.project.service.EventPublisher;
import com.esports.project.service.interfaces.CollaborationService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class CollaborationServiceImpl
                implements CollaborationService {

        private final CollaborationRepository collaborationRepository;
        private final EventPublisher publisher;

        private final CampaignRepository campaignRepository;

        private String getCurrentUserId() {

                UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder
                                .getContext()
                                .getAuthentication()
                                .getPrincipal();

                return user.getUserId();
        }

        private void validateRequest(
                        CollaborationRequestDTO request) {

                if (request == null) {
                        throw new BadRequestException(
                                        "Request cannot be null");
                }

                if (request.getCampaignId() == null
                                || request.getCampaignId().isBlank()) {

                        throw new BadRequestException(
                                        "Campaign Id is required");
                }

                if (request.getTitle() == null
                                || request.getTitle().isBlank()) {

                        throw new BadRequestException(
                                        "Title is required");
                }

                if (request.getDescription() == null
                                || request.getDescription().isBlank()) {

                        throw new BadRequestException(
                                        "Description is required");
                }

                if (request.getProposedAmount() == null) {

                        throw new BadRequestException(
                                        "Proposed amount is required");
                }

                if (request.getProposedAmount().doubleValue() <= 0) {

                        throw new BadRequestException(
                                        "Proposed amount must be greater than 0");
                }
        }

        private void validateRequestInfluencer(
                        CollaborationRequestInfluencerDTO request) {

                if (request == null) {
                        throw new BadRequestException(
                                        "Request cannot be null");
                }

                if (request.getCampaignId() == null
                                || request.getCampaignId().isBlank()) {

                        throw new BadRequestException(
                                        "Campaign Id is required");
                }

                if (request.getTitle() == null
                                || request.getTitle().isBlank()) {

                        throw new BadRequestException(
                                        "Title is required");
                }

                if (request.getDescription() == null
                                || request.getDescription().isBlank()) {

                        throw new BadRequestException(
                                        "Description is required");
                }

                if (request.getProposedAmount() == null) {

                        throw new BadRequestException(
                                        "Proposed amount is required");
                }

                if (request.getProposedAmount().doubleValue() <= 0) {

                        throw new BadRequestException(
                                        "Proposed amount must be greater than 0");
                }
        }

        @Override
        public CollaborationRequest createByBrand(
                        CollaborationRequestDTO request) {

                validateRequest(request);

                if (request.getUserId() == null
                                || request.getUserId().isBlank()) {

                        throw new BadRequestException(
                                        "Influencer Id is required");
                }

                Campaign campaign = campaignRepository.findById(
                                request.getCampaignId())
                                .orElseThrow(() -> new NotFoundException(
                                                "Campaign not found"));

                if (!campaign.getBrandId()
                                .equals(getCurrentUserId())) {

                        throw new UnauthorizedException(
                                        "You can create collaboration only for your campaign");
                }

                CollaborationRequest collaboration = new CollaborationRequest();

                collaboration.setCampaign(campaign);
                collaboration.setTitle(request.getTitle());
                collaboration.setDescription(
                                request.getDescription());

                collaboration.setProposedAmount(
                                request.getProposedAmount());

                collaboration.setSenderId(
                                getCurrentUserId());

                collaboration.setUserId(
                                request.getUserId());

                collaboration.setStatus(
                                StatusMaster.PENDING);

                collaboration.setCreatedAt(
                                LocalDateTime.now());

                collaboration.setUpdatedAt(
                                LocalDateTime.now());

                CollaborationRequest saved = collaborationRepository.save(collaboration);

                sendNotification(
                                saved.getUserId(),
                                "New Collaboration Request",
                                "You have received a collaboration request from a brand.");

                return saved;
        }

        @Override
        public CollaborationRequest createByInfluencer(
                        CollaborationRequestInfluencerDTO request) {

                validateRequestInfluencer(request);

                Campaign campaign = campaignRepository.findById(
                                request.getCampaignId())
                                .orElseThrow(() -> new NotFoundException(
                                                "Campaign not found"));

                CollaborationRequest collaboration = new CollaborationRequest();

                collaboration.setCampaign(campaign);

                collaboration.setTitle(
                                request.getTitle());

                collaboration.setDescription(
                                request.getDescription());

                collaboration.setProposedAmount(
                                request.getProposedAmount());

                collaboration.setSenderId(
                                getCurrentUserId());

                // Brand becomes receiver
                collaboration.setUserId(
                                campaign.getBrandId());

                collaboration.setStatus(
                                StatusMaster.PENDING);

                collaboration.setCreatedAt(
                                LocalDateTime.now());

                collaboration.setUpdatedAt(
                                LocalDateTime.now());

                CollaborationRequest saved = collaborationRepository.save(collaboration);

                sendNotification(
                                saved.getUserId(),
                                "New Collaboration Request",
                                "You have received a collaboration proposal from an influencer.");

                return saved;

                // return collaborationRepository.save(
                // collaboration);
        }

        @Override
        public List<CollaborationRequest> getSent() {

                return collaborationRepository
                                .findBySenderId(
                                                getCurrentUserId());
        }

        @Override
        public List<CollaborationRequest> getReceived() {

                return collaborationRepository
                                .findByUserId(
                                                getCurrentUserId());
        }

        @Override
        public List<CollaborationRequest> getByStatus(
                        StatusMaster status) {

                if (status == null) {

                        throw new BadRequestException(
                                        "Status is required");
                }

                List<CollaborationRequest> sent = collaborationRepository
                                .findBySenderIdAndStatus(
                                                getCurrentUserId(),
                                                status);

                List<CollaborationRequest> received = collaborationRepository
                                .findByUserIdAndStatus(
                                                getCurrentUserId(),
                                                status);

                sent.addAll(received);

                return sent;
        }

        @Override
        public CollaborationRequest accept(
                        String collaborationId) {

                CollaborationRequest collaboration = collaborationRepository
                                .findById(
                                                collaborationId)
                                .orElseThrow(() -> new NotFoundException(
                                                "Collaboration not found"));

                if (!collaboration.getUserId()
                                .equals(getCurrentUserId())) {

                        throw new UnauthorizedException(
                                        "Only receiver can accept");
                }

                if (collaboration.getStatus() != StatusMaster.PENDING) {

                        throw new BadRequestException(
                                        "Only pending requests can be accepted");
                }

                collaboration.setStatus(
                                StatusMaster.ACCEPTED);

                collaboration.setUpdatedAt(
                                LocalDateTime.now());

                CollaborationRequest saved = collaborationRepository.save(collaboration);

                sendNotification(
                                saved.getSenderId(),
                                "Collaboration Accepted",
                                "Your collaboration request has been accepted.");

                return saved;

                // return collaborationRepository.save(
                // collaboration);
        }

        @Override
        public CollaborationRequest reject(
                        String collaborationId) {

                CollaborationRequest collaboration = collaborationRepository
                                .findById(
                                                collaborationId)
                                .orElseThrow(() -> new NotFoundException(
                                                "Collaboration not found"));

                if (!collaboration.getUserId()
                                .equals(getCurrentUserId())) {

                        throw new UnauthorizedException(
                                        "Only receiver can reject");
                }

                if (collaboration.getStatus() != StatusMaster.PENDING) {

                        throw new BadRequestException(
                                        "Only pending requests can be rejected");
                }

                collaboration.setStatus(
                                StatusMaster.REJECTED);

                collaboration.setUpdatedAt(
                                LocalDateTime.now());

                CollaborationRequest saved = collaborationRepository.save(collaboration);

                sendNotification(
                                saved.getSenderId(),
                                "Collaboration Rejected",
                                "Your collaboration request has been rejected.");

                return saved;

                // return collaborationRepository.save(
                // collaboration);
        }

        @Override
        public CollaborationRequest complete(
                        String collaborationId) {

                CollaborationRequest collaboration = collaborationRepository
                                .findById(
                                                collaborationId)
                                .orElseThrow(() -> new NotFoundException(
                                                "Collaboration not found"));

                boolean sender = collaboration.getSenderId()
                                .equals(getCurrentUserId());

                boolean receiver = collaboration.getUserId()
                                .equals(getCurrentUserId());

                if (!sender && !receiver) {

                        throw new UnauthorizedException(
                                        "You are not authorized");
                }

                if (collaboration.getStatus() != StatusMaster.ACCEPTED) {

                        throw new BadRequestException(
                                        "Only accepted collaborations can be completed");
                }

                collaboration.setStatus(
                                StatusMaster.COMPLETED);

                collaboration.setUpdatedAt(
                                LocalDateTime.now());

                CollaborationRequest saved = collaborationRepository.save(collaboration);

                sendNotification(
                                saved.getSenderId(),
                                "Collaboration Completed",
                                "Collaboration has been marked as completed.");

                sendNotification(
                                saved.getUserId(),
                                "Collaboration Completed",
                                "Collaboration has been marked as completed.");

                return saved;

                // return collaborationRepository.save(
                // collaboration);
        }

        @Override
        public void delete(
                        String collaborationId) {

                CollaborationRequest collaboration = collaborationRepository
                                .findById(
                                                collaborationId)
                                .orElseThrow(() -> new NotFoundException(
                                                "Collaboration not found"));

                if (!collaboration.getSenderId()
                                .equals(getCurrentUserId())) {

                        throw new UnauthorizedException(
                                        "Only creator can delete");
                }

                if (collaboration.getStatus() != StatusMaster.PENDING) {

                        throw new BadRequestException(
                                        "Only pending requests can be deleted");
                }
                sendNotification(
                                collaboration.getUserId(),
                                "Collaboration Request Cancelled",
                                "A pending collaboration request has been cancelled.");

                collaborationRepository.delete(
                                collaboration);
        }

        @Override
        public CollaborationRequest getById(
                        String collaborationId) {

                return collaborationRepository
                                .findById(
                                                collaborationId)
                                .orElseThrow(() -> new NotFoundException(
                                                "Collaboration not found"));
        }

        @Override
        public List<CollaborationRequest> getByCampaign(
                        String campaignId) {

                Campaign campaign = campaignRepository
                                .findById(campaignId)
                                .orElseThrow(() -> new NotFoundException(
                                                "Campaign not found"));

                return collaborationRepository
                                .findByCampaignId(
                                                campaign.getId());
        }

        private void sendNotification(
                        String userId,
                        String title,
                        String message) {

                try {

                        NotificationEventDTO notification = new NotificationEventDTO(
                                        userId,
                                        title,
                                        message);

                        publisher.publishNotification(
                                        notification);

                } catch (Exception e) {

                        System.out.println(
                                        "Campaign Notification Error : "
                                                        + e.getMessage());
                }
        }
}