package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.List;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.entity.AffiliateLink;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.AffiliateLinkRepository;

@ExtendWith(MockitoExtension.class)
class AffiliateLinkServiceTest {

    @Mock
    private AffiliateLinkRepository affiliateLinkRepository;

    @InjectMocks
    private AffiliateLinkService affiliateLinkService;

    @Test
    void getAffiliateLinkById_ShouldReturnAffiliateLink() {

        // Arrange
        AffiliateLink affiliateLink = new AffiliateLink();
        affiliateLink.setId("123");
        affiliateLink.setLinkName("Amazon Campaign");

        when(affiliateLinkRepository.findById("123"))
                .thenReturn(Optional.of(affiliateLink));

        // Act
        AffiliateLink result =
                affiliateLinkService.getAffiliateLinkById("123");

        // Assert
        assertNotNull(result);
        assertEquals("123", result.getId());
        assertEquals("Amazon Campaign", result.getLinkName());
    }

    @Test
    void getAffiliateLinkById_ShouldThrowNotFoundException() {

        // Arrange
        when(affiliateLinkRepository.findById("999"))
                .thenReturn(Optional.empty());

        // Act & Assert
        NotFoundException exception =
                assertThrows(
                        NotFoundException.class,
                        () -> affiliateLinkService
                                .getAffiliateLinkById("999"));

        assertEquals(
                "Affiliate Link not found with id : 999",
                exception.getMessage());
    }


@Test
void getAllAffiliateLinks_ShouldReturnAllLinks() {

    AffiliateLink link1 = new AffiliateLink();
    link1.setId("1");

    AffiliateLink link2 = new AffiliateLink();
    link2.setId("2");

    when(affiliateLinkRepository.findAll())
            .thenReturn(List.of(link1, link2));

    List<AffiliateLink> result =
            affiliateLinkService.getAllAffiliateLinks();

    assertEquals(2, result.size());
}

@Test
void updateAffiliateLink_ShouldUpdateAffiliateLink() {

    AffiliateLink existingLink = new AffiliateLink();
    existingLink.setId("123");
    existingLink.setLinkName("Old Campaign");

    AffiliateLink updatedLink = new AffiliateLink();
    updatedLink.setLinkName("New Campaign");

    when(affiliateLinkRepository.findById("123"))
            .thenReturn(Optional.of(existingLink));

    when(affiliateLinkRepository.save(existingLink))
            .thenReturn(existingLink);

    AffiliateLink result =
            affiliateLinkService.updateAffiliateLink(
                    "123",
                    updatedLink);

    assertEquals(
            "New Campaign",
            result.getLinkName());
}

@Test
void updateAffiliateLink_ShouldThrowNotFoundException() {

    AffiliateLink updatedLink = new AffiliateLink();

    when(affiliateLinkRepository.findById("123"))
            .thenReturn(Optional.empty());

    assertThrows(
            NotFoundException.class,
            () -> affiliateLinkService
                    .updateAffiliateLink(
                            "123",
                            updatedLink));
}

@Test
void deleteAffiliateLink_ShouldDeleteAffiliateLink() {

    affiliateLinkService.deleteAffiliateLink("123");

    verify(affiliateLinkRepository)
            .deleteById("123");
}

@Test
void getByShortCode_ShouldReturnAffiliateLink() {

    AffiliateLink affiliateLink = new AffiliateLink();
    affiliateLink.setShortCode("amzhp25");

    when(affiliateLinkRepository
            .findByShortCode("amzhp25"))
                    .thenReturn(affiliateLink);

    AffiliateLink result =
            affiliateLinkService
                    .getByShortCode("amzhp25");

    assertNotNull(result);
    assertEquals(
            "amzhp25",
            result.getShortCode());
}

@Test
void getByShortCode_ShouldThrowNotFoundException() {

    when(affiliateLinkRepository
            .findByShortCode("invalid"))
                    .thenReturn(null);

    assertThrows(
            NotFoundException.class,
            () -> affiliateLinkService
                    .getByShortCode("invalid"));
}


}


