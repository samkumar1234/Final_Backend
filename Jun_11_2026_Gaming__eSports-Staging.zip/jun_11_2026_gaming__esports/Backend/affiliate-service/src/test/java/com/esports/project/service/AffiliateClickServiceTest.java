package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.entity.AffiliateClick;
import com.esports.project.repository.AffiliateClickRepository;

@ExtendWith(MockitoExtension.class)
class AffiliateClickServiceTest {

    @Mock
    private AffiliateClickRepository affiliateClickRepository;

    @InjectMocks
    private AffiliateClickService affiliateClickService;

    @Test
    void createAffiliateClick_ShouldSaveAffiliateClick() {

        // Arrange
        AffiliateClick affiliateClick = new AffiliateClick();
        affiliateClick.setSessionId("SESSION123");
        affiliateClick.setVisitorIp("192.168.1.1");
        affiliateClick.setClickedAt(LocalDateTime.now());

        when(affiliateClickRepository.save(affiliateClick))
                .thenReturn(affiliateClick);

        // Act
        AffiliateClick result =
                affiliateClickService.createAffiliateClick(
                        affiliateClick);

        // Assert
        assertNotNull(result);
        assertEquals(
                "SESSION123",
                result.getSessionId());
        assertEquals(
                "192.168.1.1",
                result.getVisitorIp());
    }

    @Test
void getAllAffiliateClicks_ShouldReturnAllClicks() {

    // Arrange
    AffiliateClick click1 = new AffiliateClick();
    click1.setId("1");

    AffiliateClick click2 = new AffiliateClick();
    click2.setId("2");

    when(affiliateClickRepository.findAll())
            .thenReturn(List.of(click1, click2));

    // Act
    List<AffiliateClick> result =
            affiliateClickService.getAllAffiliateClicks();

    // Assert
    assertNotNull(result);
    assertEquals(2, result.size());
}

@Test
void getAffiliateClickById_ShouldReturnClick() {

    // Arrange
    AffiliateClick affiliateClick = new AffiliateClick();
    affiliateClick.setId("123");
    affiliateClick.setSessionId("SESSION123");

    when(affiliateClickRepository.findById("123"))
            .thenReturn(Optional.of(affiliateClick));

    // Act
    AffiliateClick result =
            affiliateClickService.getAffiliateClickById("123");

    // Assert
    assertNotNull(result);
    assertEquals("123", result.getId());
    assertEquals(
            "SESSION123",
            result.getSessionId());
}

@Test
void deleteAffiliateClick_ShouldDeleteClick() {

    // Act
    affiliateClickService.deleteAffiliateClick("123");

    // Assert
    verify(affiliateClickRepository)
            .deleteById("123");
}

@Test
void getClickCount_ShouldReturnCount() {

    // Arrange
    when(
        affiliateClickRepository
            .countByAffiliateLink_Id("LINK123"))
            .thenReturn(5L);

    // Act
    long count =
            affiliateClickService
                    .getClickCount("LINK123");

    // Assert
    assertEquals(5L, count);
}

@Test
void getClicksByAffiliateLinkId_ShouldReturnClicks() {

    // Arrange
    AffiliateClick click1 = new AffiliateClick();
    click1.setId("1");

    AffiliateClick click2 = new AffiliateClick();
    click2.setId("2");

    when(
        affiliateClickRepository
            .findByAffiliateLink_Id("LINK123"))
            .thenReturn(List.of(click1, click2));

    // Act
    List<AffiliateClick> result =
            affiliateClickService
                    .getClicksByAffiliateLinkId(
                            "LINK123");

    // Assert
    assertNotNull(result);
    assertEquals(2, result.size());
}

@Test
void getUniqueClickCount_ShouldReturnUniqueCount() {

    // Arrange
    when(
        affiliateClickRepository
            .countByAffiliateLink_IdAndUniqueClickTrue(
                    "LINK123"))
            .thenReturn(3L);

    // Act
    long count =
            affiliateClickService
                    .getUniqueClickCount(
                            "LINK123");

    // Assert
    assertEquals(3L, count);
}
}