package com.esports.project.DTO;


import com.esports.project.enums.StatusMaster;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AffiliateLinkDTO {

    private String linkName;

    private String destinationUrl;

    private String shortCode;

    private String collaborationId;

    private String userId;

    private StatusMaster status;

}
