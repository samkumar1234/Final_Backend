package com.esports.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.esports.project.entity.AffiliateClick;
import com.esports.project.service.AffiliateClickService;

@RestController
@RequestMapping("/affiliate/clicks")
public class AffiliateClickController {

    @Autowired
    private AffiliateClickService affiliateClickService;

    //@PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public AffiliateClick createAffiliateClick(
            @RequestBody AffiliateClick affiliateClick) {

        return affiliateClickService.createAffiliateClick(
                affiliateClick);
    }

    //@PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public List<AffiliateClick> getAllAffiliateClicks() {

        return affiliateClickService.getAllAffiliateClicks();
    }

    //@PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public AffiliateClick getAffiliateClickById(
            @PathVariable String id) {

        return affiliateClickService.getAffiliateClickById(id);
    }

    //@PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public void deleteAffiliateClick(
            @PathVariable String id) {

        affiliateClickService.deleteAffiliateClick(id);
    }

    //@PreAuthorize("hasAnyRole('ADMIN','BRAND','INFLUENCER')")
    @GetMapping("/count/{affiliateLinkId}")
    public long getClickCount(
            @PathVariable String affiliateLinkId) {

        return affiliateClickService
                .getClickCount(affiliateLinkId);
    }

    //@PreAuthorize("hasAnyRole('ADMIN','BRAND','INFLUENCER')")
    @GetMapping("/link/{affiliateLinkId}")
    public List<AffiliateClick> getClicksByAffiliateLinkId(
            @PathVariable String affiliateLinkId) {

        return affiliateClickService
                .getClicksByAffiliateLinkId(
                        affiliateLinkId);
    }

    //@PreAuthorize("hasAnyRole('ADMIN','BRAND','INFLUENCER')")
    @GetMapping("/unique-count/{affiliateLinkId}")
    public Map<String, Object> getUniqueClickCount(
            @PathVariable String affiliateLinkId) {

        long count = affiliateClickService
                .getUniqueClickCount(
                        affiliateLinkId);

        Map<String, Object> response = new HashMap<>();

        response.put(
                "affiliateLinkId",
                affiliateLinkId);

        response.put(
                "uniqueClicks",
                count);

        return response;
    }
}