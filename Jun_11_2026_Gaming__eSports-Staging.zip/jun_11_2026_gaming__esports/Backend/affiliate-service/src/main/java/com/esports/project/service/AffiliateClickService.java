package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.esports.project.entity.AffiliateClick;
import com.esports.project.repository.AffiliateClickRepository;

@Service
public class AffiliateClickService {

    @Autowired
    private AffiliateClickRepository affiliateClickRepository;

    public AffiliateClick createAffiliateClick(
            AffiliateClick affiliateClick) {

        affiliateClick.setClickedAt(LocalDateTime.now());

        return affiliateClickRepository.save(affiliateClick);
    }

    public List<AffiliateClick> getAllAffiliateClicks() {

        return affiliateClickRepository.findAll();
    }

    public AffiliateClick getAffiliateClickById(String id) {

        return affiliateClickRepository.findById(id).orElse(null);
    }

    public void deleteAffiliateClick(String id) {

        affiliateClickRepository.deleteById(id);
    }

   public long getClickCount(String affiliateLinkId) {

    return affiliateClickRepository
            .countByAffiliateLink_Id(affiliateLinkId);
}

public List<AffiliateClick> getClicksByAffiliateLinkId(
        String affiliateLinkId) {

    return affiliateClickRepository
            .findByAffiliateLink_Id(affiliateLinkId);
}

public long getUniqueClickCount(
        String affiliateLinkId) {

    return affiliateClickRepository
            .countByAffiliateLink_IdAndUniqueClickTrue(
                    affiliateLinkId);
}
}

