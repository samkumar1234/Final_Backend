package com.esports.project.exception;

public class AffiliateClickNotFoundException extends RuntimeException {

    public AffiliateClickNotFoundException(String message) {
        super(message);
    }
}