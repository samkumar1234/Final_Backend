package com.esports.project.exception;

public class AffiliateLinkNotFoundException extends RuntimeException {

    public AffiliateLinkNotFoundException(String message) {
        super(message);
    }
}