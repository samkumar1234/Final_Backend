package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.EnumType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "affiliate_links")
public class AffiliateLink {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String linkName;

    private String destinationUrl;

    private String shortCode;

    private String collaborationId;

    private String userId;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "affiliateLink")
    @JsonManagedReference(value = "affiliate-click")
    private List<AffiliateClick> affiliateClicks;
}