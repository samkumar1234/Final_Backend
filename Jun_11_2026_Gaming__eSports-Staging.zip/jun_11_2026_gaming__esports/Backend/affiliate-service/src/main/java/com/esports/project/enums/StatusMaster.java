package com.esports.project.enums;

public enum StatusMaster {
    
    ACTIVE,
    INACTIVE,
    EXPIRED,
    SUSPENDED

}