package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import javax.ws.rs.NotFoundException;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.AffiliateLinkDTO;
import com.esports.project.DTO.AffiliateLinkResponseDTO;
import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.entity.AffiliateLink;
import com.esports.project.repository.AffiliateLinkRepository;

@Service
public class AffiliateLinkService {

    private final AffiliateLinkRepository affiliateLinkRepository;
    private final EventPublisher publisher;

    public AffiliateLinkService(AffiliateLinkRepository affiliateLinkRepository,
                                        EventPublisher publisher){
                this.affiliateLinkRepository = affiliateLinkRepository;
                this.publisher = publisher;
                                        }



     

        public AffiliateLink createAffiliateLink(
        AffiliateLinkDTO dto) {

    AffiliateLink affiliateLink =
            new AffiliateLink();

    affiliateLink.setLinkName(
            dto.getLinkName());

    affiliateLink.setDestinationUrl(
            dto.getDestinationUrl());

    affiliateLink.setShortCode(
            dto.getShortCode());

    affiliateLink.setCollaborationId(
            dto.getCollaborationId());

    affiliateLink.setUserId(
            dto.getUserId());

    affiliateLink.setStatus(
            dto.getStatus());

    affiliateLink.setCreatedAt(
            LocalDateTime.now());

    affiliateLink.setUpdatedAt(
            LocalDateTime.now());

                AffiliateLink saved =
        affiliateLinkRepository.save(
                affiliateLink);

sendNotification(
        saved.getUserId(),
        "Affiliate Link Created",
        "Your affiliate link "
                + saved.getLinkName()
                + " has been created.");

return saved;

//     return affiliateLinkRepository
//             .save(affiliateLink);
}

    public List<AffiliateLink> getAllAffiliateLinks() {

        return affiliateLinkRepository.findAll();
    }

    public AffiliateLink getAffiliateLinkById(String id) {

        return affiliateLinkRepository.findById(id).orElse(null);
    }

    public AffiliateLink updateAffiliateLink(String id,
            AffiliateLink affiliateLink) {

        AffiliateLink existingLink =
                affiliateLinkRepository.findById(id).orElse(null);

        if (existingLink != null) {

            existingLink.setLinkName(
                    affiliateLink.getLinkName());

            existingLink.setDestinationUrl(
                    affiliateLink.getDestinationUrl());

            existingLink.setShortCode(
                    affiliateLink.getShortCode());

            existingLink.setStatus(
                    affiliateLink.getStatus());

            existingLink.setUpdatedAt(
                    LocalDateTime.now());

            AffiliateLink updated = affiliateLinkRepository.save(existingLink);
            sendNotification(
        updated.getUserId(),
        "Affiliate Link Updated",
        "Your affiliate link "
                + updated.getLinkName()
                + " has been updated.");

return updated;
        }

        return null;
    }

    public void deleteAffiliateLink(String id) {

        AffiliateLink affiliateLink =
        affiliateLinkRepository.findById(id)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Affiliate Link not found"));

        affiliateLinkRepository.deleteById(id);

        sendNotification(
        affiliateLink.getUserId(),
        "Affiliate Link Deleted",
        "Your affiliate link "
                + affiliateLink.getLinkName()
                + " has been deleted.");

affiliateLinkRepository.delete(
        affiliateLink);
    }

    public AffiliateLink getByShortCode(String shortCode) {

    AffiliateLink affiliateLink =
            affiliateLinkRepository.findByShortCode(shortCode);

    if (affiliateLink == null) {
        throw new NotFoundException(
                "Affiliate Link not found with shortCode : "
                        + shortCode);
    }

    return affiliateLink;

}

    public AffiliateLinkResponseDTO getAffiliateLinkByCollaborationID(String collaborationID) {

    AffiliateLink affiliateLink =
            affiliateLinkRepository.findByCollaborationId(collaborationID);

    if (affiliateLink == null) {
        throw new RuntimeException(
                "Affiliate Link not found for Collaboration ID: " + collaborationID);
    }

    return new AffiliateLinkResponseDTO(
            affiliateLink.getLinkName(),
            affiliateLink.getDestinationUrl());
}

 private void sendNotification(
        String userId,
        String title,
        String message) {

    try {

        NotificationEventDTO notification =
                new NotificationEventDTO(
                        userId,
                        title,
                        message);

        publisher.publishNotification(
                notification);

    } catch (Exception e) {

        System.out.println(
                "Campaign Notification Error : "
                        + e.getMessage());
    }
}
}