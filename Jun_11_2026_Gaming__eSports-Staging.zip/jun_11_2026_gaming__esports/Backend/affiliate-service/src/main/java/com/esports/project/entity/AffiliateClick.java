package com.esports.project.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(
    name = "affiliate_clicks",
    indexes = {
        @Index(name = "idx_affiliate_link_id", columnList = "affiliate_link_id"),
        @Index(name = "idx_clicked_at", columnList = "clickedAt")
    }
)
public class AffiliateClick {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String sessionId;

    private String visitorIp;

    private String deviceType;

    private String browser;

    private String operatingSystem;

    private String refererUrl;

    private String country;

    private String city;

    private String userAgent;

    private Boolean uniqueClick;

    private Boolean fraudulentClick;

    @CreationTimestamp
    private LocalDateTime clickedAt;

    /*
     * Relationship Mapping
     */
    @ManyToOne
    @JoinColumn(name = "affiliate_link_id")
    @JsonBackReference(value = "affiliate-click")
    private AffiliateLink affiliateLink;

    
}