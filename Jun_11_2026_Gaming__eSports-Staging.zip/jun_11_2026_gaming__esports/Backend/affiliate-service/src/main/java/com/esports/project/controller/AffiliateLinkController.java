package com.esports.project.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.entity.AffiliateLink;
import com.esports.project.service.AffiliateLinkService;

import jakarta.servlet.http.HttpServletRequest;

import com.esports.project.DTO.AffiliateLinkDTO;
import com.esports.project.DTO.AffiliateLinkResponseDTO;
import com.esports.project.entity.AffiliateClick;
import com.esports.project.service.AffiliateClickService;



@RestController
@RequestMapping("/affiliate/links")
public class AffiliateLinkController {

    @Autowired
    private AffiliateClickService affiliateClickService;

    @Autowired
    private AffiliateLinkService affiliateLinkService;

    //@PreAuthorize("hasAnyRole('ADMIN','BRAND')")
     @PostMapping
        public AffiliateLink createAffiliateLink( @RequestBody AffiliateLinkDTO dto) {

                       return affiliateLinkService.createAffiliateLink(dto);

   
}

    //@PreAuthorize("hasAnyRole('ADMIN','BRAND','INFLUENCER')")
    @GetMapping
    public List<AffiliateLink> getAllAffiliateLinks() {

        return affiliateLinkService.getAllAffiliateLinks();
    }

    //@PreAuthorize("hasAnyRole('ADMIN','BRAND','INFLUENCER')")
    @GetMapping("/{id}")
    public AffiliateLink getAffiliateLinkById(
            @PathVariable String id) {

        return affiliateLinkService.getAffiliateLinkById(id);
    }

    //@PreAuthorize("hasAnyRole('ADMIN','BRAND')")
    @PutMapping("/{id}")
    public AffiliateLink updateAffiliateLink(
            @PathVariable String id,
            @RequestBody AffiliateLink affiliateLink) {

        return affiliateLinkService.updateAffiliateLink(
                id,
                affiliateLink);
    }

    //@PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public void deleteAffiliateLink(
            @PathVariable String id) {

        affiliateLinkService.deleteAffiliateLink(id);
    }

    // PUBLIC ENDPOINT
    @GetMapping("/a/{shortCode}")
    public ResponseEntity<Void> redirectToDestination(
            @PathVariable String shortCode,
            HttpServletRequest request) {

        AffiliateLink affiliateLink =
                affiliateLinkService.getByShortCode(shortCode);

        AffiliateClick click = new AffiliateClick();

        click.setSessionId(
                request.getSession().getId());

        click.setVisitorIp(
                request.getRemoteAddr());

        click.setBrowser(
                request.getHeader("User-Agent"));

        click.setAffiliateLink(
                affiliateLink);

        click.setUniqueClick(true);

        click.setFraudulentClick(false);

        affiliateClickService.createAffiliateClick(click);

        return ResponseEntity.status(HttpStatus.FOUND)
                .location(
                        URI.create(
                                affiliateLink.getDestinationUrl()))
                .build();
    }


    //@PreAuthorize("hasAnyRole('ADMIN','BRAND','INFLUENCER')")
//   @GetMapping("/{collaborationID}")
// public AffiliateLinkResponseDTO getAffiliateLinkByCollaborationID(
//         @PathVariable String collaborationID) {

//     return affiliateLinkService.getAffiliateLinkByCollaborationID(collaborationID);
// }

@GetMapping("/collaboration/{collaborationID}")
public AffiliateLinkResponseDTO
getAffiliateLinkByCollaborationID(
        @PathVariable String collaborationID) {

    return affiliateLinkService
            .getAffiliateLinkByCollaborationID(
                    collaborationID);
}


    
}