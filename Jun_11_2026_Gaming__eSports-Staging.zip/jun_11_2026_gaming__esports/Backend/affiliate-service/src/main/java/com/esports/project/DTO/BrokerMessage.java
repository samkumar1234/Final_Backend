package com.esports.project.DTO;


import lombok.Data;

@Data
public class BrokerMessage {
    private String userId;
    private String type;
    private String topic;
    private Object payload;
    private Long offset;
}