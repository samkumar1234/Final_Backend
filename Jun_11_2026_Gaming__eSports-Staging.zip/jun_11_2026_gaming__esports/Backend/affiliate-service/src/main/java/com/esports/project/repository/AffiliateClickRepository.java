package com.esports.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.AffiliateClick;

@Repository
public interface AffiliateClickRepository
        extends JpaRepository<AffiliateClick, String> {

    long countByAffiliateLink_Id(String affiliateLinkId);

    List<AffiliateClick> findByAffiliateLink_Id(String affiliateLinkId);

    long countByAffiliateLink_IdAndUniqueClickTrue(
        String affiliateLinkId);
    

}