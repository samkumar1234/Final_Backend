package com.esports.project.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class AffiliateLinkResponseDTO {

    private String linkName;
    private String destinationUrl;
}