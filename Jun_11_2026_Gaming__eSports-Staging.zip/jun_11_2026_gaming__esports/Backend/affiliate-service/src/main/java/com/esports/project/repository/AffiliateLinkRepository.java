package com.esports.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.AffiliateLink;

@Repository
public interface AffiliateLinkRepository extends JpaRepository<AffiliateLink, String> {

    AffiliateLink findByShortCode(String shortCode);

    AffiliateLink findByCollaborationId(String collaborationID);
}