package com.esports.project.service;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.exception.NotFoundException;

@Service
public class TestService {
    
    public void throwNotFound(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserDetailsDTO user = (UserDetailsDTO) authentication.getPrincipal();
        System.out.println(user);
        throw new NotFoundException("Test Not found");
    }
}
