package com.hlms.loan;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.entity.AuditLog;
import com.hlms.loan.repository.AuditLogRepository;
import com.hlms.loan.service.AuditService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuditServiceTest {

    @Mock
    private AuditLogRepository repository;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private AuditService auditService;

    private Map<String, Object> beforeData;
    private Map<String, Object> afterData;

    @BeforeEach
    void setUp() {

        beforeData = new HashMap<>();
        beforeData.put("status", "PENDING");

        afterData = new HashMap<>();
        afterData.put("status", "APPROVED");
    }

    // =====================================================
    // POSITIVE TEST CASES
    // =====================================================

    @Test
    void record_ShouldSaveAuditLogSuccessfully()
            throws Exception {

        when(objectMapper.writeValueAsString(beforeData))
                .thenReturn("{\"status\":\"PENDING\"}");

        when(objectMapper.writeValueAsString(afterData))
                .thenReturn("{\"status\":\"APPROVED\"}");

        auditService.record(
                "loan_application",
                "APP001",
                "APPROVED",
                "test@bank.com",
                beforeData,
                afterData);

        verify(repository).save(any(AuditLog.class));
    }

    @Test
    void history_ShouldReturnAuditLogs() {

        AuditLog log1 =
                AuditLog.builder()
                        .action("CREATE")
                        .build();

        AuditLog log2 =
                AuditLog.builder()
                        .action("UPDATE")
                        .build();

        when(repository
                .findByEntityTypeAndEntityIdOrderByCreatedAtDesc(
                        "loan_application",
                        "APP001"))
                .thenReturn(List.of(log1, log2));

        List<AuditLog> result =
                auditService.history(
                        "loan_application",
                        "APP001");

        assertEquals(2, result.size());
    }

    @Test
    void historyChronological_ShouldReturnReverseOrder() {

        AuditLog latest =
                AuditLog.builder()
                        .action("UPDATE")
                        .build();

        AuditLog oldest =
                AuditLog.builder()
                        .action("CREATE")
                        .build();

        when(repository
                .findByEntityTypeAndEntityIdOrderByCreatedAtDesc(
                        "loan_application",
                        "APP001"))
                .thenReturn(List.of(latest, oldest));

        List<AuditLog> result =
                auditService.historyChronological(
                        "loan_application",
                        "APP001");

        assertEquals("CREATE",
                result.get(0).getAction());

        assertEquals("UPDATE",
                result.get(1).getAction());
    }

    // =====================================================
    // NEGATIVE TEST CASES
    // =====================================================

    @Test
    void record_WhenSerializationFails_ShouldStillSaveAuditLog()
            throws Exception {

        when(objectMapper.writeValueAsString(any()))
                .thenThrow(
                        new RuntimeException(
                                "Serialization Error"));

        auditService.record(
                "loan_application",
                "APP001",
                "UPDATE",
                "user@test.com",
                beforeData,
                afterData);

        verify(repository).save(any(AuditLog.class));
    }

    @Test
    void record_WhenBeforeDataSerializationFails_ShouldSave()
            throws Exception {

        when(objectMapper.writeValueAsString(beforeData))
                .thenThrow(
                        new RuntimeException("Error"));

        auditService.record(
                "loan_application",
                "APP001",
                "UPDATE",
                "user@test.com",
                beforeData,
                afterData);

        verify(repository).save(any(AuditLog.class));
    }

    @Test
    void record_WhenAfterDataSerializationFails_ShouldSave()
            throws Exception {

        when(objectMapper.writeValueAsString(beforeData))
                .thenReturn("{\"status\":\"PENDING\"}");

        when(objectMapper.writeValueAsString(afterData))
                .thenThrow(
                        new RuntimeException("Error"));

        auditService.record(
                "loan_application",
                "APP001",
                "UPDATE",
                "user@test.com",
                beforeData,
                afterData);

        verify(repository).save(any(AuditLog.class));
    }

    @Test
    void history_WhenNoRecordsExist_ShouldReturnEmptyList() {

        when(repository
                .findByEntityTypeAndEntityIdOrderByCreatedAtDesc(
                        "loan_application",
                        "APP001"))
                .thenReturn(List.of());

        List<AuditLog> result =
                auditService.history(
                        "loan_application",
                        "APP001");

        assertTrue(result.isEmpty());
    }

    // =====================================================
    // EDGE TEST CASES
    // =====================================================

    @Test
    void record_WithNullBeforeAndAfterData_ShouldSaveSuccessfully() {

        auditService.record(
                "loan_application",
                "APP001",
                "CREATE",
                "user@test.com",
                null,
                null);

        verify(repository).save(any(AuditLog.class));
    }

    @Test
    void record_WithNullActorEmail_ShouldSaveSuccessfully() {

        auditService.record(
                "loan_application",
                "APP001",
                "CREATE",
                null,
                null,
                null);

        verify(repository).save(any(AuditLog.class));
    }

    @Test
    void record_ShouldStoreCorrectValues()
            throws Exception {

        when(objectMapper.writeValueAsString(beforeData))
                .thenReturn("{\"status\":\"PENDING\"}");

        when(objectMapper.writeValueAsString(afterData))
                .thenReturn("{\"status\":\"APPROVED\"}");

        auditService.record(
                "loan_application",
                "APP001",
                "UPDATE",
                "user@test.com",
                beforeData,
                afterData);

        ArgumentCaptor<AuditLog> captor =
                ArgumentCaptor.forClass(AuditLog.class);

        verify(repository).save(captor.capture());

        AuditLog savedLog =
                captor.getValue();

        assertEquals(
                "loan_application",
                savedLog.getEntityType());

        assertEquals(
                "APP001",
                savedLog.getEntityId());

        assertEquals(
                "UPDATE",
                savedLog.getAction());

        assertEquals(
                "user@test.com",
                savedLog.getActorEmail());
    }

    @Test
    void record_ShouldPersistSerializedJson()
            throws Exception {

        when(objectMapper.writeValueAsString(beforeData))
                .thenReturn("{\"status\":\"PENDING\"}");

        when(objectMapper.writeValueAsString(afterData))
                .thenReturn("{\"status\":\"APPROVED\"}");

        auditService.record(
                "loan_application",
                "APP001",
                "UPDATE",
                "user@test.com",
                beforeData,
                afterData);

        ArgumentCaptor<AuditLog> captor =
                ArgumentCaptor.forClass(AuditLog.class);

        verify(repository).save(captor.capture());

        AuditLog log =
                captor.getValue();

        assertEquals(
                "{\"status\":\"PENDING\"}",
                log.getBeforeData());

        assertEquals(
                "{\"status\":\"APPROVED\"}",
                log.getAfterData());
    }

    @Test
    void historyChronological_WhenSingleRecord_ReturnSameRecord() {

        AuditLog log =
                AuditLog.builder()
                        .action("CREATE")
                        .build();

        when(repository
                .findByEntityTypeAndEntityIdOrderByCreatedAtDesc(
                        "loan_application",
                        "APP001"))
                .thenReturn(List.of(log));

        List<AuditLog> result =
                auditService.historyChronological(
                        "loan_application",
                        "APP001");

        assertEquals(1, result.size());

        assertEquals(
                "CREATE",
                result.get(0).getAction());
    }

    @Test
    void historyChronological_WhenEmptyList_ShouldReturnEmptyList() {

        when(repository
                .findByEntityTypeAndEntityIdOrderByCreatedAtDesc(
                        "loan_application",
                        "APP001"))
                .thenReturn(List.of());

        List<AuditLog> result =
                auditService.historyChronological(
                        "loan_application",
                        "APP001");

        assertTrue(result.isEmpty());
    }

    @Test
    void historyChronological_ShouldReverseThreeRecords() {

        AuditLog first =
                AuditLog.builder()
                        .action("UPDATE")
                        .build();

        AuditLog second =
                AuditLog.builder()
                        .action("REVIEW")
                        .build();

        AuditLog third =
                AuditLog.builder()
                        .action("CREATE")
                        .build();

        when(repository
                .findByEntityTypeAndEntityIdOrderByCreatedAtDesc(
                        "loan_application",
                        "APP001"))
                .thenReturn(
                        Arrays.asList(
                                first,
                                second,
                                third));

        List<AuditLog> result =
                auditService.historyChronological(
                        "loan_application",
                        "APP001");

        assertEquals(
                "CREATE",
                result.get(0).getAction());

        assertEquals(
                "REVIEW",
                result.get(1).getAction());

        assertEquals(
                "UPDATE",
                result.get(2).getAction());
    }
}