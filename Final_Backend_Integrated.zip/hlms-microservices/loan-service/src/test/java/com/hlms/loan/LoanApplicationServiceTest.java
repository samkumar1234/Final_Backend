package com.hlms.loan;

import com.hlms.loan.dto.SubmitApplicationRequest;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.exception.BadRequestException;
import com.hlms.loan.exception.ResourceNotFoundException;
import com.hlms.loan.repository.LoanApplicationRepository;
import com.hlms.loan.service.AuditService;
import com.hlms.loan.service.LoanApplicationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoanApplicationServiceTest {

    @Mock
    private LoanApplicationRepository repository;

    @Mock
    private AuditService auditService;

    @InjectMocks
    private LoanApplicationService service;

    private LoanApplication application;
    private SubmitApplicationRequest request;

    @BeforeEach
    void setUp() {

        application = LoanApplication.builder()
                .appId("APP001")
                .userEmail("user@test.com")
                .status("Draft")
                .stageIndex(0)
                .productId("HOME001")
                .loanAmount(new BigDecimal("1000000"))
                .tenureYears(20)
                .applicantName("John")
                .applicantPan("ABCDE1234F")
                .build();

        request = new SubmitApplicationRequest();
        request.setProductId("HOME001");
        request.setLoanAmount(new BigDecimal("1000000"));
        request.setTenureYears(20);
        request.setApplicantName("John");
        request.setApplicantPan("ABCDE1234F");
    }

    // ====================================================
    // GET
    // ====================================================

    @Test
    void get_ShouldReturnApplication() {

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        LoanApplication result = service.get("APP001");

        assertNotNull(result);
        assertEquals("APP001", result.getAppId());
    }

    @Test
    void get_ShouldThrowException_WhenNotFound() {

        when(repository.findById("APP001"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.get("APP001"));
    }

    @Test
    void get_ShouldThrowException_WhenSoftDeleted() {

        application.setDeletedAt(OffsetDateTime.now());

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.get("APP001"));
    }

    // ====================================================
    // LIST
    // ====================================================

    @Test
    void listForUser_ShouldReturnApplications() {

        when(repository.findByUserEmailAndDeletedAtIsNull(
                "user@test.com"))
                .thenReturn(List.of(application));

        assertEquals(
                1,
                service.listForUser("user@test.com").size());
    }

    @Test
    void listForUser_ShouldReturnEmptyList() {

        when(repository.findByUserEmailAndDeletedAtIsNull(
                "user@test.com"))
                .thenReturn(List.of());

        assertTrue(
                service.listForUser("user@test.com")
                        .isEmpty());
    }

    @Test
    void listAll_ShouldReturnApplications() {

        when(repository.findByDeletedAtIsNull())
                .thenReturn(List.of(application));

        assertEquals(
                1,
                service.listAll().size());
    }

    @Test
    void listAll_ShouldReturnEmptyList() {

        when(repository.findByDeletedAtIsNull())
                .thenReturn(List.of());

        assertTrue(service.listAll().isEmpty());
    }

    // ====================================================
    // PAGINATION
    // ====================================================

    @Test
    void listAll_WithPagination() {

        Page<LoanApplication> page =
                new PageImpl<>(List.of(application));

        when(repository.findByDeletedAtIsNull(any()))
                .thenReturn(page);

        Page<LoanApplication> result =
                service.listAll(PageRequest.of(0, 10));

        assertEquals(
                1,
                result.getContent().size());
    }

    @Test
    void listForUser_WithPagination() {

        Page<LoanApplication> page =
                new PageImpl<>(List.of(application));

        when(repository.findByUserEmailAndDeletedAtIsNull(
                eq("user@test.com"),
                any()))
                .thenReturn(page);

        Page<LoanApplication> result =
                service.listForUser(
                        "user@test.com",
                        PageRequest.of(0, 10));

        assertEquals(
                1,
                result.getContent().size());
    }

    // ====================================================
    // TRACKING NO
    // ====================================================

    @Test
    void getByTrackingNo_ShouldReturnApplication() {

        application.setTrackingNo("TRK123");

        when(repository.findByTrackingNoAndDeletedAtIsNull(
                "TRK123"))
                .thenReturn(Optional.of(application));

        LoanApplication result =
                service.getByTrackingNo("TRK123");

        assertEquals(
                "TRK123",
                result.getTrackingNo());
    }

    @Test
    void getByTrackingNo_ShouldThrowException() {

        when(repository.findByTrackingNoAndDeletedAtIsNull(
                "TRK999"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getByTrackingNo("TRK999"));
    }

    // ====================================================
    // SAVE DRAFT
    // ====================================================

    @Test
    void saveDraft_ShouldCreateNewDraft() {

        when(repository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        LoanApplication result =
                service.saveDraft(
                        null,
                        "user@test.com",
                        request,
                        1);

        assertNotNull(result);

        verify(repository).save(any());

        verify(auditService).record(
                eq("loan_application"),
                anyString(),
                eq("CREATE"),
                eq("user@test.com"),
                isNull(),
                anyMap());
    }

    @Test
    void saveDraft_ShouldUpdateExistingDraft() {

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(repository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        LoanApplication result =
                service.saveDraft(
                        "APP001",
                        "user@test.com",
                        request,
                        2);

        assertNotNull(result);
    }

    @Test
    void saveDraft_ShouldStoreCorrectValues() {

        when(repository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        LoanApplication saved =
                service.saveDraft(
                        null,
                        "user@test.com",
                        request,
                        1);

        assertEquals(
                "HOME001",
                saved.getProductId());

        assertEquals(
                new BigDecimal("1000000"),
                saved.getLoanAmount());

        assertEquals(
                "John",
                saved.getApplicantName());
    }

    // ====================================================
    // SUBMIT
    // ====================================================

    @Test
    void submit_ShouldSubmitApplication() {

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(repository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        LoanApplication result =
                service.submit("APP001");

        assertNotNull(result);

        verify(repository).save(any());
    }

    @Test
    void submit_ShouldGenerateTrackingNumber() {

        application.setTrackingNo(null);

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(repository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        service.submit("APP001");

        ArgumentCaptor<LoanApplication> captor =
                ArgumentCaptor.forClass(
                        LoanApplication.class);

        verify(repository).save(captor.capture());

        assertNotNull(
                captor.getValue().getTrackingNo());
    }

    @Test
    void submit_ShouldThrowException_WhenProductMissing() {

        application.setProductId(null);

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                BadRequestException.class,
                () -> service.submit("APP001"));
    }

    @Test
    void submit_ShouldThrowException_WhenLoanAmountMissing() {

        application.setLoanAmount(BigDecimal.ZERO);

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                BadRequestException.class,
                () -> service.submit("APP001"));
    }

    @Test
    void submit_ShouldThrowException_WhenTenureMissing() {

        application.setTenureYears(null);

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                BadRequestException.class,
                () -> service.submit("APP001"));
    }

    @Test
    void submit_ShouldThrowException_WhenApplicantMissing() {

        application.setApplicantName(null);

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                BadRequestException.class,
                () -> service.submit("APP001"));
    }

    @Test
    void submit_ShouldThrowException_WhenPanMissing() {

        application.setApplicantPan(null);

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                BadRequestException.class,
                () -> service.submit("APP001"));
    }

    // ====================================================
    // UPDATE STAGE
    // ====================================================

    @Test
    void updateStage_ShouldUpdateStage() {

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(repository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        LoanApplication updated =
                service.updateStage(
                        "APP001",
                        5,
                        "Disbursement",
                        "manager@test.com");

        assertEquals(5,
                updated.getStageIndex());
    }

    @Test
    void updateStage_ShouldThrowException_WhenNotFound() {

        when(repository.findById("APP001"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.updateStage(
                        "APP001",
                        2,
                        "Verification"));
    }

    // ====================================================
    // WITHDRAW
    // ====================================================

    @Test
    void withdraw_ShouldSoftDeleteApplication() {

        when(repository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(repository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        service.withdraw("APP001");

        assertNotNull(application.getDeletedAt());

        verify(repository).save(any());
    }

    @Test
    void withdraw_ShouldThrowException_WhenNotFound() {

        when(repository.findById("APP001"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.withdraw("APP001"));
    }

    // ====================================================
    // WORKFLOW
    // ====================================================

    @Test
    void workflowStages_ShouldReturnStages() {

        List<String> stages =
                service.workflowStages();

        assertFalse(stages.isEmpty());
        assertTrue(stages.contains("Draft"));
    }
}