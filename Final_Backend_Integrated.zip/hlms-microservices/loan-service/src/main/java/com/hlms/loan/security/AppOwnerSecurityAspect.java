package com.hlms.loan.security;

import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.repository.LoanApplicationRepository;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.lang.reflect.Method;
import java.util.Arrays;

@Aspect
@Component
public class AppOwnerSecurityAspect {

    private final LoanApplicationRepository loanApplicationRepository;

    public AppOwnerSecurityAspect(LoanApplicationRepository loanApplicationRepository) {
        this.loanApplicationRepository = loanApplicationRepository;
    }

    @Before("@annotation(com.hlms.loan.security.RequireAppOwner)")
    public void checkAppOwner(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();

        RequireAppOwner annotation = method.getAnnotation(RequireAppOwner.class);
        String appIdParamName = annotation.appIdParam();

        String appId = extractAppId(joinPoint, signature, appIdParamName);

        if (appId == null || appId.trim().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Application ID is required.");
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Authentication required.");
        }

        String currentUserEmail = authentication.getName();

        boolean privilegedUser = authentication.getAuthorities()
                .stream()
                .anyMatch(authority ->
                        authority.getAuthority().equals("ADMIN") ||
                        authority.getAuthority().equals("ROLE_ADMIN") ||
                        authority.getAuthority().equals("BANK_OFFICER") ||
                        authority.getAuthority().equals("ROLE_BANK_OFFICER") ||
                        authority.getAuthority().equals("LEGAL") ||
                        authority.getAuthority().equals("ROLE_LEGAL")
                );

        if (privilegedUser) {
            return;
        }

        LoanApplication app = loanApplicationRepository.findById(appId)
                .filter(a -> a.getDeletedAt() == null)
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.NOT_FOUND, "Loan application not found.")
                );

        if (app.getUserEmail() == null ||
                !app.getUserEmail().equalsIgnoreCase(currentUserEmail)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Access denied.");
        }
    }

    private String extractAppId(
            JoinPoint joinPoint,
            MethodSignature signature,
            String appIdParamName) {

        String[] parameterNames = signature.getParameterNames();
        Object[] args = joinPoint.getArgs();

        if (parameterNames != null && args != null) {
            for (int i = 0; i < parameterNames.length; i++) {
                if (appIdParamName.equals(parameterNames[i])) {
                    Object value = args[i];
                    return value == null ? null : String.valueOf(value);
                }
            }
        }

        if (args == null) {
            return null;
        }

        return Arrays.stream(args)
                .filter(arg -> arg instanceof String)
                .map(String.class::cast)
                .filter(value -> value.startsWith("APP-"))
                .findFirst()
                .orElse(null);
    }
}