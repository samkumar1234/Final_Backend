package com.hlms.loan.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Map;

/**
 * Declarative REST client for user-service (spring.application.name =
 * "user-service"). Eureka resolves the name to a live host:port, so
 * loan-service never hard-codes user-service's address.
 *
 * Use this for live/authoritative user lookups (e.g. confirming a user is
 * still active right before submitting an application); the local AppUser
 * JPA entity mirror stays available for cheap same-database joins/reads.
 */
@FeignClient(name = "user-service", configuration = FeignAuthConfig.class)
public interface UserServiceClient {

    @GetMapping("/api/users/{email}")
    Map<String, Object> getUserByEmail(@PathVariable("email") String email);
}
