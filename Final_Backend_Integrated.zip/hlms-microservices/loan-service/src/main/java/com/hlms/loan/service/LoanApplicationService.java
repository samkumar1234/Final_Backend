package com.hlms.loan.service;

import com.hlms.loan.dto.SubmitApplicationRequest;
import com.hlms.loan.entity.Disbursement;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.exception.BadRequestException;
import com.hlms.loan.exception.ResourceNotFoundException;
import com.hlms.loan.repository.DisbursementRepository;
import com.hlms.loan.repository.LoanApplicationRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class LoanApplicationService {

    private final LoanApplicationRepository repository;
    private final DisbursementRepository disbursementRepository;
    private final AuditService auditService;

    public LoanApplicationService(
            LoanApplicationRepository repository,
            DisbursementRepository disbursementRepository,
            AuditService auditService) {

        this.repository = repository;
        this.disbursementRepository = disbursementRepository;
        this.auditService = auditService;
    }

    private static final List<String> WORKFLOW_STAGES = List.of(
            "Draft",
            "Submitted",
            "Document Verification",
            "Legal Verification",
            "Bank Office Decision",
            "Disbursement",
            "Active"
    );

    public List<LoanApplication> listForUser(String userEmail) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail);
    }

    public List<LoanApplication> listAll() {
        return repository.findByDeletedAtIsNull();
    }

    public org.springframework.data.domain.Page<LoanApplication> listAll(
            org.springframework.data.domain.Pageable pageable) {

        return repository.findByDeletedAtIsNull(pageable);
    }

    public org.springframework.data.domain.Page<LoanApplication> listForUser(
            String userEmail,
            org.springframework.data.domain.Pageable pageable) {

        return repository.findByUserEmailAndDeletedAtIsNull(userEmail, pageable);
    }

    public LoanApplication get(String appId) {
        return repository.findById(appId)
                .filter(app -> app.getDeletedAt() == null)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Loan application not found: " + appId));
    }

    public LoanApplication getByTrackingNo(String trackingNo) {
        return repository.findByTrackingNoAndDeletedAtIsNull(trackingNo)
                .orElseThrow(() ->
                        new ResourceNotFoundException("No application found for tracking number: " + trackingNo));
    }

    @Transactional
    public LoanApplication saveDraft(
            String appId,
            String userEmail,
            SubmitApplicationRequest req,
            int currentStep) {

        boolean isNew = appId == null || appId.trim().isEmpty();

        LoanApplication app;

        if (isNew) {
            app = new LoanApplication();
            app.setAppId(generateAppId());
            app.setUserEmail(userEmail);
            app.setStatus("Draft");
            app.setStageIndex(0);
            app.setCurrentStep(currentStep);
            app.setSavedAt(OffsetDateTime.now());
        } else {
            app = get(appId);

            if (app.getUserEmail() == null || app.getUserEmail().trim().isEmpty()) {
                app.setUserEmail(userEmail);
            }
        }

        applyFields(app, req);

        app.setCurrentStep(currentStep);
        app.setSavedAt(OffsetDateTime.now());

        if (app.getFormData() == null || app.getFormData().trim().isEmpty()) {
            app.setFormData("{}");
        }

        if (app.getStatus() == null || app.getStatus().trim().isEmpty()) {
            app.setStatus("Draft");
        }

        if (app.getStageIndex() == null) {
            app.setStageIndex(0);
        }

        if (app.getCurrentStep() == null) {
            app.setCurrentStep(currentStep);
        }

        if (app.getSavedAt() == null) {
            app.setSavedAt(OffsetDateTime.now());
        }

        LoanApplication saved = repository.save(app);

        syncDisbursementBankDetails(saved);

        if (isNew) {
            try {
                auditService.record(
                        "loan_application",
                        saved.getAppId(),
                        "CREATE",
                        userEmail,
                        null,
                        Map.of(
                                "status", safeString(saved.getStatus()),
                                "stageIndex", safeInteger(saved.getStageIndex())
                        )
                );
            } catch (Exception ignored) {
                /*
                 * Draft save should not fail only because audit logging failed.
                 */
            }
        }

        return saved;
    }

    @Transactional
    public LoanApplication submit(String appId) {
        LoanApplication app = get(appId);

        validateForSubmission(app);

        String prevStatus = safeString(app.getStatus());
        Integer prevStage = safeInteger(app.getStageIndex());

        app.setStatus("Submitted");
        app.setStageIndex(1);

        if (app.getTrackingNo() == null || app.getTrackingNo().trim().isEmpty()) {
            app.setTrackingNo(generateTrackingNo());
        }

        LoanApplication saved = repository.save(app);

        syncDisbursementBankDetails(saved);

        try {
            auditService.record(
                    "loan_application",
                    appId,
                    "SUBMIT",
                    app.getUserEmail(),
                    Map.of(
                            "status", prevStatus,
                            "stageIndex", prevStage
                    ),
                    Map.of(
                            "status", safeString(saved.getStatus()),
                            "stageIndex", safeInteger(saved.getStageIndex()),
                            "trackingNo", safeString(saved.getTrackingNo())
                    )
            );
        } catch (Exception ignored) {
            /*
             * Submit should not fail only because audit logging failed.
             */
        }

        return saved;
    }

    @Transactional
    public LoanApplication updateStage(String appId, int stageIndex, String status) {
        return updateStage(appId, stageIndex, status, null);
    }

    @Transactional
    public LoanApplication updateStage(
            String appId,
            int stageIndex,
            String status,
            String actorEmail) {

        LoanApplication app = get(appId);

        String prevStatus = safeString(app.getStatus());
        Integer prevStage = safeInteger(app.getStageIndex());

        app.setStageIndex(stageIndex);

        if (status != null) {
            app.setStatus(status);
        }

        LoanApplication saved = repository.save(app);

        try {
            auditService.record(
                    "loan_application",
                    appId,
                    "STAGE_CHANGE",
                    actorEmail,
                    Map.of(
                            "status", prevStatus,
                            "stageIndex", prevStage
                    ),
                    Map.of(
                            "status", safeString(saved.getStatus()),
                            "stageIndex", safeInteger(saved.getStageIndex())
                    )
            );
        } catch (Exception ignored) {
            /*
             * Stage update should not fail only because audit logging failed.
             */
        }

        return saved;
    }

    @Transactional
    public void withdraw(String appId) {
        LoanApplication app = get(appId);

        app.setDeletedAt(OffsetDateTime.now());

        repository.save(app);

        try {
            auditService.record(
                    "loan_application",
                    appId,
                    "WITHDRAW",
                    app.getUserEmail(),
                    Map.of(
                            "status", safeString(app.getStatus())
                    ),
                    Map.of(
                            "deletedAt", app.getDeletedAt().toString()
                    )
            );
        } catch (Exception ignored) {
            /*
             * Withdraw should not fail only because audit logging failed.
             */
        }
    }

    public List<String> workflowStages() {
        return WORKFLOW_STAGES;
    }

    private void validateForSubmission(LoanApplication app) {
        if (app.getProductId() == null || app.getProductId().trim().isEmpty()) {
            throw new BadRequestException("Select a loan product before submitting.");
        }

        if (app.getLoanAmount() == null || app.getLoanAmount().signum() <= 0) {
            throw new BadRequestException("Loan amount must be greater than zero.");
        }

        if (app.getTenureYears() == null || app.getTenureYears() <= 0) {
            throw new BadRequestException("Tenure years is required.");
        }

        if (app.getApplicantName() == null || app.getApplicantName().trim().isEmpty()) {
            throw new BadRequestException("Applicant name is required.");
        }

        if (app.getApplicantPan() == null || app.getApplicantPan().trim().isEmpty()) {
            throw new BadRequestException("Applicant PAN is required.");
        }

        if (app.getAccountNumber() == null || app.getAccountNumber().trim().isEmpty()) {
            throw new BadRequestException("Bank account number is required.");
        }
    }

    private void applyFields(LoanApplication app, SubmitApplicationRequest req) {
        if (req == null) {
            return;
        }

        if (req.getProductId() != null) {
            app.setProductId(req.getProductId());
        }

        if (req.getLoanAmount() != null) {
            app.setLoanAmount(req.getLoanAmount());
        }

        if (req.getTenureYears() != null) {
            app.setTenureYears(req.getTenureYears());
        }

        if (req.getPurpose() != null) {
            app.setPurpose(req.getPurpose());
        }

        if (req.getApplicantName() != null) {
            app.setApplicantName(req.getApplicantName());
        }

        if (req.getApplicantMobile() != null) {
            app.setApplicantMobile(req.getApplicantMobile());
        }

        if (req.getApplicantPan() != null) {
            app.setApplicantPan(req.getApplicantPan());
        }

        if (req.getAddrDoorNo() != null) {
            app.setAddrDoorNo(req.getAddrDoorNo());
        }

        if (req.getAddrStreet() != null) {
            app.setAddrStreet(req.getAddrStreet());
        }

        if (req.getAddrCity() != null) {
            app.setAddrCity(req.getAddrCity());
        }

        if (req.getAddrState() != null) {
            app.setAddrState(req.getAddrState());
        }

        if (req.getAddrPincode() != null) {
            app.setAddrPincode(req.getAddrPincode());
        }

        if (req.getEmploymentType() != null) {
            app.setEmploymentType(req.getEmploymentType());
        }

        if (req.getEmployer() != null) {
            app.setEmployer(req.getEmployer());
        }

        if (req.getMonthlyIncome() != null) {
            app.setMonthlyIncome(req.getMonthlyIncome());
        }

        if (req.getOtherEmis() != null) {
            app.setOtherEmis(req.getOtherEmis());
        }

        if (req.getPropertyAddress() != null) {
            app.setPropertyAddress(req.getPropertyAddress());
        }

        if (req.getPropertyType() != null) {
            app.setPropertyType(req.getPropertyType());
        }

        if (req.getPropertyValue() != null) {
            app.setPropertyValue(req.getPropertyValue());
        }

        if (req.getAccountNumber() != null) {
            app.setAccountNumber(req.getAccountNumber());
        }
    }

    private void syncDisbursementBankDetails(LoanApplication app) {
        if (app == null) {
            return;
        }

        if (app.getAppId() == null || app.getAppId().trim().isEmpty()) {
            return;
        }

        if (app.getAccountNumber() == null || app.getAccountNumber().trim().isEmpty()) {
            return;
        }

        Disbursement disbursement = disbursementRepository
                .findByAppIdAndDeletedAtIsNull(app.getAppId())
                .orElseGet(Disbursement::new);

        disbursement.setAppId(app.getAppId());
        disbursement.setBankDetails(app.getAccountNumber());

        disbursementRepository.save(disbursement);
    }

    private String generateAppId() {
        return "APP-" + UUID.randomUUID()
                .toString()
                .substring(0, 8)
                .toUpperCase();
    }

    private String generateTrackingNo() {
        String datePart = OffsetDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMdd"));

        return "TRK-" + datePart + "-" + UUID.randomUUID()
                .toString()
                .substring(0, 6)
                .toUpperCase();
    }

    private String safeString(String value) {
        return value == null ? "" : value;
    }

    private Integer safeInteger(Integer value) {
        return value == null ? 0 : value;
    }
}