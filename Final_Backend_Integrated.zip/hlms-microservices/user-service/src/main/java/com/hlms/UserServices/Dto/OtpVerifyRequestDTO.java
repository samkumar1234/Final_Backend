package com.hlms.UserServices.Dto;


public class OtpVerifyRequestDTO {

    private String email;
    private String otpCode;

    public OtpVerifyRequestDTO() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOtpCode() {
        return otpCode;
    }

    public void setOtpCode(String otpCode) {
        this.otpCode = otpCode;
    }
}
