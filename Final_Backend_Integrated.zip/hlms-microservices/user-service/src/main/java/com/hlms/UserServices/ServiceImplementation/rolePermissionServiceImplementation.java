package com.hlms.UserServices.ServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hlms.UserServices.Entity.rolePermissionEntity;
import com.hlms.UserServices.Exception.ResourceNotFoundException;
import com.hlms.UserServices.Repository.rolePermissionRepository;
import com.hlms.UserServices.Service.rolePermissionService;

@Service
public class rolePermissionServiceImplementation
        implements rolePermissionService {

    @Autowired
    private rolePermissionRepository repository;

    @Override
    @Transactional
    public rolePermissionEntity createPermission(
            rolePermissionEntity permission) {

        return repository.save(permission);
    }

    @Override
    @Transactional(readOnly = true)
    public List<rolePermissionEntity>
    getAllPermissions() {

        return repository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public rolePermissionEntity getPermission(
            Long permissionId) {

        return repository.findById(permissionId)
                .orElseThrow(
                        () -> new ResourceNotFoundException(
                                "Permission Not Found"));
    }

    @Override
    @Transactional
    public rolePermissionEntity updatePermission(
            Long permissionId,
            rolePermissionEntity permission) {

        rolePermissionEntity existing =
                getPermission(permissionId);

        existing.setRole(
                permission.getRole());

        existing.setModule(
                permission.getModule());

        existing.setCanView(
                permission.getCanView());

        existing.setCanAdd(
                permission.getCanAdd());

        existing.setCanEdit(
                permission.getCanEdit());

        existing.setCanDelete(
                permission.getCanDelete());

        return repository.save(existing);
    }

    @Override
    @Transactional
    public void deletePermission(
            Long permissionId) {

        rolePermissionEntity permission =
                getPermission(permissionId);

        repository.delete(permission);
    }
}