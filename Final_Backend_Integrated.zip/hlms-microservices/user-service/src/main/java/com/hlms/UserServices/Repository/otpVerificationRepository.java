package com.hlms.UserServices.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hlms.UserServices.Entity.otpVerificationEntity;

@Repository
public interface otpVerificationRepository
        extends JpaRepository<otpVerificationEntity, String> {

    Optional<otpVerificationEntity>
    findTopByEmailAndConsumedFalseOrderByCreatedAtDesc(
            String email);

    Optional<otpVerificationEntity>
    findByEmailAndOtpCodeAndConsumedFalse(
            String email,
            String otpCode);
}