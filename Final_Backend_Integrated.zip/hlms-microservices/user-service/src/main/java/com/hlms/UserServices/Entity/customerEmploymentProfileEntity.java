package com.hlms.UserServices.Entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
@Table(name = "customer_employment_profile")
public class customerEmploymentProfileEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "profile_id")
    private Long profileId;

    @Column(name = "user_email", nullable = false, unique = true)
    private String userEmail;

    @Column(name = "employment_type")
    private String employmentType;

    @Column(name = "employer")
    private String employer;

    @Column(name = "monthly_income")
    private BigDecimal monthlyIncome;

    @Column(name = "other_emis")
    private BigDecimal otherEmis;

    @Column(name = "desired_amount")
    private BigDecimal desiredAmount;

    @Column(name = "pan")
    private String pan;

    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    public customerEmploymentProfileEntity() {
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    public String getEmployer() {
        return employer;
    }

    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public BigDecimal getOtherEmis() {
        return otherEmis;
    }

    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }

    public BigDecimal getDesiredAmount() {
        return desiredAmount;
    }

    public void setDesiredAmount(BigDecimal desiredAmount) {
        this.desiredAmount = desiredAmount;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public LocalDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(LocalDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }
}