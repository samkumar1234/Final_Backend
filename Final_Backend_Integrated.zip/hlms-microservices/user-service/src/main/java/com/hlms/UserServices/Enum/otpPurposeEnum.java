package com.hlms.UserServices.Enum;

public enum otpPurposeEnum {

    LOGIN,
    FORGOT_PASSWORD,
    REGISTRATION
}