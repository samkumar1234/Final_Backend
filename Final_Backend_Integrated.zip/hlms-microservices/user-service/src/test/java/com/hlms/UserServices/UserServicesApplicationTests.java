package com.hlms.UserServices;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.hlms.UserServices.Dto.LoginRequestDTO;
import com.hlms.UserServices.Dto.RegisterRequestDTO;
import com.hlms.UserServices.Entity.appUserEntity;
import com.hlms.UserServices.Entity.customerEmploymentProfileEntity;
import com.hlms.UserServices.Entity.otpVerificationEntity;
import com.hlms.UserServices.Entity.rolePermissionEntity;
import com.hlms.UserServices.Enum.roleEnum;
import com.hlms.UserServices.Exception.DuplicateRecordException;
import com.hlms.UserServices.Exception.InvalidCredentialsException;
import com.hlms.UserServices.Exception.InvalidOtpException;
import com.hlms.UserServices.Exception.ResourceNotFoundException;
import com.hlms.UserServices.Repository.appUserRepository;
import com.hlms.UserServices.Repository.customerEmploymentProfileRepository;
import com.hlms.UserServices.Repository.otpVerificationRepository;
import com.hlms.UserServices.Repository.rolePermissionRepository;

import com.hlms.UserServices.ServiceImplementation.appUserServiceImplementation;
import com.hlms.UserServices.ServiceImplementation.customerEmploymentProfileServiceImplementation;
import com.hlms.UserServices.ServiceImplementation.otpVerificationServiceImplementation;
import com.hlms.UserServices.ServiceImplementation.rolePermissionServiceImplementation;

@ExtendWith(MockitoExtension.class)
class UserServicesApplicationTests {

    // ==================================
    // APP USER
    // ==================================

    @InjectMocks
    private appUserServiceImplementation userService;

    @Mock
    private appUserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;


    @Test
    void registerUserSuccess() {

        RegisterRequestDTO dto =
                new RegisterRequestDTO();

        dto.setEmail("test@test.com");
        dto.setName("Test");
        dto.setMobile("9876543210");
        dto.setPassword("Password@123");
        dto.setRole(roleEnum.CUSTOMER);

        when(userRepository.existsByEmail(any()))
                .thenReturn(false);

        when(passwordEncoder.encode(any()))
                .thenReturn("encoded");

        when(userRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        assertNotNull(
                userService.registerUser(dto));
    }
    @Test
    void updateUserSuccess() {

        appUserEntity existing = new appUserEntity();
        existing.setEmail("test@test.com");

        appUserEntity updated = new appUserEntity();
        updated.setName("Updated");

        when(userRepository.findByEmailAndDeletedAtIsNull(anyString()))
                .thenReturn(Optional.of(existing));

        when(userRepository.save(any()))
                .thenReturn(existing);

        assertNotNull(
                userService.updateUser(
                        "test@test.com",
                        updated));
    }
    @Test
    void deleteUserSuccess() {

        appUserEntity user =
                new appUserEntity();

        when(userRepository
                .findByEmailAndDeletedAtIsNull(
                        anyString()))
                .thenReturn(Optional.of(user));

        assertDoesNotThrow(
                () -> userService.deleteUser(
                        "test@test.com"));
    }
    @Test
    void deleteUserNotFound() {

        when(userRepository
                .findByEmailAndDeletedAtIsNull(
                        anyString()))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userService.deleteUser(
                        "missing@test.com"));
    }
    @Test
    void forgotPasswordSuccess() {

        appUserEntity user =
                new appUserEntity();

        when(userRepository
                .findByEmailAndDeletedAtIsNull(
                        anyString()))
                .thenReturn(Optional.of(user));

        assertNotNull(
                userService.forgotPassword(
                        "test@test.com"));
    }
    @Test
    void forgotPasswordUserNotFound() {

        when(userRepository
                .findByEmailAndDeletedAtIsNull(
                        anyString()))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userService.forgotPassword(
                        "test@test.com"));
    }
    @Test
    void registerDuplicateUser() {

        RegisterRequestDTO dto =
                new RegisterRequestDTO();

        dto.setEmail("test@test.com");

        when(userRepository.existsByEmail(any()))
                .thenReturn(true);

        assertThrows(
                DuplicateRecordException.class,
                () -> userService.registerUser(dto));
    }

    @Test
    void loginSuccess() {

        appUserEntity user =
                new appUserEntity();

        user.setEmail("admin@test.com");
        user.setPasswordHash("encoded");
        user.setRole(roleEnum.ADMIN);

        LoginRequestDTO req =
                new LoginRequestDTO();

        req.setEmail("admin@test.com");
        req.setPassword("Admin@123");

        when(userRepository
                .findByEmailAndDeletedAtIsNull(any()))
                .thenReturn(Optional.of(user));

        when(passwordEncoder.matches(any(), any()))
                .thenReturn(true);


        assertNotNull(userService.login(req));
    }

    @Test
    void loginUserNotFound() {

        LoginRequestDTO req =
                new LoginRequestDTO();

        req.setEmail("wrong@test.com");

        when(userRepository
                .findByEmailAndDeletedAtIsNull(any()))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userService.login(req));
    }

    @Test
    void loginInvalidPassword() {

        appUserEntity user =
                new appUserEntity();

        user.setPasswordHash("encoded");

        LoginRequestDTO req =
                new LoginRequestDTO();

        req.setEmail("test@test.com");
        req.setPassword("wrong");

        when(userRepository
                .findByEmailAndDeletedAtIsNull(any()))
                .thenReturn(Optional.of(user));

        when(passwordEncoder.matches(any(), any()))
                .thenReturn(false);

        assertThrows(
                InvalidCredentialsException.class,
                () -> userService.login(req));
    }

    @Test
    void getUserSuccess() {

        appUserEntity user =
                new appUserEntity();

        user.setEmail("test@test.com");

        when(userRepository
                .findByEmailAndDeletedAtIsNull(any()))
                .thenReturn(Optional.of(user));

        assertNotNull(
                userService.getUserByEmail("test@test.com"));
    }

    @Test
    void getUserNotFound() {

        when(userRepository
                .findByEmailAndDeletedAtIsNull(any()))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userService.getUserByEmail("x@test.com"));
    }

    // ==================================
    // CUSTOMER PROFILE
    // ==================================

    @InjectMocks
    private customerEmploymentProfileServiceImplementation profileService;

    @Mock
    private customerEmploymentProfileRepository profileRepository;

    @Test
    void createProfileSuccess() {

        customerEmploymentProfileEntity profile =
                new customerEmploymentProfileEntity();

        profile.setUserEmail("customer@test.com");

        when(profileRepository.existsByUserEmail(any()))
                .thenReturn(false);

        when(profileRepository.save(any()))
                .thenReturn(profile);

        assertNotNull(
                profileService.createProfile(profile));
    }
    @Test
    void updateProfileSuccess() {

        customerEmploymentProfileEntity existing =
                new customerEmploymentProfileEntity();

        existing.setUserEmail(
                "customer@test.com");

        customerEmploymentProfileEntity update =
                new customerEmploymentProfileEntity();

        update.setEmployer("Infosys");

        when(profileRepository
                .findByUserEmailAndDeletedAtIsNull(
                        anyString()))
                .thenReturn(Optional.of(existing));

        when(profileRepository.save(any()))
                .thenReturn(existing);

        assertNotNull(
                profileService.updateProfile(
                        "customer@test.com",
                        update));
    }
    @Test
    void updateProfileNotFound() {

        when(profileRepository
                .findByUserEmailAndDeletedAtIsNull(
                        anyString()))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> profileService.updateProfile(
                        "x@test.com",
                        new customerEmploymentProfileEntity()));
    }
    @Test
    void deleteProfileSuccess() {

        customerEmploymentProfileEntity profile =
                new customerEmploymentProfileEntity();

        when(profileRepository
                .findByUserEmailAndDeletedAtIsNull(
                        anyString()))
                .thenReturn(Optional.of(profile));

        assertDoesNotThrow(
                () -> profileService.deleteProfile(
                        "customer@test.com"));
    }
    @Test
    void deleteProfileNotFound() {

        when(profileRepository
                .findByUserEmailAndDeletedAtIsNull(
                        anyString()))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> profileService.deleteProfile(
                        "missing@test.com"));
    }
    @Test
    void createDuplicateProfile() {

        customerEmploymentProfileEntity profile =
                new customerEmploymentProfileEntity();

        profile.setUserEmail("customer@test.com");

        when(profileRepository.existsByUserEmail(any()))
                .thenReturn(true);

        assertThrows(
                DuplicateRecordException.class,
                () -> profileService.createProfile(profile));
    }

    @Test
    void getProfileSuccess() {

        customerEmploymentProfileEntity profile =
                new customerEmploymentProfileEntity();

        profile.setUserEmail("customer@test.com");

        when(profileRepository
                .findByUserEmailAndDeletedAtIsNull(any()))
                .thenReturn(Optional.of(profile));

        assertNotNull(
                profileService.getProfile("customer@test.com"));
    }

    @Test
    void getProfileNotFound() {

        when(profileRepository
                .findByUserEmailAndDeletedAtIsNull(any()))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> profileService.getProfile("x@test.com"));
    }

    @Test
    void getAllProfiles() {

        when(profileRepository.findAll())
                .thenReturn(Arrays.asList(
                        new customerEmploymentProfileEntity(),
                        new customerEmploymentProfileEntity()));

        assertEquals(
                2,
                profileService.getAllProfiles().size());
    }

    @Test
    void getAllProfilesEmpty() {

        when(profileRepository.findAll())
                .thenReturn(Arrays.asList());

        assertEquals(
                0,
                profileService.getAllProfiles().size());
    }

    // ==================================
    // ROLE PERMISSION
    // ==================================

    @InjectMocks
    private rolePermissionServiceImplementation permissionService;

    @Mock
    private rolePermissionRepository permissionRepository;

    @Test
    void createPermissionSuccess() {

        rolePermissionEntity entity =
                new rolePermissionEntity();

        entity.setRole("ADMIN");

        when(permissionRepository.save(any()))
                .thenReturn(entity);

        assertEquals(
                "ADMIN",
                permissionService
                        .createPermission(entity)
                        .getRole());
    }
    @Test
    void updatePermissionSuccess() {

        rolePermissionEntity existing =
                new rolePermissionEntity();

        existing.setPermissionId(1L);

        rolePermissionEntity update =
                new rolePermissionEntity();

        update.setRole("ADMIN");

        when(permissionRepository.findById(1L))
                .thenReturn(Optional.of(existing));

        when(permissionRepository.save(any()))
                .thenReturn(existing);

        assertNotNull(
                permissionService.updatePermission(
                        1L,
                        update));
    }
    @Test
    void updatePermissionNotFound() {

        when(permissionRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> permissionService.updatePermission(
                        1L,
                        new rolePermissionEntity()));
    }
    @Test
    void deletePermissionSuccess() {

        rolePermissionEntity permission =
                new rolePermissionEntity();

        permission.setPermissionId(1L);

        when(permissionRepository.findById(1L))
                .thenReturn(Optional.of(permission));

        assertDoesNotThrow(
                () -> permissionService.deletePermission(
                        1L));
    }
    @Test
    void deletePermissionNotFound() {

        when(permissionRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> permissionService.deletePermission(
                        1L));
    }
    @Test
    void getPermissionSuccess() {

        rolePermissionEntity permission =
                new rolePermissionEntity();

        permission.setPermissionId(1L);

        when(permissionRepository.findById(1L))
                .thenReturn(Optional.of(permission));

        assertNotNull(
                permissionService.getPermission(1L));
    }

    @Test
    void getPermissionNotFound() {

        when(permissionRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> permissionService.getPermission(1L));
    }

    @Test
    void getAllPermissionSuccess() {

        when(permissionRepository.findAll())
                .thenReturn(Arrays.asList(
                        new rolePermissionEntity(),
                        new rolePermissionEntity()));

        assertEquals(
                2,
                permissionService.getAllPermissions().size());
    }

    // ==================================
    // OTP
    // ==================================

    @InjectMocks
    private otpVerificationServiceImplementation otpService;

    @Mock
    private otpVerificationRepository otpRepository;

    @Test
    void generateOtpSuccess() {

        when(otpRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        String otp =
                otpService.generateOtp(
                        "test@test.com",
                        "LOGIN");

        assertNotNull(otp);
    }

    @Test
    void verifyOtpSuccess() {

        otpVerificationEntity otp =
                new otpVerificationEntity();

        otp.setEmail("test@test.com");
        otp.setOtpCode("123456");
        otp.setConsumed(false);
        otp.setExpiresAt(
                LocalDateTime.now().plusMinutes(5));

        when(
            otpRepository.findByEmailAndOtpCodeAndConsumedFalse(
                    any(),
                    any()))
            .thenReturn(Optional.of(otp));

        assertEquals(
                "OTP Verified Successfully",
                otpService.verifyOtp(
                        "test@test.com",
                        "123456"));
    }

    @Test
    void verifyOtpExpired() {

        otpVerificationEntity otp =
                new otpVerificationEntity();

        otp.setEmail("test@test.com");
        otp.setOtpCode("123456");
        otp.setConsumed(false);

        otp.setExpiresAt(
                LocalDateTime.now().minusMinutes(5));

        when(
            otpRepository.findByEmailAndOtpCodeAndConsumedFalse(
                    any(),
                    any()))
            .thenReturn(Optional.of(otp));

        assertThrows(
                InvalidOtpException.class,
                () -> otpService.verifyOtp(
                        "test@test.com",
                        "123456"));
    }

    @Test
    void verifyOtpInvalid() {

        when(
            otpRepository.findByEmailAndOtpCodeAndConsumedFalse(
                    any(),
                    any()))
            .thenReturn(Optional.empty());

        assertThrows(
                InvalidOtpException.class,
                () -> otpService.verifyOtp(
                        "test@test.com",
                        "123456"));
    }
}