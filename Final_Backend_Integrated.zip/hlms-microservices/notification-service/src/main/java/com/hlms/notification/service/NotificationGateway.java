package com.hlms.notification.service;

/**
 * Abstraction over the actual send mechanism for a channel (US-NM-05 Multi-Channel
 * Communication). NotificationService always writes the notification row first (so it's
 * retrievable in-app regardless of what happens next), then calls this per requested channel.
 *
 * Swap LoggingNotificationGateway for a real implementation (Twilio/SNS for SMS, SES/SMTP
 * for email, a push-notification provider for in-app) by providing another @Service bean
 * of this type and marking it @Primary - no other code needs to change.
 */
public interface NotificationGateway {
    void dispatch(String channel, String userEmail, String title, String body);
}
