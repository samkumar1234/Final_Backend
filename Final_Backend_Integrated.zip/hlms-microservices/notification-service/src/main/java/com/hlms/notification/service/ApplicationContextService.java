package com.hlms.notification.service;

import com.hlms.notification.client.ApplicationSummaryResponse;
import com.hlms.notification.client.DocumentResponse;
import com.hlms.notification.client.DocumentStatusClient;
import com.hlms.notification.client.DocumentStatusResponse;
import com.hlms.notification.client.EmiInstallmentResponse;
import com.hlms.notification.client.LegalStatusResponse;
import com.hlms.notification.client.LegalVerificationClient;
import com.hlms.notification.client.LegalVerificationResponse;
import com.hlms.notification.client.LoanApplicationClient;
import com.hlms.notification.client.RepaymentSummaryClient;
import com.hlms.notification.client.RepaymentSummaryResponse;
import com.hlms.notification.client.UserClient;
import com.hlms.notification.client.UserSummaryResponse;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * FIX: UserClient, DocumentStatusClient, LegalVerificationClient and
 * RepaymentSummaryClient were declared but never injected anywhere, so nothing in this
 * service ever fetched cross-service details. This is the component that uses them.
 */
@Service
public class ApplicationContextService {

    private static final Logger log = LoggerFactory.getLogger(ApplicationContextService.class);

    private final LoanApplicationClient loanApplicationClient;
    private final UserClient userClient;
    private final DocumentStatusClient documentStatusClient;
    private final LegalVerificationClient legalVerificationClient;
    private final RepaymentSummaryClient repaymentSummaryClient;

    public ApplicationContextService(LoanApplicationClient loanApplicationClient,
                                     UserClient userClient,
                                     DocumentStatusClient documentStatusClient,
                                     LegalVerificationClient legalVerificationClient,
                                     RepaymentSummaryClient repaymentSummaryClient) {
        this.loanApplicationClient = loanApplicationClient;
        this.userClient = userClient;
        this.documentStatusClient = documentStatusClient;
        this.legalVerificationClient = legalVerificationClient;
        this.repaymentSummaryClient = repaymentSummaryClient;
    }

    /** Loan application facts, or null if loan-service has no such application / is down. */
    public ApplicationSummaryResponse getApplication(String appId) {
        return callQuietly("loan-service", () -> loanApplicationClient.getApplication(appId));
    }

    /** True only if loan-service positively answered 404 for this appId. */
    public boolean applicationDefinitelyMissing(String appId) {
        try {
            loanApplicationClient.getApplication(appId);
            return false;
        } catch (FeignException.NotFound notFound) {
            return true;
        } catch (Exception ex) {
            // Down, unauthorised, unreachable - not evidence that the application is missing.
            log.warn("Could not verify application {} with loan-service: {}", appId, ex.toString());
            return false;
        }
    }

    public UserSummaryResponse getUser(String email) {
        if (email == null || email.isBlank()) {
            return null;
        }
        return callQuietly("user-service", () -> userClient.getUser(email));
    }

    public DocumentStatusResponse getDocumentStatus(String appId) {
        List<DocumentResponse> documents =
                callQuietly("document-service", () -> documentStatusClient.getDocuments(appId));
        if (documents == null) {
            return null;
        }
        int verified = 0;
        int rejected = 0;
        for (DocumentResponse document : documents) {
            String status = document.verificationStatus() == null ? "" : document.verificationStatus();
            if (status.equalsIgnoreCase("Verified") || status.equalsIgnoreCase("Approved")) {
                verified++;
            } else if (status.equalsIgnoreCase("Rejected")) {
                rejected++;
            }
        }
        int total = documents.size();
        return new DocumentStatusResponse(appId, total, verified, rejected, total > 0 && verified == total);
    }

    public LegalStatusResponse getLegalStatus(String appId) {
        try {
            LegalVerificationResponse verification = legalVerificationClient.getByApplication(appId);
            if (verification == null) {
                return new LegalStatusResponse(appId, false, null, null);
            }
            return new LegalStatusResponse(appId, true, verification.decision(), verification.officerEmail());
        } catch (FeignException.NotFound notFound) {
            // No verification raised yet - a real answer, not a failure.
            return new LegalStatusResponse(appId, false, null, null);
        } catch (Exception ex) {
            log.warn("legal-service lookup failed for {}: {}", appId, ex.toString());
            return null;
        }
    }

    public RepaymentSummaryResponse getRepaymentSummary(String appId) {
        List<EmiInstallmentResponse> schedule =
                callQuietly("repayment-service", () -> repaymentSummaryClient.getSchedule(appId));
        if (schedule == null) {
            return null;
        }
        LocalDate today = LocalDate.now();
        int paid = 0;
        int overdue = 0;
        for (EmiInstallmentResponse installment : schedule) {
            String status = installment.status() == null ? "" : installment.status();
            boolean isPaid = status.equalsIgnoreCase("Paid") || installment.paidDate() != null;
            if (isPaid) {
                paid++;
            } else if (installment.dueDate() != null && installment.dueDate().isBefore(today)) {
                overdue++;
            }
        }
        // Standard NPA-style rule of thumb: three consecutive missed EMIs.
        return new RepaymentSummaryResponse(appId, schedule.size(), paid, overdue, overdue >= 3);
    }

    /** One call that gathers every section, naming whatever could not be reached. */
    public com.hlms.notification.dto.ApplicationContextResponse getFullContext(String appId) {
        List<String> unavailable = new ArrayList<>();

        ApplicationSummaryResponse application = getApplication(appId);
        if (application == null) unavailable.add("loan-service");

        String email = application == null ? null : application.userEmail();
        UserSummaryResponse user = getUser(email);
        if (email != null && user == null) unavailable.add("user-service");

        DocumentStatusResponse documents = getDocumentStatus(appId);
        if (documents == null) unavailable.add("document-service");

        LegalStatusResponse legal = getLegalStatus(appId);
        if (legal == null) unavailable.add("legal-service");

        RepaymentSummaryResponse repayment = getRepaymentSummary(appId);
        if (repayment == null) unavailable.add("repayment-service");

        return new com.hlms.notification.dto.ApplicationContextResponse(
                appId, application, user, documents, legal, repayment, unavailable);
    }

    private <T> T callQuietly(String serviceName, Supplier<T> call) {
        try {
            return call.get();
        } catch (FeignException.NotFound notFound) {
            return null;
        } catch (Exception ex) {
            log.warn("{} lookup failed: {}", serviceName, ex.toString());
            return null;
        }
    }
}
