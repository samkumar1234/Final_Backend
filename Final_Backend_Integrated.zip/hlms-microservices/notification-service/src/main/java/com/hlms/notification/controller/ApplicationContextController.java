package com.hlms.notification.controller;

import com.hlms.notification.dto.ApplicationContextResponse;
import com.hlms.notification.service.ApplicationContextService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * NEW: exposes the aggregated cross-service view directly, so the details can be checked
 * without going through a service request. Sections that could not be reached come back
 * null, and the failing service is listed in "unavailable".
 */
@RestController
@RequestMapping("/api/application-context")
public class ApplicationContextController {

    private final ApplicationContextService service;

    public ApplicationContextController(ApplicationContextService service) {
        this.service = service;
    }

    @GetMapping("/{appId}")
    public ApplicationContextResponse get(@PathVariable String appId) {
        return service.getFullContext(appId);
    }
}
