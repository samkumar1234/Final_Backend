package com.hlms.notification.entity;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "notification")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Notification {

    @Id
    @Column(name = "notification_id", length = 50)
    private String notificationId;

    @Column(name = "user_email", nullable = false)
    private String userEmail;

    @Column(name = "title", length = 150, nullable = false)
    private String title;

    @Column(name = "body", columnDefinition = "TEXT")
    private String body;

    // FIX: was @ElementCollection, which mapped to a separate "notification_channels"
    // table rather than the notification.channels column. Now stored in-row as CSV.
    @Convert(converter = StringListConverter.class)
    @Column(name = "channels", columnDefinition = "TEXT")
    private List<String> channels = new ArrayList<>(List.of("inapp")); // inapp, sms, email

    @Column(name = "is_read", nullable = false)
    private Boolean isRead = false;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
        if (isRead == null) isRead = false;
        if (channels == null || channels.isEmpty()) channels = new ArrayList<>(List.of("inapp"));
    }

    public Notification() {
    }

    public Notification(String notificationId, String userEmail, String title, String body,
                        List<String> channels, Boolean isRead,
                        OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.notificationId = notificationId;
        this.userEmail = userEmail;
        this.title = title;
        this.body = body;
        this.channels = channels == null ? new ArrayList<>() : new ArrayList<>(channels);
        this.isRead = isRead;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getNotificationId() {
        return notificationId;
    }
    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }
    public String getUserEmail() {
        return userEmail;
    }
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getBody() {
        return body;
    }
    public void setBody(String body) {
        this.body = body;
    }
    public List<String> getChannels() {
        return channels;
    }
    public void setChannels(List<String> channels) {
        this.channels = channels == null ? new ArrayList<>() : new ArrayList<>(channels);
    }

    /**
     * FIX: the old accessor was isRead(), so Jackson published the field as "read" and a
     * client reading notification.isRead always got undefined. Published as "isRead" now,
     * with "read" kept as an alias so anything already reading the old key still works.
     */
    public Boolean getIsRead() {
        return isRead;
    }
    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }
    @JsonGetter("read")
    public Boolean readAlias() {
        return isRead;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String notificationId;
        private String userEmail;
        private String title;
        private String body;
        private List<String> channels = new ArrayList<>(List.of("inapp"));
        private Boolean isRead = false;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder notificationId(String notificationId) {
            this.notificationId = notificationId;
            return this;
        }
        public Builder userEmail(String userEmail) {
            this.userEmail = userEmail;
            return this;
        }
        public Builder title(String title) {
            this.title = title;
            return this;
        }
        public Builder body(String body) {
            this.body = body;
            return this;
        }
        public Builder channels(List<String> channels) {
            this.channels = channels == null ? new ArrayList<>() : new ArrayList<>(channels);
            return this;
        }
        public Builder isRead(Boolean isRead) {
            this.isRead = isRead;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public Notification build() {
            return new Notification(notificationId, userEmail, title, body, channels, isRead, createdAt, deletedAt);
        }
    }
}
