package com.hlms.notification.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

/**
 * Subset of loan-service's GET /api/loan-applications/{appId} response.
 * The remaining ~25 keys in that payload are ignored.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ApplicationSummaryResponse(
        String appId,
        String trackingNo,
        String userEmail,
        String productId,
        BigDecimal loanAmount,
        String status,
        String applicantName,
        String applicantMobile) { }
