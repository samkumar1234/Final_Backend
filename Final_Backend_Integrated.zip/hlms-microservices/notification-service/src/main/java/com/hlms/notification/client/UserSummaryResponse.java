package com.hlms.notification.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Subset of user-service's appUserEntity JSON that this service cares about.
 * Unknown fields (passwordHash, idType, timestamps...) are ignored.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record UserSummaryResponse(
        String email,
        String name,
        String mobile,
        String role,
        Boolean active,
        Boolean prefSms,
        Boolean prefEmail,
        Boolean prefInapp) { }
