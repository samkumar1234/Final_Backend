package com.hlms.notification.dto;

import com.hlms.notification.client.ApplicationSummaryResponse;
import com.hlms.notification.client.DocumentStatusResponse;
import com.hlms.notification.client.LegalStatusResponse;
import com.hlms.notification.client.RepaymentSummaryResponse;
import com.hlms.notification.client.UserSummaryResponse;

import java.util.List;

/**
 * Everything notification-service can gather about one application from the other
 * services. Any section that could not be reached is null, and the service that failed
 * is named in {@code unavailable} - so a downstream outage degrades the response instead
 * of blanking it or throwing.
 */
public record ApplicationContextResponse(
        String appId,
        ApplicationSummaryResponse application,
        UserSummaryResponse user,
        DocumentStatusResponse documents,
        LegalStatusResponse legal,
        RepaymentSummaryResponse repayment,
        List<String> unavailable) { }
