package com.hlms.notification.service;

import com.hlms.notification.entity.AppUser;
import com.hlms.notification.entity.Notification;
import com.hlms.notification.exception.BadRequestException;
import com.hlms.notification.exception.ResourceNotFoundException;
import com.hlms.notification.repository.AppUserRepository;
import com.hlms.notification.repository.NotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Backs feature "8. Notification & Communication Management". */
@Service
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    private final NotificationRepository repository;
    private final AppUserRepository userRepository;
    private final NotificationGateway gateway;

    public NotificationService(NotificationRepository repository,
                               AppUserRepository userRepository,
                               NotificationGateway gateway) {
        this.repository = repository;
        this.userRepository = userRepository;
        this.gateway = gateway;
    }

    @Transactional
    public Notification send(String userEmail, String title, String body, List<String> channels) {
        // FIX: a missing userEmail/title used to reach the DB and surface as a raw 500
        // not-null violation.
        if (userEmail == null || userEmail.isBlank()) {
            throw new BadRequestException("userEmail is required");
        }
        if (title == null || title.isBlank()) {
            throw new BadRequestException("title is required");
        }

        List<String> effectiveChannels = resolveChannels(userEmail, channels);

        Notification notification = Notification.builder()
                .notificationId("NOTIF-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase())
                .userEmail(userEmail)
                .title(title)
                .body(body)
                .channels(effectiveChannels)
                .isRead(false)
                .build();

        Notification saved = repository.save(notification);

        // US-NM-05 Multi-Channel Communication: dispatch on every effective channel. The
        // row above is saved regardless of dispatch outcome, so in-app history never
        // depends on an external gateway succeeding.
        for (String channel : effectiveChannels) {
            try {
                gateway.dispatch(channel, userEmail, title, body);
            } catch (Exception ex) {
                // FIX: this used to swallow the failure silently, which made a broken
                // gateway impossible to diagnose. Still non-fatal, but now visible.
                log.warn("Dispatch on channel {} for {} failed: {}", channel, userEmail, ex.toString());
            }
        }
        return saved;
    }

    /**
     * US-NM-04: honour the recipient's app_user.pref_sms / pref_email / pref_inapp flags.
     * An explicit channel list from the caller wins (system-critical messages), otherwise
     * the user's own preferences decide, falling back to in-app.
     */
    private List<String> resolveChannels(String userEmail, List<String> requested) {
        if (requested != null && !requested.isEmpty()) {
            return new ArrayList<>(requested);
        }

        List<String> preferred = new ArrayList<>();
        Optional<AppUser> user = userRepository.findByEmailAndDeletedAtIsNull(userEmail);
        if (user.isPresent()) {
            AppUser u = user.get();
            if (Boolean.TRUE.equals(u.isPrefInapp())) preferred.add("inapp");
            if (Boolean.TRUE.equals(u.isPrefEmail())) preferred.add("email");
            if (Boolean.TRUE.equals(u.isPrefSms())) preferred.add("sms");
        }
        if (preferred.isEmpty()) {
            preferred.add("inapp");
        }
        return preferred;
    }

    public List<Notification> listForUser(String userEmail) {
        return repository.findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc(userEmail);
    }

    /** Paginated/sortable variant - e.g. ?page=0&size=20&sort=createdAt,desc */
    public Page<Notification> listForUser(String userEmail, Pageable pageable) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail, pageable);
    }

    public List<Notification> listUnread(String userEmail) {
        return repository.findByUserEmailAndIsReadAndDeletedAtIsNull(userEmail, false);
    }

    @Transactional
    public Notification markRead(String notificationId) {
        // FIX: was orElseThrow() with no argument - an unknown id produced a bare
        // NoSuchElementException and a 500 instead of a 404.
        Notification n = repository.findById(notificationId)
                .filter(existing -> existing.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found: " + notificationId));
        n.setIsRead(true);
        return repository.save(n);
    }
}
