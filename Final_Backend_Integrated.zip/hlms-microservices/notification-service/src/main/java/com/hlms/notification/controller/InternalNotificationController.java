package com.hlms.notification.controller;
import com.hlms.notification.entity.Notification;
import com.hlms.notification.service.NotificationService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import java.util.Map;
/**
 * Service-to-service endpoint (not for end users): other microservices call this
 * to send a notification on behalf of a system flow (OTP delivery, EMI reminders,
 * default escalation) that has no logged-in user/JWT of its own. Protected by
 * InternalApiKeyFilter instead of the normal JWT filter - see SecurityConfig.
 */
@RestController
@RequestMapping("/internal/notifications")
public class InternalNotificationController {
    private final NotificationService service;
    @PostMapping
    public Notification send(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<String> channels = (List<String>) body.get("channels");
        return service.send((String) body.get("userEmail"), (String) body.get("title"), (String) body.get("body"), channels);
    }

    public InternalNotificationController(NotificationService service) {
        this.service = service;
    }
}