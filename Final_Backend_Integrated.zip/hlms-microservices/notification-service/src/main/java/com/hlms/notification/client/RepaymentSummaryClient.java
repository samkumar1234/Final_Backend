package com.hlms.notification.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * Fetches the EMI schedule for an application from repayment-service.
 *
 * FIX: was GET /internal/repayment/application/{appId}/summary (nonexistent). The real
 * endpoint is EmiInstallmentController -> GET /api/emi/{appId}/schedule; paid/overdue
 * counts are derived in ApplicationContextService.
 */
@FeignClient(name = "repayment-service", configuration = FeignClientConfig.class)
public interface RepaymentSummaryClient {

    @GetMapping("/api/emi/{appId}/schedule")
    List<EmiInstallmentResponse> getSchedule(@PathVariable("appId") String appId);
}
