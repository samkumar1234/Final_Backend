package com.hlms.notification.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * Fetches the uploaded documents for an application from document-service.
 *
 * FIX: was GET /internal/documents/application/{appId}/status (nonexistent). The real
 * endpoint is ApplicationDocumentController -> GET /api/application-documents/app/{appId},
 * which returns the raw document rows; the counts are derived in ApplicationContextService.
 */
@FeignClient(name = "document-service", configuration = FeignClientConfig.class)
public interface DocumentStatusClient {

    @GetMapping("/api/application-documents/app/{appId}")
    List<DocumentResponse> getDocuments(@PathVariable("appId") String appId);
}
