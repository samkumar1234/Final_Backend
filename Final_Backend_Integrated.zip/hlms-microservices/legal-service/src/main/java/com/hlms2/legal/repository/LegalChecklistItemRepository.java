package com.hlms2.legal.repository;

import com.hlms2.legal.entity.LegalChecklistItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LegalChecklistItemRepository extends JpaRepository<LegalChecklistItem, String> {
    Optional<LegalChecklistItem> findByChecklistItemIdAndDeletedAtIsNull(String checklistItemId);
    List<LegalChecklistItem> findByDeletedAtIsNull();
}
