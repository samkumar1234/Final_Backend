package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.BankOfficeDecisionDTO;
import com.hlms2.legal.entity.BankOfficeDecision;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.BankOfficeDecisionRepository;
import com.hlms2.legal.service.BankOfficeDecisionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Ported from hlms2.serviceimpl.BankOfficeDecisionServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql:
 *
 * - decision_id is now the surrogate PK; app_id is a unique lookup column.
 * - the "decision" column was renamed to "status" in the schema - the DTO
 *   and entity field are renamed to match.
 * - delete is now a soft delete (sets deleted_at), with a matching restore().
 *
 * Business rule unchanged (US-EL-05): reason is required unless status is
 * APPROVED.
 */
@Service
@Transactional
public class BankOfficeDecisionServiceImpl implements BankOfficeDecisionService {

    private static final List<String> VALID_STATUSES = List.of("APPROVED", "CONDITIONALLY_APPROVED", "REJECTED", "PENDING");

    private final BankOfficeDecisionRepository repository;
    private final AppUserRepository appUserRepository;

    public BankOfficeDecisionServiceImpl(BankOfficeDecisionRepository repository, AppUserRepository appUserRepository) {
        this.repository = repository;
        this.appUserRepository = appUserRepository;
    }

    @Override
    public BankOfficeDecisionDTO create(BankOfficeDecisionDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (repository.findByAppIdAndDeletedAtIsNull(dto.getAppId()).isPresent()) {
            throw new ValidationException("A bank office decision already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        BankOfficeDecision entity = toEntity(dto);
        entity.setDecisionId(null);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        return toDto(repository.save(entity));
    }

    @Override
    public BankOfficeDecisionDTO update(Long decisionId, BankOfficeDecisionDTO dto) {
        BankOfficeDecision existing = repository.findByDecisionIdAndDeletedAtIsNull(decisionId)
                .orElseThrow(() -> new ResourceNotFoundException("No bank office decision found with id " + decisionId + "."));
        dto.setAppId(dto.getAppId() != null ? dto.getAppId() : existing.getAppId());
        validate(dto);
        BankOfficeDecision entity = toEntity(dto);
        entity.setDecisionId(decisionId);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(Long decisionId) {
        return repository.findByDecisionIdAndDeletedAtIsNull(decisionId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(Long decisionId) {
        return repository.findById(decisionId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public BankOfficeDecisionDTO findById(Long decisionId) {
        return repository.findByDecisionIdAndDeletedAtIsNull(decisionId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public BankOfficeDecisionDTO findByAppId(String appId) {
        Validators.required(appId, "appId");
        return repository.findByAppIdAndDeletedAtIsNull(appId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BankOfficeDecisionDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(BankOfficeDecisionDTO dto) {
        Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        if (appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull(dto.getOfficerEmail()).isEmpty()) {
            throw new ValidationException("officerEmail " + dto.getOfficerEmail() + " is not a known active app_user.");
        }
        // US-EL-05: rejection or conditional approval must always be explained to the customer.
        if (!"APPROVED".equalsIgnoreCase(dto.getStatus())) {
            Validators.required(dto.getReason(), "reason");
        }
    }

    private BankOfficeDecision toEntity(BankOfficeDecisionDTO dto) {
        return BankOfficeDecision.builder()
                .decisionId(dto.getDecisionId())
                .appId(dto.getAppId())
                .status(dto.getStatus())
                .officerEmail(dto.getOfficerEmail())
                .decisionDate(dto.getDecisionDate())
                .reason(dto.getReason())
                .remarks(dto.getRemarks())
                .build();
    }

    private BankOfficeDecisionDTO toDto(BankOfficeDecision entity) {
        return BankOfficeDecisionDTO.builder()
                .decisionId(entity.getDecisionId())
                .appId(entity.getAppId())
                .status(entity.getStatus())
                .officerEmail(entity.getOfficerEmail())
                .decisionDate(entity.getDecisionDate())
                .reason(entity.getReason())
                .remarks(entity.getRemarks())
                .build();
    }
}
