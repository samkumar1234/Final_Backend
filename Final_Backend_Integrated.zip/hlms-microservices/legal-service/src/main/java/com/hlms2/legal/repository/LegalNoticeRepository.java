package com.hlms2.legal.repository;

import com.hlms2.legal.entity.LegalNotice;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LegalNoticeRepository extends JpaRepository<LegalNotice, String> {
    Optional<LegalNotice> findByNoticeIdAndDeletedAtIsNull(String noticeId);
    List<LegalNotice> findByDeletedAtIsNull();
}
