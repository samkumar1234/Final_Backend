package com.hlms2.legal.dto;

import java.time.LocalDate;

public class LegalNoticeDTO {
    private String noticeId;
    private String noticeNo;
    private String appId;
    private String noticeType;
    private LocalDate issueDate;
    private LocalDate dueDate;
    private String status;
    private String officerEmail;
    private String content;

    public LegalNoticeDTO() {
    }

    public LegalNoticeDTO(String noticeId, String noticeNo, String appId, String noticeType, LocalDate issueDate,
                           LocalDate dueDate, String status, String officerEmail, String content) {
        this.noticeId = noticeId;
        this.noticeNo = noticeNo;
        this.appId = appId;
        this.noticeType = noticeType;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.status = status;
        this.officerEmail = officerEmail;
        this.content = content;
    }

    public String getNoticeId() {
        return noticeId;
    }

    public void setNoticeId(String noticeId) {
        this.noticeId = noticeId;
    }

    public String getNoticeNo() {
        return noticeNo;
    }

    public void setNoticeNo(String noticeNo) {
        this.noticeNo = noticeNo;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getNoticeType() {
        return noticeType;
    }

    public void setNoticeType(String noticeType) {
        this.noticeType = noticeType;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String noticeId;
        private String noticeNo;
        private String appId;
        private String noticeType;
        private LocalDate issueDate;
        private LocalDate dueDate;
        private String status;
        private String officerEmail;
        private String content;

        public Builder noticeId(String noticeId) {
            this.noticeId = noticeId;
            return this;
        }

        public Builder noticeNo(String noticeNo) {
            this.noticeNo = noticeNo;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder noticeType(String noticeType) {
            this.noticeType = noticeType;
            return this;
        }

        public Builder issueDate(LocalDate issueDate) {
            this.issueDate = issueDate;
            return this;
        }

        public Builder dueDate(LocalDate dueDate) {
            this.dueDate = dueDate;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder officerEmail(String officerEmail) {
            this.officerEmail = officerEmail;
            return this;
        }

        public Builder content(String content) {
            this.content = content;
            return this;
        }

        public LegalNoticeDTO build() {
            return new LegalNoticeDTO(noticeId, noticeNo, appId, noticeType, issueDate, dueDate, status,
                    officerEmail, content);
        }
    }
}
