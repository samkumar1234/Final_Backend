package com.hlms2.legal;

import com.hlms2.legal.client.LoanServiceClient;
import com.hlms2.legal.dto.LegalVerificationDTO;
import com.hlms2.legal.entity.AppUser;
import com.hlms2.legal.entity.LegalVerification;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.LegalVerificationRepository;
import com.hlms2.legal.serviceimpl.LegalVerificationServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LegalVerificationServiceImplTest {

    @Mock
    private LegalVerificationRepository repository;

    @Mock
    private AppUserRepository appUserRepository;

    @Mock
    private LoanServiceClient loanServiceClient;

    @InjectMocks
    private LegalVerificationServiceImpl service;

    private LegalVerificationDTO validDto;

    @BeforeEach
    void setUp() {
        validDto = LegalVerificationDTO.builder()
                .appId("APP-1")
                .decision("PENDING")
                .officerEmail("legal@bank.com")
                .build();
    }

    private void stubActiveOfficer() {
        when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("legal@bank.com"))
                .thenReturn(Optional.of(AppUser.builder().email("legal@bank.com").active(true).build()));
    }

    private void stubSaveReturnsArgument() {
        when(repository.save(any(LegalVerification.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    // ---------- create() ----------

    @Test
    void create_success_defaultsInfoRequestedToFalse() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalVerificationDTO result = service.create(validDto);

        assertEquals(Boolean.FALSE, result.getInfoRequested());
        assertNotNull(result.getDecisionDate());
    }

    @Test
    void create_preservesInfoRequestedTrue_whenProvided() {
        validDto.setInfoRequested(Boolean.TRUE);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalVerificationDTO result = service.create(validDto);

        assertTrue(result.getInfoRequested());
    }

    @Test
    void create_setsVerificationIdToNull_evenIfDtoHadOne() {
        validDto.setVerificationId(123L);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        ArgumentCaptor<LegalVerification> captor = ArgumentCaptor.forClass(LegalVerification.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        service.create(validDto);

        assertNull(captor.getValue().getVerificationId());
    }

    @Test
    void create_preservesProvidedDecisionDate() {
        OffsetDateTime fixed = OffsetDateTime.parse("2026-02-02T09:00:00Z");
        validDto.setDecisionDate(fixed);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalVerificationDTO result = service.create(validDto);

        assertEquals(fixed, result.getDecisionDate());
    }

    @Test
    void create_remarksNotRequired_whenApproved() {
        validDto.setDecision("APPROVED");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        assertDoesNotThrow(() -> service.create(validDto));
    }

    @Test
    void create_rejected_withoutRemarks_throwsValidationException() {
        validDto.setDecision("REJECTED");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(validDto));
        assertTrue(ex.getMessage().contains("remarks"));
        verify(repository, never()).save(any());
    }

    @Test
    void create_rejected_withRemarks_succeeds() {
        validDto.setDecision("REJECTED");
        validDto.setRemarks("Signature mismatch");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalVerificationDTO result = service.create(validDto);

        assertEquals("Signature mismatch", result.getRemarks());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        validDto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(validDto));
        verifyNoInteractions(repository);
    }

    @Test
    void create_duplicateAppId_throwsValidationException() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1"))
                .thenReturn(Optional.of(new LegalVerification()));

        assertThrows(ValidationException.class, () -> service.create(validDto));
        verify(repository, never()).save(any());
    }

    @Test
    void create_invalidDecision_throwsValidationException() {
        validDto.setDecision("MAYBE");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_missingOfficerEmail_throwsValidationException() {
        validDto.setOfficerEmail(null);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_officerNotActive_throwsValidationException() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("legal@bank.com"))
                .thenReturn(Optional.empty());

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    // ---------- update() ----------

    @Test
    void update_success() {
        LegalVerification existing = LegalVerification.builder()
                .verificationId(7L).appId("APP-1").decision("PENDING").officerEmail("legal@bank.com").build();
        when(repository.findByVerificationIdAndDeletedAtIsNull(7L)).thenReturn(Optional.of(existing));
        stubActiveOfficer();
        ArgumentCaptor<LegalVerification> captor = ArgumentCaptor.forClass(LegalVerification.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        LegalVerificationDTO result = service.update(7L, validDto);

        assertEquals(7L, captor.getValue().getVerificationId());
        assertNotNull(result.getDecisionDate());
    }

    @Test
    void update_notFound_throwsResourceNotFoundException() {
        when(repository.findByVerificationIdAndDeletedAtIsNull(404L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.update(404L, validDto));
    }

    @Test
    void update_appIdDefaultsToExisting_whenDtoAppIdNull() {
        validDto.setAppId(null);
        LegalVerification existing = LegalVerification.builder()
                .verificationId(7L).appId("APP-EXISTING").decision("PENDING").officerEmail("legal@bank.com").build();
        when(repository.findByVerificationIdAndDeletedAtIsNull(7L)).thenReturn(Optional.of(existing));
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalVerificationDTO result = service.update(7L, validDto);

        assertEquals("APP-EXISTING", result.getAppId());
    }

    // ---------- softDelete() ----------

    @Test
    void softDelete_found_returnsTrue() {
        LegalVerification existing = LegalVerification.builder().verificationId(7L).build();
        when(repository.findByVerificationIdAndDeletedAtIsNull(7L)).thenReturn(Optional.of(existing));
        ArgumentCaptor<LegalVerification> captor = ArgumentCaptor.forClass(LegalVerification.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        assertTrue(service.softDelete(7L));
        assertNotNull(captor.getValue().getDeletedAt());
    }

    @Test
    void softDelete_notFound_returnsFalse() {
        when(repository.findByVerificationIdAndDeletedAtIsNull(999L)).thenReturn(Optional.empty());

        assertFalse(service.softDelete(999L));
    }

    // ---------- restore() ----------

    @Test
    void restore_foundAndDeleted_returnsTrue() {
        LegalVerification existing = LegalVerification.builder().verificationId(7L)
                .deletedAt(OffsetDateTime.now()).build();
        when(repository.findById(7L)).thenReturn(Optional.of(existing));
        ArgumentCaptor<LegalVerification> captor = ArgumentCaptor.forClass(LegalVerification.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        assertTrue(service.restore(7L));
        assertNull(captor.getValue().getDeletedAt());
    }

    @Test
    void restore_foundButNotDeleted_returnsFalse() {
        LegalVerification existing = LegalVerification.builder().verificationId(7L).deletedAt(null).build();
        when(repository.findById(7L)).thenReturn(Optional.of(existing));

        assertFalse(service.restore(7L));
    }

    @Test
    void restore_notFound_returnsFalse() {
        when(repository.findById(999L)).thenReturn(Optional.empty());

        assertFalse(service.restore(999L));
    }

    // ---------- findById() ----------

    @Test
    void findById_found_returnsDto() {
        when(repository.findByVerificationIdAndDeletedAtIsNull(7L))
                .thenReturn(Optional.of(LegalVerification.builder().verificationId(7L).appId("APP-1").build()));

        LegalVerificationDTO result = service.findById(7L);

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findById_notFound_returnsNull() {
        when(repository.findByVerificationIdAndDeletedAtIsNull(999L)).thenReturn(Optional.empty());

        assertNull(service.findById(999L));
    }

    // ---------- findByAppId() ----------

    @Test
    void findByAppId_missingAppId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.findByAppId(""));
    }

    @Test
    void findByAppId_found_returnsDto() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1"))
                .thenReturn(Optional.of(LegalVerification.builder().appId("APP-1").build()));

        assertNotNull(service.findByAppId("APP-1"));
    }

    @Test
    void findByAppId_notFound_returnsNull() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-404")).thenReturn(Optional.empty());

        assertNull(service.findByAppId("APP-404"));
    }

    // ---------- findAll() ----------

    @Test
    void findAll_returnsMappedList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of(
                LegalVerification.builder().appId("APP-1").build(),
                LegalVerification.builder().appId("APP-2").build()));

        assertEquals(2, service.findAll().size());
    }

    @Test
    void findAll_empty_returnsEmptyList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        assertTrue(service.findAll().isEmpty());
    }
}
