package com.tcs.hlms.service;

import com.tcs.hlms.entity.AuditLogEntity;

import java.util.List;

public interface AuditLogService {

    AuditLogEntity saveAuditLog(
            AuditLogEntity auditLog);

    AuditLogEntity getAuditLogById(
            Long logId);

    List<AuditLogEntity> getAllAuditLogs();

    void deleteAuditLog(Long logId);
}