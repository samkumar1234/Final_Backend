package com.tcs.hlms.controller;

import com.tcs.hlms.entity.ApplicationDocumentEntity;
import com.tcs.hlms.service.ApplicationDocumentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/application-documents")
public class ApplicationDocumentController {

    private final ApplicationDocumentService service;

    public ApplicationDocumentController(
            ApplicationDocumentService service) {
        this.service = service;
    }

    @PostMapping
    public ApplicationDocumentEntity saveDocument(
            @RequestBody ApplicationDocumentEntity document) {

        return service.saveDocument(document);
    }

    @GetMapping("/{documentId}")
    public ApplicationDocumentEntity getDocumentById(
            @PathVariable String documentId) {

        return service.getDocumentById(documentId);
    }

    @GetMapping("/app/{appId}")
    public List<ApplicationDocumentEntity> getDocumentsByAppId(
            @PathVariable String appId) {

        return service.getDocumentsByAppId(appId);
    }

    @GetMapping
    public List<ApplicationDocumentEntity> getAllDocuments() {
        return service.getAllDocuments();
    }

    @DeleteMapping("/{documentId}")
    public String deleteDocument(
            @PathVariable String documentId) {

        service.deleteDocument(documentId);
        return "Document deleted successfully";
    }
}