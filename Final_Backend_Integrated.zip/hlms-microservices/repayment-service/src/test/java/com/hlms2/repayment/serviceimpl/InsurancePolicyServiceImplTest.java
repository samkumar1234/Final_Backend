package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.InsurancePolicyDTO;
import com.hlms2.repayment.entity.InsurancePolicy;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.repository.InsurancePolicyRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InsurancePolicyServiceImplTest {

    @Mock
    private InsurancePolicyRepository repository;

    private InsurancePolicyServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new InsurancePolicyServiceImpl(repository);
    }

    private InsurancePolicyDTO validDto() {
        InsurancePolicyDTO dto = new InsurancePolicyDTO();
        dto.setAppId("APP-1");
        dto.setPolicyType("property");
        dto.setStatus("Active");
        dto.setValidTill(LocalDate.now().plusYears(1));
        return dto;
    }

    // ---------- create() ----------

    @Test
    void create_positive_generatesPolicyId() {
        InsurancePolicyDTO dto = validDto();
        when(repository.save(any(InsurancePolicy.class))).thenAnswer(inv -> inv.getArgument(0));

        InsurancePolicyDTO result = service.create(dto);

        assertThat(result.getPolicyId()).startsWith("POL-");
        assertThat(result.getStatus()).isEqualTo("Active");
    }

    @Test
    void create_edge_defaultsStatusToActiveWhenNull() {
        InsurancePolicyDTO dto = validDto();
        dto.setStatus(null);
        dto.setValidTill(null);
        when(repository.save(any(InsurancePolicy.class))).thenAnswer(inv -> inv.getArgument(0));

        assertThat(service.create(dto).getStatus()).isEqualTo("Active");
    }

    @Test
    void create_negative_missingAppId_throws() {
        InsurancePolicyDTO dto = validDto();
        dto.setAppId(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
        verifyNoInteractions(repository);
    }

    @Test
    void create_negative_invalidPolicyType_throws() {
        InsurancePolicyDTO dto = validDto();
        dto.setPolicyType("vehicle");

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_invalidStatus_throws() {
        InsurancePolicyDTO dto = validDto();
        dto.setStatus("Suspended");

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_activeWithPastValidTill_throws() {
        InsurancePolicyDTO dto = validDto();
        dto.setStatus("Active");
        dto.setValidTill(LocalDate.now().minusDays(1));

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("cannot have a validTill date in the past");
    }

    @Test
    void create_edge_expiredWithPastValidTill_allowed() {
        InsurancePolicyDTO dto = validDto();
        dto.setStatus("Expired");
        dto.setValidTill(LocalDate.now().minusDays(1));
        when(repository.save(any(InsurancePolicy.class))).thenAnswer(inv -> inv.getArgument(0));

        assertThat(service.create(dto).getStatus()).isEqualTo("Expired");
    }

    @Test
    void create_edge_lifePolicyTypeAccepted() {
        InsurancePolicyDTO dto = validDto();
        dto.setPolicyType("life");
        when(repository.save(any(InsurancePolicy.class))).thenAnswer(inv -> inv.getArgument(0));

        assertThat(service.create(dto).getPolicyType()).isEqualTo("life");
    }

    // ---------- update() ----------

    @Test
    void update_positive_updatesExisting() {
        InsurancePolicyDTO dto = validDto();
        dto.setPolicyId("POL-1");
        InsurancePolicy existing = InsurancePolicy.builder().policyId("POL-1").appId("APP-1").policyType("property").status("Active").build();
        when(repository.findByPolicyIdAndDeletedAtIsNull("POL-1")).thenReturn(Optional.of(existing));
        when(repository.save(any(InsurancePolicy.class))).thenAnswer(inv -> inv.getArgument(0));

        assertThat(service.update(dto)).isNotNull();
    }

    @Test
    void update_negative_missingPolicyId_throws() {
        assertThatThrownBy(() -> service.update(validDto())).isInstanceOf(ValidationException.class);
    }

    @Test
    void update_negative_notFound_throws() {
        InsurancePolicyDTO dto = validDto();
        dto.setPolicyId("POL-404");
        when(repository.findByPolicyIdAndDeletedAtIsNull("POL-404")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(dto)).isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- softDelete() / restore() ----------

    @Test
    void softDelete_positive_returnsTrue() {
        InsurancePolicy existing = InsurancePolicy.builder().policyId("POL-1").appId("APP-1").build();
        when(repository.findByPolicyIdAndDeletedAtIsNull("POL-1")).thenReturn(Optional.of(existing));

        assertThat(service.softDelete("POL-1")).isTrue();
        assertThat(existing.getDeletedAt()).isNotNull();
    }

    @Test
    void softDelete_negative_notFound_returnsFalse() {
        when(repository.findByPolicyIdAndDeletedAtIsNull("POL-404")).thenReturn(Optional.empty());

        assertThat(service.softDelete("POL-404")).isFalse();
    }

    @Test
    void restore_positive_returnsTrue() {
        InsurancePolicy existing = InsurancePolicy.builder().policyId("POL-1").appId("APP-1")
                .deletedAt(OffsetDateTime.now()).build();
        when(repository.findById("POL-1")).thenReturn(Optional.of(existing));

        assertThat(service.restore("POL-1")).isTrue();
    }

    @Test
    void restore_edge_notDeleted_returnsFalse() {
        InsurancePolicy existing = InsurancePolicy.builder().policyId("POL-1").appId("APP-1").build();
        when(repository.findById("POL-1")).thenReturn(Optional.of(existing));

        assertThat(service.restore("POL-1")).isFalse();
    }

    // ---------- findById() / findAll() ----------

    @Test
    void findById_negative_missingPolicyId_throws() {
        assertThatThrownBy(() -> service.findById(null)).isInstanceOf(ValidationException.class);
    }

    @Test
    void findById_positive_returnsDto() {
        InsurancePolicy existing = InsurancePolicy.builder().policyId("POL-1").appId("APP-1").build();
        when(repository.findByPolicyIdAndDeletedAtIsNull("POL-1")).thenReturn(Optional.of(existing));

        assertThat(service.findById("POL-1")).isNotNull();
    }

    @Test
    void findAll_edge_empty() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        assertThat(service.findAll()).isEmpty();
    }

    @Test
    void findAll_positive_mapsEntities() {
        InsurancePolicy existing = InsurancePolicy.builder().policyId("POL-1").appId("APP-1").build();
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of(existing));

        assertThat(service.findAll()).hasSize(1);
    }
}
