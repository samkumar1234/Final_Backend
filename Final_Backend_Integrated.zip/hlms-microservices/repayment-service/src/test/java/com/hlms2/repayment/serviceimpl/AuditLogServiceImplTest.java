package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.AuditLogDTO;
import com.hlms2.repayment.entity.AppUser;
import com.hlms2.repayment.entity.AuditLog;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.repository.AppUserRepository;
import com.hlms2.repayment.repository.AuditLogRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuditLogServiceImplTest {

    @Mock
    private AuditLogRepository repository;
    @Mock
    private AppUserRepository appUserRepository;

    private AuditLogServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new AuditLogServiceImpl(repository, appUserRepository);
    }

    private AuditLogDTO validDto() {
        AuditLogDTO dto = new AuditLogDTO();
        dto.setEntityType("EMI_INSTALLMENT");
        dto.setEntityId("EMI-1");
        dto.setAction("CREATE");
        dto.setActorEmail("officer@bank.com");
        return dto;
    }

    private AppUser activeUser() {
        AppUser user = new AppUser();
        user.setEmail("officer@bank.com");
        user.setActive(true);
        return user;
    }

    // ---------- create() ----------

    @Test
    void create_positive_savesAndReturnsDto() {
        AuditLogDTO dto = validDto();
        when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("officer@bank.com"))
                .thenReturn(Optional.of(activeUser()));
        when(repository.save(any(AuditLog.class))).thenAnswer(inv -> {
            AuditLog e = inv.getArgument(0);
            e.setLogId(1L);
            return e;
        });

        AuditLogDTO result = service.create(dto);

        assertThat(result.getLogId()).isEqualTo(1L);
        assertThat(result.getCreatedAt()).isNotNull();
    }

    @Test
    void create_negative_missingEntityType_throws() {
        AuditLogDTO dto = validDto();
        dto.setEntityType(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
        verifyNoInteractions(repository);
    }

    @Test
    void create_negative_missingEntityId_throws() {
        AuditLogDTO dto = validDto();
        dto.setEntityId(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_invalidAction_throws() {
        AuditLogDTO dto = validDto();
        dto.setAction("DESTROY");

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_missingActorEmail_throws() {
        AuditLogDTO dto = validDto();
        dto.setActorEmail(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_actorNotActiveUser_throws() {
        AuditLogDTO dto = validDto();
        when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("officer@bank.com"))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("not a known active app_user");
        verify(repository, never()).save(any());
    }

    @Test
    void create_edge_allValidActionValues_areAccepted() {
        for (String action : List.of("CREATE", "UPDATE", "DELETE", "APPROVE", "REJECT", "LOGIN", "LOGOUT")) {
            AuditLogDTO dto = validDto();
            dto.setAction(action);
            when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("officer@bank.com"))
                    .thenReturn(Optional.of(activeUser()));
            when(repository.save(any(AuditLog.class))).thenAnswer(inv -> inv.getArgument(0));

            AuditLogDTO result = service.create(dto);

            assertThat(result.getAction()).isEqualTo(action);
        }
    }

    @Test
    void create_edge_actionIsCaseInsensitive() {
        AuditLogDTO dto = validDto();
        dto.setAction("create");
        when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("officer@bank.com"))
                .thenReturn(Optional.of(activeUser()));
        when(repository.save(any(AuditLog.class))).thenAnswer(inv -> inv.getArgument(0));

        assertThat(service.create(dto)).isNotNull();
    }

    // ---------- delete() ----------

    @Test
    void delete_positive_returnsTrue() {
        when(repository.existsById(1L)).thenReturn(true);

        assertThat(service.delete(1L)).isTrue();
        verify(repository).deleteById(1L);
    }

    @Test
    void delete_negative_notFound_returnsFalse() {
        when(repository.existsById(404L)).thenReturn(false);

        assertThat(service.delete(404L)).isFalse();
        verify(repository, never()).deleteById(any());
    }

    @Test
    void delete_negative_missingLogId_throws() {
        assertThatThrownBy(() -> service.delete(null)).isInstanceOf(ValidationException.class);
    }

    // ---------- findById() / findAll() ----------

    @Test
    void findById_positive_returnsDto() {
        AuditLog log = AuditLog.builder().logId(1L).entityType("EMI").entityId("1").action("CREATE").build();
        when(repository.findById(1L)).thenReturn(Optional.of(log));

        assertThat(service.findById(1L)).isNotNull();
    }

    @Test
    void findById_negative_notFound_returnsNull() {
        when(repository.findById(404L)).thenReturn(Optional.empty());

        assertThat(service.findById(404L)).isNull();
    }

    @Test
    void findById_negative_missingLogId_throws() {
        assertThatThrownBy(() -> service.findById(null)).isInstanceOf(ValidationException.class);
    }

    @Test
    void findAll_edge_empty() {
        when(repository.findAll()).thenReturn(List.of());

        assertThat(service.findAll()).isEmpty();
    }

    @Test
    void findAll_positive_mapsEntries() {
        AuditLog log = AuditLog.builder().logId(1L).entityType("EMI").entityId("1").action("CREATE").build();
        when(repository.findAll()).thenReturn(List.of(log));

        assertThat(service.findAll()).hasSize(1);
    }
}
