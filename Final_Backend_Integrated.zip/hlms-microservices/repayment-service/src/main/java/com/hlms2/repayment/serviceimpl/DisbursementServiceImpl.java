package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.client.LoanServiceClient;
import com.hlms2.repayment.dto.DisbursementDTO;
import com.hlms2.repayment.entity.Disbursement;
import com.hlms2.repayment.entity.LoanApplication;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.DisbursementRepository;
import com.hlms2.repayment.repository.LoanApplicationRepository;
import com.hlms2.repayment.service.DisbursementService;
import com.hlms2.repayment.service.EmiInstallmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

/**
 * Ported from hlms2.serviceimpl.DisbursementServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql:
 *
 * - disbursement_id is now the surrogate PK; app_id is a unique lookup
 *   column (create() checks uniqueness on app_id, update()/findById key
 *   off disbursement_id).
 * - delete is now a soft delete (sets deleted_at), with a matching
 *   restore().
 *
 * Business logic unchanged: a loan can only be disbursed once, the
 * amount/mode/reference must be well formed, and the disbursed date can
 * never be in the future.
 */
@Service
@Transactional
public class DisbursementServiceImpl implements DisbursementService {

    private static final Logger log = LoggerFactory.getLogger(DisbursementServiceImpl.class);
    private static final List<String> VALID_MODES = List.of("NEFT", "RTGS", "CHEQUE", "UPI");

    private final DisbursementRepository repository;
    private final LoanServiceClient loanServiceClient;
    private final LoanApplicationRepository loanApplicationRepository;
    private final EmiInstallmentService emiInstallmentService;

    public DisbursementServiceImpl(DisbursementRepository repository, LoanServiceClient loanServiceClient,
                                    LoanApplicationRepository loanApplicationRepository,
                                    EmiInstallmentService emiInstallmentService) {
        this.repository = repository;
        this.loanServiceClient = loanServiceClient;
        this.loanApplicationRepository = loanApplicationRepository;
        this.emiInstallmentService = emiInstallmentService;
    }

    @Override
    public DisbursementDTO create(DisbursementDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (repository.findByAppIdAndDeletedAtIsNull(dto.getAppId()).isPresent()) {
            throw new ValidationException("A disbursement already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        Disbursement entity = toEntity(dto);
        entity.setDisbursementId(null);
        entity.setDisbursedDate(entity.getDisbursedDate() == null ? OffsetDateTime.now() : entity.getDisbursedDate());
        Disbursement saved = repository.save(entity);
        // Recording a disbursement is the terminal step of the loan workflow -
        // push loan-service's status forward via Eureka + Feign to reflect that.
        notifyLoanService(saved.getAppId());
        // US-DSB-02: disbursing the loan is what triggers generation of the
        // full EMI repayment schedule, so the customer can immediately see
        // it against their loan.
        generateEmiSchedule(saved);
        return toDto(saved);
    }

    private void generateEmiSchedule(Disbursement disbursement) {
        try {
            LoanApplication loanApplication = loanApplicationRepository
                    .findByAppIdAndDeletedAtIsNull(disbursement.getAppId())
                    .orElse(null);
            if (loanApplication == null) {
                log.warn("Could not generate EMI schedule for {}: loan application not found.", disbursement.getAppId());
                return;
            }
            BigDecimal principal = disbursement.getAmount() != null ? disbursement.getAmount() : loanApplication.getLoanAmount();
            Integer tenureYears = loanApplication.getTenureYears();
            if (principal == null || tenureYears == null) {
                log.warn("Could not generate EMI schedule for {}: missing principal/tenure.", disbursement.getAppId());
                return;
            }
            OffsetDateTime disbursedDate = disbursement.getDisbursedDate() != null ? disbursement.getDisbursedDate() : OffsetDateTime.now();
            // First EMI falls due one month after the funds are disbursed.
            emiInstallmentService.generateSchedule(
                    disbursement.getAppId(),
                    principal,
                    loanApplication.getInterestRate(),
                    tenureYears,
                    disbursedDate.toLocalDate().plusMonths(1));
        } catch (Exception ex) {
            log.warn("EMI schedule generation failed for {}: {}", disbursement.getAppId(), ex.getMessage());
        }
    }

    private void notifyLoanService(String appId) {
        if (loanServiceClient == null || appId == null) {
            return;
        }
        try {
            loanServiceClient.updateLoanStage(appId, Map.of("stageIndex", 5, "status", "Disbursed"));
        } catch (Exception ex) {
            log.warn("Could not push disbursement status for {} to loan-service: {}", appId, ex.getMessage());
        }
    }

    @Override
    public DisbursementDTO update(Long disbursementId, DisbursementDTO dto) {
        Disbursement existing = repository.findByDisbursementIdAndDeletedAtIsNull(disbursementId)
                .orElseThrow(() -> new ResourceNotFoundException("No disbursement found with id " + disbursementId + "."));
        dto.setAppId(dto.getAppId() != null ? dto.getAppId() : existing.getAppId());
        validate(dto);
        Disbursement entity = toEntity(dto);
        entity.setDisbursementId(disbursementId);
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(Long disbursementId) {
        return repository.findByDisbursementIdAndDeletedAtIsNull(disbursementId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(Long disbursementId) {
        return repository.findById(disbursementId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public DisbursementDTO findById(Long disbursementId) {
        return repository.findByDisbursementIdAndDeletedAtIsNull(disbursementId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public DisbursementDTO findByAppId(String appId) {
        Validators.required(appId, "appId");
        return repository.findByAppIdAndDeletedAtIsNull(appId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DisbursementDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(DisbursementDTO dto) {
        Validators.positive(dto.getAmount(), "amount");
        Validators.required(dto.getRefNo(), "refNo");
        Validators.oneOf(dto.getMode(), "mode", VALID_MODES.toArray(new String[0]));
        Validators.required(dto.getBankDetails(), "bankDetails");
        if (dto.getDisbursedDate() != null && dto.getDisbursedDate().isAfter(OffsetDateTime.now())) {
            throw new ValidationException("disbursedDate cannot be in the future.");
        }
    }

    private Disbursement toEntity(DisbursementDTO dto) {
        return Disbursement.builder()
                .disbursementId(dto.getDisbursementId())
                .appId(dto.getAppId())
                .disbursedDate(dto.getDisbursedDate())
                .amount(dto.getAmount())
                .refNo(dto.getRefNo())
                .mode(dto.getMode())
                .bankDetails(dto.getBankDetails())
                .build();
    }

    private DisbursementDTO toDto(Disbursement entity) {
        return DisbursementDTO.builder()
                .disbursementId(entity.getDisbursementId())
                .appId(entity.getAppId())
                .disbursedDate(entity.getDisbursedDate())
                .amount(entity.getAmount())
                .refNo(entity.getRefNo())
                .mode(entity.getMode())
                .bankDetails(entity.getBankDetails())
                .build();
    }
}
