package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.BidDTO;

import java.util.List;

public interface BidService {
    BidDTO create(BidDTO dto);
    BidDTO update(BidDTO dto);
    boolean softDelete(String bidId);
    boolean restore(String bidId);
    BidDTO findById(String bidId);
    List<BidDTO> findAll();
}
