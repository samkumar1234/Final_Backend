package com.hlms2.repayment.controller;

import com.hlms2.repayment.dto.AuditLogDTO;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.service.AuditLogService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** No PUT here on purpose - audit log entries are immutable once created. */
@RestController
@RequestMapping("/api/audit-log")
public class AuditLogController {

    private final AuditLogService service;

    public AuditLogController(AuditLogService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<AuditLogDTO> create(@RequestBody AuditLogDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @DeleteMapping("/{logId}")
    public ResponseEntity<Void> delete(@PathVariable Long logId) {
        return service.delete(logId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{logId}")
    public AuditLogDTO findById(@PathVariable Long logId) {
        AuditLogDTO dto = service.findById(logId);
        if (dto == null) {
            throw new ResourceNotFoundException("Audit log entry " + logId + " does not exist.");
        }
        return dto;
    }

    @GetMapping
    public List<AuditLogDTO> findAll() {
        return service.findAll();
    }
}
