package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.LoanApplication;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LoanApplicationRepository extends JpaRepository<LoanApplication, String> {
    Optional<LoanApplication> findByAppIdAndDeletedAtIsNull(String appId);
}
