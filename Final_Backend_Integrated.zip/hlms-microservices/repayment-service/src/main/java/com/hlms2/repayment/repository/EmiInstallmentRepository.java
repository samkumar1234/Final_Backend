package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.EmiInstallment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmiInstallmentRepository extends JpaRepository<EmiInstallment, String> {
    Optional<EmiInstallment> findByInstallmentIdAndDeletedAtIsNull(String installmentId);
    List<EmiInstallment> findByDeletedAtIsNull();
    List<EmiInstallment> findByAppIdAndDeletedAtIsNull(String appId);
}
