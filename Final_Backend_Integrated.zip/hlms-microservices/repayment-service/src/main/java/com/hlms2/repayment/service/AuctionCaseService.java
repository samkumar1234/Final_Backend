package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.AuctionCaseDTO;

import java.util.List;

public interface AuctionCaseService {
    AuctionCaseDTO create(AuctionCaseDTO dto);
    AuctionCaseDTO update(Long auctionId, AuctionCaseDTO dto);
    boolean softDelete(Long auctionId);
    boolean restore(Long auctionId);
    AuctionCaseDTO findById(Long auctionId);
    AuctionCaseDTO findByAppId(String appId);
    List<AuctionCaseDTO> findAll();
}
