package com.hlms2.repayment.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Declarative REST client for loan-service, resolved via Eureka using
 * loan-service's spring.application.name.
 */
@FeignClient(name = "loan-service", configuration = FeignAuthConfig.class)
public interface LoanServiceClient {

    @GetMapping("/api/loan-applications/{appId}")
    Map<String, Object> getLoanApplication(@PathVariable("appId") String appId);

    @PatchMapping("/api/loan-applications/{appId}/stage")
    Map<String, Object> updateLoanStage(@PathVariable("appId") String appId, @RequestBody Map<String, Object> body);
}
