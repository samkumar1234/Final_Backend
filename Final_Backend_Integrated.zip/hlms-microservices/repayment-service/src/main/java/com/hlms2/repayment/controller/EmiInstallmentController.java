package com.hlms2.repayment.controller;

import com.hlms2.repayment.dto.EmiInstallmentDTO;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.service.EmiInstallmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/emi")
public class EmiInstallmentController {

    private final EmiInstallmentService service;

    public EmiInstallmentController(EmiInstallmentService service) {
        this.service = service;
    }

    @PostMapping("/installments")
    public ResponseEntity<EmiInstallmentDTO> create(@RequestBody EmiInstallmentDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/installments/{installmentId}")
    public EmiInstallmentDTO update(@PathVariable String installmentId, @RequestBody EmiInstallmentDTO dto) {
        dto.setInstallmentId(installmentId);
        return service.update(dto);
    }

    @DeleteMapping("/installments/{installmentId}")
    public ResponseEntity<Void> softDelete(@PathVariable String installmentId) {
        return service.softDelete(installmentId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/installments/{installmentId}/restore")
    public ResponseEntity<Void> restore(@PathVariable String installmentId) {
        return service.restore(installmentId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/installments/{installmentId}")
    public EmiInstallmentDTO findById(@PathVariable String installmentId) {
        EmiInstallmentDTO dto = service.findById(installmentId);
        if (dto == null) {
            throw new ResourceNotFoundException("EMI installment " + installmentId + " does not exist.");
        }
        return dto;
    }

    @GetMapping("/installments")
    public List<EmiInstallmentDTO> findAll() {
        return service.findAll();
    }

    @GetMapping("/{appId}/schedule")
    public List<EmiInstallmentDTO> getPaymentHistory(@PathVariable String appId) {
        return service.getPaymentHistory(appId);
    }
}
