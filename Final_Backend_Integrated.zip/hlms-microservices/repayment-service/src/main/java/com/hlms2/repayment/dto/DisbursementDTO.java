package com.hlms2.repayment.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public class DisbursementDTO {
    private Long disbursementId;
    private String appId;
    private OffsetDateTime disbursedDate;
    private BigDecimal amount;
    private String refNo;
    private String mode;
    private String bankDetails;

    public DisbursementDTO() {
    }

    public DisbursementDTO(Long disbursementId, String appId, OffsetDateTime disbursedDate, BigDecimal amount, String refNo, String mode, String bankDetails) {
        this.disbursementId = disbursementId;
        this.appId = appId;
        this.disbursedDate = disbursedDate;
        this.amount = amount;
        this.refNo = refNo;
        this.mode = mode;
        this.bankDetails = bankDetails;
    }

    public Long getDisbursementId() {
        return disbursementId;
    }
    public void setDisbursementId(Long disbursementId) {
        this.disbursementId = disbursementId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public OffsetDateTime getDisbursedDate() {
        return disbursedDate;
    }
    public void setDisbursedDate(OffsetDateTime disbursedDate) {
        this.disbursedDate = disbursedDate;
    }
    public BigDecimal getAmount() {
        return amount;
    }
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    public String getRefNo() {
        return refNo;
    }
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    public String getMode() {
        return mode;
    }
    public void setMode(String mode) {
        this.mode = mode;
    }
    public String getBankDetails() {
        return bankDetails;
    }
    public void setBankDetails(String bankDetails) {
        this.bankDetails = bankDetails;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long disbursementId;
        private String appId;
        private OffsetDateTime disbursedDate;
        private BigDecimal amount;
        private String refNo;
        private String mode;
        private String bankDetails;

        public Builder disbursementId(Long disbursementId) {
            this.disbursementId = disbursementId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder disbursedDate(OffsetDateTime disbursedDate) {
            this.disbursedDate = disbursedDate;
            return this;
        }
        public Builder amount(BigDecimal amount) {
            this.amount = amount;
            return this;
        }
        public Builder refNo(String refNo) {
            this.refNo = refNo;
            return this;
        }
        public Builder mode(String mode) {
            this.mode = mode;
            return this;
        }
        public Builder bankDetails(String bankDetails) {
            this.bankDetails = bankDetails;
            return this;
        }

        public DisbursementDTO build() {
            return new DisbursementDTO(disbursementId, appId, disbursedDate, amount, refNo, mode, bankDetails);
        }
    }
}
