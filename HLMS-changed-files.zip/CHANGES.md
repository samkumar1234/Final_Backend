# HLMS — construction disbursement: customer tracking view + balance-release fix

Copy each file over the same path in your `HLMS/` tree. Nothing else changes.

---

## 1. The balance-release error

**What you saw:** `This operation violates a database constraint (duplicate or invalid reference).`
That string is produced by exactly one place — `GlobalExceptionHandler.handleDataIntegrity`
in repayment-service, which catches `DataIntegrityViolationException` and returns 409.

**Root cause:** `emi_installment` carries `UNIQUE (app_id, installment_no)` across the
**whole table** — `deleted_at` is not part of the constraint.

Sequence that broke:

1. Officer disburses tranche 1 → `generateSchedule()` inserts installments `#1..#240`.
2. Officer clicks **Release Balance** → `releaseBalance()` → `regenerateSchedule()`.
3. `regenerateSchedule()` **soft-deleted** the old rows (set `deleted_at`) and then inserted a
   fresh `#1..#240`.
4. The soft-deleted rows still hold `(app_id, 1)`, `(app_id, 2)`, … so the first insert of the
   new schedule hits the unique key → Postgres duplicate key → 409 → red toast.

The disbursement row itself was fine; the collision was always in the EMI rebuild.

**Fix** — `EmiInstallmentServiceImpl.regenerateSchedule()` now:

- loads **every** row for the application via the new `findByAppId()` (live *and* rows a previous
  rebuild already soft-deleted — those were the hidden landmines),
- refuses the rebuild if any installment was ever `PAID` (unchanged guard, now covering
  soft-deleted rows too),
- **hard-deletes** the superseded rows and `flush()`es before the new inserts go out, so
  Hibernate can't order an INSERT ahead of the DELETEs,
- logs a one-line summary of what it discarded, since the soft-delete audit trail goes away.

`GlobalExceptionHandler` now also logs the **root cause** of any constraint violation
server-side. The browser message stays generic on purpose (no table/constraint names leaked),
but next time you get a 409 the real Postgres error will be in the repayment-service log.

### If you'd rather keep the soft-deleted rows for audit

Run this once instead, and the original soft-delete code would also have worked — the
constraint becomes "unique among *live* rows only":

```sql
ALTER TABLE emi_installment DROP CONSTRAINT IF EXISTS emi_installment_app_id_installment_no_key;
CREATE UNIQUE INDEX emi_installment_live_uq
  ON emi_installment (app_id, installment_no)
  WHERE deleted_at IS NULL;
```

The Java fix above works **without** this migration, so pick one. Doing both is harmless.

---

## 2. New column: `first_tranche_amount`

`releaseBalance()` overwrites `disbursed_amount` with the full sanctioned amount, so after the
balance lands the tranche 1 / tranche 2 split is unrecoverable — and the customer's phase table
would have nothing to show. One nullable column fixes it:

- set when the disbursement row is first written (`applyTrancheState`),
- backfilled inside `releaseBalance()` for rows created before this change,
- exposed on `DisbursementDTO`.

`ddl-auto=update` adds the column on next boot. No manual SQL needed. Existing rows stay `null`
and the UI falls back gracefully.

---

## 3. Customer tracking — "Construction Disbursement Progress"

New card on `/customer/tracking/:appId`, between the application summary and "Currently With":

- Approved Loan / Amount Released / Remaining Amount / Progress %, plus a progress bar
- phase table: Phase, Construction Stage, Phase Amount, Released, Engineer Status,
  Phase Status, Disbursed At
- the exact reason the balance is on hold, pulled live from `GET
  /api/disbursements/by-application/{appId}/balance-eligibility` (read-only — same endpoint the
  officer screen uses)
- an **Upload Engineer's Sign →** button routing to `/customer/postdisb/:appId` when that's what
  is blocking the release

The card only renders for staged loans (construction product, `PARTIAL` type, a pending amount,
or a completed balance release). Normal loans see the page exactly as before.

### One difference from your mock-up — read this

Your screenshot shows **four** equal phases (Foundation / Structure / Roofing / Final
Finishing, ₹750,000 each). Your backend does not have four phases. The design you approved
stores **one disbursement row with two tranches**: an initial credit, and a balance released
after the engineer's sign is verified. Your own second screenshot shows that — ₹2,100,000
credited, ₹900,000 pending, a 70/30 split, not 4×25%.

So the table renders the two phases that genuinely exist, with real numbers:

| # | Construction Stage | Source |
|---|---|---|
| 1 | Initial Release — on sanction | `firstTrancheAmount`, `disbursedDate` |
| 2 | Balance Release — after engineer's sign | `sanctioned − firstTranche`, `balanceReleasedDate`, engineer status from balance-eligibility |

Layout, columns, badges and wording match your mock; only the row count follows the data.

Real 4-stage staged disbursement (foundation → structure → roofing → finishing, each
individually requested, engineer-verified and released) is a different feature: a
`disbursement_phase` child table, phase request/verify endpoints, an officer screen that
releases per phase, and EMI generation deferred until the final phase. That's a schema change
plus new endpoints on three services. Say the word and I'll spec it before writing any of it —
I'm not going to quietly fake four rows out of two tranches in the meantime.

---

## Testing it

1. Restart repayment-service (picks up the new column and the fix).
2. `npm start` in `Frontend/`.
3. Existing app **TRK-20260817-42DD53** already has a stuck balance — as Mohan, hit
   **Release Balance** on the verified row. It should now credit ₹900,000, rebuild the EMI
   schedule on the full ₹3,000,000, and flip the loan to `Disbursed`.
4. Log in as siva → Track Application → open the app. Progress reads 100%, phase #2 shows
   `VERIFIED` / `DISBURSED` with the release timestamp.
5. To see the mid-flight state, disburse a fresh construction loan partially: progress bar sits
   at the partial %, phase #2 shows `NOT UPLOADED` / `NOT_STARTED` and the upload button appears.

---

## 4. Notification bell dropdown — all five portals

The bell now opens an in-place dropdown listing notifications (newest first),
in **customer, bank officer, admin, bidder and legal**. Click a notification to
mark it read; "Mark all as read" clears the badge in one go; clicking anywhere
outside closes the panel.

Backend needed no changes — `GET /api/notifications`, `GET /api/notifications/unread`
and `PATCH /api/notifications/{id}/read` already existed, and `listForUser`
already sorts newest-first server-side.

### Two real bugs found on the way

**1. `isRead` vs `read`.** The entity's getter is `isRead()` with no "get"
prefix, so Jackson serializes the field as **`read`**, not `isRead`. The
customer and legal models both declared `isRead`, which meant every read/unread
check silently evaluated `undefined` — the "New" badge and the dimming of read
items never worked. Fixed in `customer/core/models/models.ts`,
`legal/core/models/models.ts` and `customer/features/support/support.html`.

**2. `notificationId` typed as `number` in bank office.** The backend PK is a
`String` (e.g. `NOTIF-1A2B3C4D`). Nothing called `markRead` yet, so it hadn't
blown up — it would have the moment the dropdown was wired. Fixed in
`bankoffice/core/models/notification.model.ts`.

### Per-portal state

| Portal | Before | Now |
|---|---|---|
| Customer | bell **navigated away** to the Support page | dropdown, plus "View All →" to Support |
| Bank officer | bell had an empty `openNotifications()` stub | dropdown |
| Admin | bell was **hard-coded `0`**, no service at all | new model + service + dropdown |
| Legal | **no bell at all** | bell + dropdown |
| Bidder | working dropdown already | kept, + "Mark all as read", moved to shared CSS |

New shared classes `.notif-backdrop` / `.notif-panel` in `styles.css` so all
five panels are positioned and styled identically instead of each one
hand-rolling inline CSS. Every portal's service now exposes the same
`notifications` / `unreadCount` signals, `loadForUser()`, `markRead()` and
`markAllRead()`.

`markAllRead()` loops one PATCH per unread item because the backend has no bulk
endpoint. Fine for realistic volumes; if a user ever accumulates hundreds it's
worth adding `PATCH /api/notifications/read-all`.

Legal's shell loads the bell via an `effect()` watching `auth.currentUser()`,
because `restoreSession()` populates the user asynchronously — on a page
refresh the email is still null at construction time.

### Read this before you demo it

**Staff bells will be empty.** Every `send()` call in the codebase targets
`app.userEmail` — the customer. Nothing anywhere creates a notification
addressed to a bank officer, admin, legal officer or bidder, so their panels
will correctly render "No notifications yet" forever. The plumbing is done and
verified; there is simply nothing being sent to staff.

If you want staff to actually receive notifications, that's a separate change —
deciding *which* events notify *which* role (e.g. notify Legal when a customer
uploads an engineer's sign; notify the officer when Legal verifies one), then
resolving that role's email(s) via user-service. Say the word and I'll spec the
event→role matrix before writing it.

The customer Support page keeps its own local copy of the list, so marking
something read in the dropdown won't grey it out on that page until you
navigate back to it. Cosmetic; tell me if you want them sharing one source.
