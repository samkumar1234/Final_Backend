import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, forkJoin, of, tap } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { NotificationDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private base = `${environment.apiBase}/notification-service/api/notifications`;

  // ---- topbar bell state ----
  readonly notifications = signal<NotificationDTO[]>([]);
  readonly unreadCount = signal(0);

  constructor(private http: HttpClient) {}

  /** Sends an in-app/email/sms notification to a user (e.g. the borrower) about a legal action. */
  send(userEmail: string, title: string, body: string, channels: string[] = ['inapp']): Observable<NotificationDTO | null> {
    return this.http.post<NotificationDTO>(this.base, { userEmail, title, body, channels }).pipe(
      catchError(() => of(null))
    );
  }

  /**
   * Loads this legal officer's own notifications for the bell dropdown.
   * Backend already returns them newest-first.
   */
  loadForUser(userEmail: string): Observable<NotificationDTO[]> {
    return this.http.get<NotificationDTO[]>(this.base, { params: { userEmail } }).pipe(
      tap((list) => {
        this.notifications.set(list || []);
        this.unreadCount.set((list || []).filter((n) => !n.read).length);
      })
    );
  }

  /** NotificationController exposes this as PATCH, not PUT. */
  markRead(notificationId: string): Observable<NotificationDTO> {
    return this.http
      .patch<NotificationDTO>(`${this.base}/${encodeURIComponent(notificationId)}/read`, {})
      .pipe(
        tap((updated) => {
          this.notifications.update((list) =>
            list.map((n) => (n.notificationId === updated.notificationId ? updated : n))
          );
          this.unreadCount.update((c) => Math.max(0, c - 1));
        })
      );
  }

  /** No bulk-read endpoint exists, so this fires one PATCH per unread notification. */
  markAllRead(): Observable<NotificationDTO[]> {
    const unread = this.notifications().filter((n) => !n.read && n.notificationId);
    if (unread.length === 0) {
      return of([]);
    }
    return forkJoin(unread.map((n) => this.markRead(n.notificationId!)));
  }
}
