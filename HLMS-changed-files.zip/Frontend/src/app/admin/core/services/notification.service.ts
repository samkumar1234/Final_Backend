import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, of, tap } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { Notification } from '../models/notification.model';

/** notification-service's NotificationController, for the topbar bell. */
@Injectable({ providedIn: 'root' })
export class NotificationService {
  private http = inject(HttpClient);
  private readonly url = `${environment.apiBaseUrl}${environment.services.notification}/api/notifications`;

  readonly notifications = signal<Notification[]>([]);
  readonly unreadCount = signal(0);

  /** Backend already returns newest-first, so no client-side sorting needed. */
  loadForUser(userEmail: string): Observable<Notification[]> {
    return this.http.get<Notification[]>(this.url, { params: { userEmail } }).pipe(
      tap((list) => {
        this.notifications.set(list || []);
        this.unreadCount.set((list || []).filter((n) => !n.read).length);
      })
    );
  }

  /** NotificationController exposes this as PATCH, not PUT. */
  markRead(notificationId: string): Observable<Notification> {
    return this.http
      .patch<Notification>(`${this.url}/${encodeURIComponent(notificationId)}/read`, {})
      .pipe(
        tap((updated) => {
          this.notifications.update((list) =>
            list.map((n) => (n.notificationId === updated.notificationId ? updated : n))
          );
          this.unreadCount.update((c) => Math.max(0, c - 1));
        })
      );
  }

  /** No bulk-read endpoint exists, so this fires one PATCH per unread notification. */
  markAllRead(): Observable<Notification[]> {
    const unread = this.notifications().filter((n) => !n.read && n.notificationId);
    if (unread.length === 0) {
      return of([]);
    }
    return forkJoin(unread.map((n) => this.markRead(n.notificationId!)));
  }
}
