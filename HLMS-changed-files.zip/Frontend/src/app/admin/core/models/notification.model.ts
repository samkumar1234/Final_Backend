/**
 * Mirrors notification-service's Notification entity.
 *
 * NOTE on `read`: the entity's getter is `isRead()` (no "get" prefix), which
 * Jackson serializes as the JSON field "read" — NOT "isRead". Getting this
 * wrong silently breaks all read/unread styling, so keep it as `read`.
 */
export interface Notification {
  // notification_id is a String PK on the backend (e.g. "NOTIF-1A2B3C4D").
  notificationId?: string;
  userEmail: string;
  title: string;
  body: string;
  channels?: string[];
  read?: boolean;
  createdAt?: string;
}
