import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="topbar">
      <button class="hamburger" (click)="sidebarOpen.set(!sidebarOpen())">☰</button>
      <a routerLink="/customer/dashboard" class="brand" style="text-decoration:none;">
        <div class="logo">
          <img src="assets/images/logo.png" width="34" style="border-radius:8px;" alt="HLMS" />
        </div>
        <div>
          <div class="title">HLMS</div>
          <div class="subtitle">Housing Loan Management System</div>
        </div>
      </a>
      <div class="topbar-search">
        <input placeholder="Search anything..." disabled title="Search coming soon" />
      </div>
      <div class="topbar-right">
        <button class="icon-btn" title="Notifications" (click)="togglePanel()">
          🔔<span class="icon-dot">{{ notifSvc.unreadCount() }}</span>
        </button>
        <a routerLink="/customer/profile" class="user-chip" style="text-decoration:none;">
          <div class="user-avatar">{{ initials() }}</div>
          <div class="user-name">{{ auth.currentUser()?.name || 'User' }}</div>
        </a>
        <button class="btn btn-outline btn-sm" (click)="logout()">Log Out</button>
      </div>
    </div>

    @if (panelOpen()) {
      <div class="notif-backdrop" (click)="panelOpen.set(false)"></div>
      <div class="card notif-panel">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <h3 style="margin:0;">🔔 Notifications</h3>
          <button class="btn-link" (click)="panelOpen.set(false)">Minimize</button>
        </div>

        @if (notifSvc.unreadCount() > 0) {
          <button class="btn-link" style="margin-top:6px;" (click)="markAllRead()">Mark all as read</button>
        }

        <div style="margin-top:10px;max-height:60vh;overflow:auto;">
          @if (!notifSvc.notifications().length) {
            <div class="empty-state"><div class="ic">📭</div>No notifications yet.</div>
          } @else {
            @for (n of notifSvc.notifications(); track n.notificationId) {
              <div class="note-item" style="cursor:pointer;" (click)="markRead(n.notificationId, n.read)">
                <strong>{{ n.title }}</strong>
                @if (!n.read) { <span class="badge badge-teal" style="margin-left:6px;">New</span> }
                <div style="font-size:12.5px;color:var(--text-mid);">{{ n.body }}</div>
                <div class="dt">{{ n.createdAt | date: 'medium' }}</div>
              </div>
            }
          }
        </div>

        <a routerLink="/customer/support" class="btn-link" style="display:block;margin-top:10px;" (click)="panelOpen.set(false)">
          View All →
        </a>
      </div>
    }
  `
})
export class Topbar implements OnInit {
  auth = inject(AuthService);
  notifSvc = inject(NotificationService);
  private router = inject(Router);

  sidebarOpen = signal(false);
  panelOpen = signal(false);

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    // A notification failure must never block the portal from rendering.
    this.notifSvc.loadForUser(email).subscribe({ error: () => {} });
  }

  initials(): string {
    const name = this.auth.currentUser()?.name || 'U';
    return name
      .split(' ')
      .map((p) => p[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  }

  togglePanel(): void {
    this.panelOpen.update((v) => !v);
  }

  markRead(notificationId: string | undefined, alreadyRead: boolean | undefined): void {
    if (!notificationId || alreadyRead) return;
    this.notifSvc.markRead(notificationId).subscribe({ error: () => {} });
  }

  markAllRead(): void {
    this.notifSvc.markAllRead().subscribe({ error: () => {} });
  }

  logout(): void {
    this.auth.logout();
  }
}
