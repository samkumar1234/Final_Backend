import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { RepaymentService } from '../../core/services/repayment.service';
import { ToastService } from '../../core/services/toast.service';

import {
  BalanceEligibility,
  Disbursement,
  ExpectedCompletion,
  LoanApplication,
  StakeholderInfo,
  WorkflowTimelineResponse
} from '../../core/models/models';

/**
 * One row of the customer's construction disbursement table.
 *
 * NOTE on phase count: the backend models a construction loan as ONE
 * disbursement row holding TWO tranches (first credit + withheld balance
 * released after the engineer's sign is verified). So this table shows the
 * two phases that actually exist in the data, not a fixed four. If the
 * product ever moves to genuine 4-stage staged disbursement, this interface
 * stays the same and only the builder below changes.
 */
export interface ConstructionPhase {
  no: number;
  stage: string;
  amount: number | null;
  released: number;
  engineerStatus: string;
  phaseStatus: 'DISBURSED' | 'REQUESTED' | 'NOT_STARTED';
  disbursedAt: string | null;
}

@Component({
  selector: 'app-tracking',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './tracking.html'
})
export class Tracking {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private repaymentSvc = inject(RepaymentService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  apps = signal<LoanApplication[]>([]);
  listLoading = signal(true);

  selectedId = signal<string | null>(null);
  detailLoading = signal(false);
  detailError = signal('');

  application = signal<LoanApplication | null>(null);
  stakeholder = signal<StakeholderInfo | null>(null);
  timeline = signal<WorkflowTimelineResponse | null>(null);
  expected = signal<ExpectedCompletion | null>(null);

  // ---- construction disbursement progress ----
  disbursement = signal<Disbursement | null>(null);
  balanceCheck = signal<BalanceEligibility | null>(null);

  /** Total the bank approved. Falls back to the application when the
   *  disbursement row predates the tranche columns. */
  sanctioned = computed<number>(() => {
    const d = this.disbursement();
    const app = this.application();
    return Number(d?.sanctionedAmount ?? app?.loanAmount ?? 0);
  });

  /** Money actually in the customer's account so far. */
  released = computed<number>(() => {
    const d = this.disbursement();
    if (!d) {
      return 0;
    }
    return Number(d.disbursedAmount ?? d.amount ?? 0);
  });

  remaining = computed<number>(() => {
    const d = this.disbursement();
    const pending = d?.pendingAmount;
    if (pending !== undefined && pending !== null) {
      return Number(pending);
    }
    return Math.max(0, this.sanctioned() - this.released());
  });

  progressPct = computed<number>(() => {
    const total = this.sanctioned();
    if (total <= 0) {
      return 0;
    }
    return Math.min(100, Math.round((this.released() / total) * 100));
  });

  /** Show the panel only for a loan that is actually staged. */
  showConstructionPanel = computed<boolean>(() => {
    const d = this.disbursement();
    if (!d) {
      return false;
    }
    const product = (this.application()?.productId || '').toUpperCase();
    return (
      product.includes('CONSTRUCTION') ||
      d.disbursementType === 'PARTIAL' ||
      !!d.balanceReleasedDate ||
      Number(d.pendingAmount ?? 0) > 0
    );
  });

  phases = computed<ConstructionPhase[]>(() => {
    const d = this.disbursement();
    if (!d) {
      return [];
    }

    const total = this.sanctioned();
    const credited = this.released();
    const pending = this.remaining();
    const fullyReleased = pending <= 0;

    // Tranche 1. Recorded explicitly from v5 onwards; for a row still
    // awaiting its balance it is simply whatever has been credited.
    const firstRaw = d.firstTrancheAmount ?? (fullyReleased ? null : credited);
    const first = firstRaw === null || firstRaw === undefined ? null : Number(firstRaw);

    // A straight full disbursement has nothing staged to show.
    if (fullyReleased && first === null) {
      return [
        {
          no: 1,
          stage: 'Full Disbursement',
          amount: credited,
          released: credited,
          engineerStatus: 'NOT REQUIRED',
          phaseStatus: 'DISBURSED',
          disbursedAt: d.disbursedDate ?? null
        }
      ];
    }

    const firstAmount = first ?? credited;
    const balanceAmount = Math.max(0, total - firstAmount);

    const phases: ConstructionPhase[] = [
      {
        no: 1,
        stage: 'Initial Release — on sanction',
        amount: firstAmount,
        released: firstAmount,
        engineerStatus: 'NOT REQUIRED',
        phaseStatus: 'DISBURSED',
        disbursedAt: d.disbursedDate ?? null
      }
    ];

    if (balanceAmount <= 0 && fullyReleased) {
      return phases;
    }

    const sign = this.balanceCheck()?.engineerSignStatus;
    const engineerStatus = fullyReleased ? 'VERIFIED' : this.signLabel(sign);

    let phaseStatus: ConstructionPhase['phaseStatus'];
    if (fullyReleased) {
      phaseStatus = 'DISBURSED';
    } else if (!sign || sign === 'NOT_UPLOADED') {
      phaseStatus = 'NOT_STARTED';
    } else {
      phaseStatus = 'REQUESTED';
    }

    phases.push({
      no: 2,
      stage: "Balance Release — after engineer's sign",
      amount: balanceAmount,
      released: fullyReleased ? balanceAmount : 0,
      engineerStatus,
      phaseStatus,
      disbursedAt: fullyReleased ? d.balanceReleasedDate ?? null : null
    });

    return phases;
  });

  /** True while the customer still has to upload the engineer's sign. */
  needsEngineerSign = computed<boolean>(() => {
    const sign = this.balanceCheck()?.engineerSignStatus;
    return this.remaining() > 0 && (!sign || sign === 'NOT_UPLOADED' || sign === 'REJECTED');
  });

  constructor() {
    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.listLoading.set(false);
      return;
    }

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.apps.set(list || []);
        this.listLoading.set(false);

        const routeAppId = this.route.snapshot.paramMap.get('appId');

        if (routeAppId) {
          this.select(routeAppId);
        }
      },
      error: () => {
        this.apps.set([]);
        this.listLoading.set(false);
      }
    });
  }

  select(appId: string): void {
    this.selectedId.set(appId);
    this.detailLoading.set(true);
    this.detailError.set('');

    this.application.set(null);
    this.stakeholder.set(null);
    this.timeline.set(null);
    this.expected.set(null);
    this.disbursement.set(null);
    this.balanceCheck.set(null);

    this.loanSvc.getApplication(appId).subscribe({
      next: (app) => {
        this.application.set(app);
      },
      error: () => {
        this.detailError.set('Could not load this application.');
      }
    });

    this.loanSvc.stakeholder(appId).subscribe({
      next: (s) => {
        this.stakeholder.set(s);
      },
      error: () => {
        this.stakeholder.set(null);
      }
    });

    this.loanSvc.timeline(appId).subscribe({
      next: (t) => {
        this.timeline.set(t);
        this.detailLoading.set(false);
      },
      error: () => {
        this.timeline.set(null);
        this.detailLoading.set(false);
      }
    });

    this.loanSvc.expectedCompletion(appId).subscribe({
      next: (e) => {
        this.expected.set(e);
      },
      error: () => {
        this.expected.set(null);
      }
    });

    // 404 here just means nothing has been disbursed yet, which is the normal
    // state for most of the workflow - so a failure is silent, not an error.
    this.repaymentSvc.disbursementByApp(appId).subscribe({
      next: (d) => {
        this.disbursement.set(d || null);

        if (d && Number(d.pendingAmount ?? 0) > 0) {
          this.repaymentSvc.balanceEligibility(appId).subscribe({
            next: (check) => this.balanceCheck.set(check),
            error: () => this.balanceCheck.set(null)
          });
        }
      },
      error: () => {
        this.disbursement.set(null);
        this.balanceCheck.set(null);
      }
    });
  }

  /** Turns the backend's engineer-sign enum into something a customer reads. */
  signLabel(status: string | null | undefined): string {
    switch (status) {
      case 'VERIFIED':
        return 'VERIFIED';
      case 'PENDING_VERIFICATION':
        return 'PENDING';
      case 'REJECTED':
        return 'REJECTED';
      case 'NOT_UPLOADED':
        return 'NOT UPLOADED';
      default:
        return 'PENDING';
    }
  }

  phaseBadgeClass(status: string): string {
    if (status === 'DISBURSED' || status === 'VERIFIED') {
      return 'badge-green';
    }
    if (status === 'REJECTED') {
      return 'badge-red';
    }
    if (status === 'REQUESTED' || status === 'PENDING') {
      return 'badge-orange';
    }
    return 'badge-gray';
  }

  deselect(): void {
    this.selectedId.set(null);
    this.router.navigate(['/customer/tracking']);
  }

  withdraw(appId: string): void {
    if (!confirm('Are you sure you want to withdraw this application? This cannot be undone.')) {
      return;
    }

    this.loanSvc.withdraw(appId).subscribe({
      next: () => {
        this.toast.success('Application withdrawn');

        this.apps.update((list) =>
          list.filter((a) => a.appId !== appId)
        );

        this.deselect();
      },
      error: () => {
        this.toast.error('Could not withdraw', 'Please try again.');
      }
    });
  }

  badgeClass(status: string | null | undefined): string {
    const s = (status || '').trim().toLowerCase();

    if (
      s.includes('reject') ||
      s.includes('decline') ||
      s.includes('failed') ||
      s.includes('cancel') ||
      s.includes('withdraw')
    ) {
      return 'badge-red';
    }

    if (
      s.includes('active') ||
      s.includes('disbursed') ||
      s.includes('approved') ||
      s.includes('completed') ||
      s.includes('verified') ||
      s.includes('paid')
    ) {
      return 'badge-green';
    }

    if (
      s.includes('draft') ||
      s.includes('submitted') ||
      s.includes('pending') ||
      s.includes('verification') ||
      s.includes('review') ||
      s.includes('decision') ||
      s.includes('processing')
    ) {
      return 'badge-orange';
    }

    return 'badge-gray';
  }

  isRejected(status: string | null | undefined): boolean {
    const s = (status || '').trim().toLowerCase();

    return (
      s.includes('reject') ||
      s.includes('decline') ||
      s.includes('failed') ||
      s.includes('cancel') ||
      s.includes('withdraw')
    );
  }

timelineStepClass(
  stepStatus: string | null | undefined,
  appStatus: string | null | undefined,
  stepIndex: number | null | undefined,
  appStageIndex: number | null | undefined
): string {
  if (this.isRejected(appStatus)) {
    if (stepIndex === appStageIndex || stepStatus === 'current') {
      return 'rejected';
    }
  }

  if (stepStatus === 'completed') {
    return 'done';
  }

  if (stepStatus === 'current') {
    return 'current';
  }

  return '';
}
}