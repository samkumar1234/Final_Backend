import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, forkJoin, of, tap } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Notification, ServiceRequest } from '../models/models';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private base = `${environment.apiBase}/notification-service/api`;

  // ---- topbar bell state ----
  // Shared across every component that injects this service (root-provided),
  // so the sidebar/topbar badge and the dropdown panel always agree.
  readonly notifications = signal<Notification[]>([]);
  readonly unreadCount = signal(0);

  constructor(private http: HttpClient) {}

  // ---- Notifications ----

  listForUser(userEmail: string): Observable<Notification[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    return this.http.get<Notification[]>(`${this.base}/notifications`, { params });
  }

  unread(userEmail: string): Observable<Notification[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    return this.http.get<Notification[]>(`${this.base}/notifications/unread`, { params });
  }

  /**
   * Loads the bell dropdown's state: the full list (already newest-first
   * from the backend), with unreadCount derived from the same list so the
   * badge and the panel can never disagree with each other.
   */
  loadForUser(userEmail: string): Observable<Notification[]> {
    return this.listForUser(userEmail).pipe(
      tap((list) => {
        this.notifications.set(list || []);
        this.unreadCount.set((list || []).filter((n) => !n.read).length);
      })
    );
  }

  markRead(notificationId: string): Observable<Notification> {
    return this.http.patch<Notification>(`${this.base}/notifications/${notificationId}/read`, {}).pipe(
      tap((updated) => {
        this.notifications.update((list) =>
          list.map((n) => (n.notificationId === updated.notificationId ? updated : n))
        );
        this.unreadCount.update((c) => Math.max(0, c - 1));
      })
    );
  }

  /**
   * NotificationController has no bulk-read endpoint, so this fires one PATCH
   * per unread notification and settles once they've all completed.
   */
  markAllRead(): Observable<Notification[]> {
    const unread = this.notifications().filter((n) => !n.read && n.notificationId);
    if (unread.length === 0) {
      return of([]);
    }
    return forkJoin(unread.map((n) => this.markRead(n.notificationId!)));
  }

  // ---- Service requests (e.g. duplicate statement, loan closure letter, NOC) ----

  listServiceRequests(userEmail: string): Observable<ServiceRequest[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    return this.http.get<ServiceRequest[]>(`${this.base}/service-requests`, { params });
  }

  listServiceRequestsForApp(appId: string): Observable<ServiceRequest[]> {
    return this.http.get<ServiceRequest[]>(`${this.base}/service-requests/by-app/${appId}`);
  }

  createServiceRequest(body: {
    userEmail: string;
    appId?: string;
    requestType: string;
    description?: string;
  }): Observable<ServiceRequest> {
    return this.http.post<ServiceRequest>(`${this.base}/service-requests`, body);
  }
}
