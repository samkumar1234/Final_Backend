export interface Notification {
  // notification_id is a String PK on the backend (e.g. "NOTIF-1A2B3C4D"), not
  // an auto-increment number.
  notificationId?: string;
  userEmail: string;
  title: string;
  body: string;
  read: boolean;
  createdAt?: string;
}

export interface ServiceRequest {
  requestId?: string;
  appId?: string;
  userEmail: string;
  requestType: string;
  description: string;
  status?: string;
  createdAt?: string;
}
