import { Component, EventEmitter, OnInit, Output, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { BidderAuthService } from '../../core/services/auth.service';
import { BidderNotificationService } from '../../core/services/notification.service';

@Component({
  selector: 'app-bidder-topbar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="topbar">
      <button class="hamburger" (click)="toggleSidebar.emit()">☰</button>
      <div class="brand">
        <div class="logo"><img src="assets/images/favicon.png" width="40px" style="border-radius:2px;" /></div>
        <div>
          <div class="title">HLMS</div>
          <div class="subtitle">Housing Loan Management System</div>
        </div>
      </div>
      <div class="topbar-search"></div>
      <div class="topbar-right">
        <button class="icon-btn" title="Notifications" (click)="togglePanel()">
          🔔<span class="icon-dot">{{ notifService.unreadCount() }}</span>
        </button>
        <div class="user-chip" (click)="goSettings()">
          <div class="user-avatar">{{ initials() }}</div>
          <div class="user-name">{{ auth.currentUser()?.name || 'Bidder' }}</div>
        </div>
      </div>
    </div>

    @if (panelOpen()) {
      <div class="notif-backdrop" (click)="panelOpen.set(false)"></div>
      <div class="card notif-panel">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <h3 style="margin:0;">🔔 Notifications</h3>
          <button class="btn-link" (click)="panelOpen.set(false)">Minimize</button>
        </div>

        @if (notifService.unreadCount() > 0) {
          <button class="btn-link" style="margin-top:6px;" (click)="markAllRead()">Mark all as read</button>
        }

        <div style="margin-top:10px;max-height:60vh;overflow:auto;">
          @if (!notifService.notifications().length) {
            <div class="empty-state"><div class="ic">📭</div>No notifications yet.</div>
          } @else {
            @for (n of notifService.notifications(); track n.notificationId) {
              <div class="note-item" style="cursor:pointer;" (click)="markRead(n.notificationId, n.read)">
                <strong>{{ n.title }}</strong>
                @if (!n.read) { <span class="badge badge-teal" style="margin-left:6px;">New</span> }
                <div style="font-size:12.5px;color:var(--text-mid);">{{ n.body }}</div>
                <div class="dt">{{ n.createdAt | date: 'medium' }}</div>
              </div>
            }
          }
        </div>
      </div>
    }
  `
})
export class BidderTopbarComponent implements OnInit {
  @Output() toggleSidebar = new EventEmitter<void>();

  auth = inject(BidderAuthService);
  notifService = inject(BidderNotificationService);
  private router = inject(Router);

  panelOpen = signal(false);

  ngOnInit(): void {
    const email = this.auth.email();
    // A notification failure must never block the portal from rendering.
    if (email) this.notifService.loadForUser(email).subscribe({ error: () => {} });
  }

  initials(): string {
    const name = this.auth.currentUser()?.name || 'Bidder';
    return name.split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase();
  }

  togglePanel(): void {
    this.panelOpen.update((v) => !v);
  }

  markRead(notificationId: string | undefined, alreadyRead: boolean | undefined): void {
    if (!notificationId || alreadyRead) return;
    this.notifService.markRead(notificationId).subscribe({ error: () => {} });
  }

  markAllRead(): void {
    this.notifService.markAllRead().subscribe({ error: () => {} });
  }

  goSettings(): void {
    this.router.navigate(['/bidder', 'biddersettings']);
  }
}
