package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.EmiInstallment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmiInstallmentRepository extends JpaRepository<EmiInstallment, String> {
    Optional<EmiInstallment> findByInstallmentIdAndDeletedAtIsNull(String installmentId);
    List<EmiInstallment> findByDeletedAtIsNull();
    List<EmiInstallment> findByAppIdAndDeletedAtIsNull(String appId);

    /**
     * CHG(v5 - balance-release fix): every installment row for an
     * application, INCLUDING rows a previous rebuild soft-deleted.
     *
     * The DB enforces UNIQUE (app_id, installment_no) across the whole
     * table - the constraint knows nothing about deleted_at. So a
     * soft-deleted installment #1 still occupies that slot, and inserting a
     * fresh installment #1 during a schedule rebuild fails with a duplicate
     * key error. regenerateSchedule() needs to see those rows in order to
     * physically remove them first.
     */
    List<EmiInstallment> findByAppId(String appId);
}
