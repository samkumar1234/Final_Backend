package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.client.DocumentServiceClient;
import com.hlms2.repayment.client.LoanServiceClient;
import com.hlms2.repayment.dto.BalanceEligibilityDTO;
import com.hlms2.repayment.dto.DisbursementDTO;
import com.hlms2.repayment.entity.Disbursement;
import com.hlms2.repayment.entity.LoanApplication;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.DisbursementRepository;
import com.hlms2.repayment.repository.LoanApplicationRepository;
import com.hlms2.repayment.service.DisbursementService;
import com.hlms2.repayment.service.EmiInstallmentService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class DisbursementServiceImpl implements DisbursementService {

    private static final Logger log = LoggerFactory.getLogger(DisbursementServiceImpl.class);

    private static final List<String> VALID_MODES = List.of(
            "NEFT",
            "RTGS",
            "CHEQUE",
            "UPI"
    );

    // ---- construction-loan tranche vocabulary ----
    public static final String TYPE_FULL = "FULL";
    public static final String TYPE_PARTIAL = "PARTIAL";
    public static final String TRANCHE_COMPLETED = "COMPLETED";
    public static final String TRANCHE_AWAITING_ENGINEER_SIGN = "AWAITING_ENGINEER_SIGN";

    public static final String SIGN_NOT_UPLOADED = "NOT_UPLOADED";
    public static final String SIGN_PENDING_VERIFICATION = "PENDING_VERIFICATION";
    public static final String SIGN_REJECTED = "REJECTED";
    public static final String SIGN_VERIFIED = "VERIFIED";
    public static final String SIGN_UNKNOWN = "UNKNOWN";

    private static final String STATUS_DISBURSED = "Disbursed";
    private static final String STATUS_PARTIALLY_DISBURSED = "Partially Disbursed";
    private static final int DISBURSEMENT_STAGE_INDEX = 5;

    private final DisbursementRepository repository;
    private final LoanServiceClient loanServiceClient;
    private final LoanApplicationRepository loanApplicationRepository;
    private final EmiInstallmentService emiInstallmentService;
    private final DocumentServiceClient documentServiceClient;

    /**
     * Product IDs treated as construction loans (LoanProductSeeder seeds
     * HL_CONSTRUCTION). Overridable per environment without a code change.
     */
    @Value("${hlms.disbursement.construction-product-ids:HL_CONSTRUCTION}")
    private String constructionProductIds = "HL_CONSTRUCTION";

    /**
     * The doc_type on post_disbursement_document that unlocks the balance
     * tranche. Matched case-insensitively, ignoring spaces/punctuation, so
     * "Engineer Sign", "Engineer's Sign" and "ENGINEER_SIGN" all match.
     */
    @Value("${hlms.disbursement.engineer-sign-doc-type:Engineer Sign}")
    private String engineerSignDocType = "Engineer Sign";

    public DisbursementServiceImpl(
            DisbursementRepository repository,
            LoanServiceClient loanServiceClient,
            LoanApplicationRepository loanApplicationRepository,
            EmiInstallmentService emiInstallmentService,
            DocumentServiceClient documentServiceClient) {

        this.repository = repository;
        this.loanServiceClient = loanServiceClient;
        this.loanApplicationRepository = loanApplicationRepository;
        this.emiInstallmentService = emiInstallmentService;
        this.documentServiceClient = documentServiceClient;
    }

    // =====================================================================
    // Create / update
    // =====================================================================

    @Override
    public DisbursementDTO create(DisbursementDTO dto) {
        Validators.required(dto.getAppId(), "appId");

        Disbursement existing = repository
                .findByAppIdAndDeletedAtIsNull(dto.getAppId())
                .orElse(null);

        if (existing != null) {
            // A disbursement row already exists for this application. If it is
            // a construction loan still awaiting its balance tranche, this is
            // NOT a re-run of the first tranche - the officer must go through
            // releaseBalance() so the engineer's-sign gate is enforced.
            if (isAwaitingBalance(existing)) {
                throw new ValidationException(
                        "Application " + existing.getAppId() + " has already had its first tranche disbursed and is "
                                + "awaiting the engineer's-sign verification. Use the balance release action instead.");
            }
            return completeExistingDisbursement(existing, dto);
        }

        return createNewDisbursement(dto);
    }

    private DisbursementDTO createNewDisbursement(DisbursementDTO dto) {
        normalize(dto);
        validate(dto);

        Disbursement entity = toEntity(dto);
        entity.setDisbursementId(null);

        if (entity.getDisbursedDate() == null) {
            entity.setDisbursedDate(OffsetDateTime.now());
        }

        applyTrancheState(entity, dto);

        Disbursement saved = repository.save(entity);

        notifyLoanService(saved);
        generateEmiSchedule(saved);

        return toDto(saved);
    }

    private DisbursementDTO completeExistingDisbursement(Disbursement existing, DisbursementDTO dto) {
        dto.setDisbursementId(existing.getDisbursementId());

        if (isBlank(dto.getAppId())) {
            dto.setAppId(existing.getAppId());
        }
        if (isBlank(dto.getBankDetails())) {
            dto.setBankDetails(existing.getBankDetails());
        }
        if (dto.getAmount() == null) {
            dto.setAmount(existing.getAmount());
        }
        if (isBlank(dto.getRefNo())) {
            dto.setRefNo(existing.getRefNo());
        }
        if (isBlank(dto.getMode())) {
            dto.setMode(existing.getMode());
        }
        if (dto.getDisbursedDate() == null) {
            dto.setDisbursedDate(
                    existing.getDisbursedDate() != null ? existing.getDisbursedDate() : OffsetDateTime.now());
        }

        normalize(dto);
        validate(dto);

        existing.setAppId(dto.getAppId());
        existing.setAmount(dto.getAmount());
        existing.setRefNo(dto.getRefNo());
        existing.setMode(dto.getMode());
        existing.setBankDetails(dto.getBankDetails());
        existing.setDisbursedDate(dto.getDisbursedDate());

        applyTrancheState(existing, dto);

        Disbursement saved = repository.save(existing);

        notifyLoanService(saved);
        generateEmiSchedule(saved);

        return toDto(saved);
    }

    @Override
    public DisbursementDTO update(Long disbursementId, DisbursementDTO dto) {
        Disbursement existing = repository.findByDisbursementIdAndDeletedAtIsNull(disbursementId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("No disbursement found with id " + disbursementId + "."));

        if (isBlank(dto.getAppId())) {
            dto.setAppId(existing.getAppId());
        }
        if (isBlank(dto.getBankDetails())) {
            dto.setBankDetails(existing.getBankDetails());
        }
        if (dto.getAmount() == null) {
            dto.setAmount(existing.getAmount());
        }
        if (isBlank(dto.getRefNo())) {
            dto.setRefNo(existing.getRefNo());
        }
        if (isBlank(dto.getMode())) {
            dto.setMode(existing.getMode());
        }
        if (dto.getDisbursedDate() == null) {
            dto.setDisbursedDate(existing.getDisbursedDate());
        }

        normalize(dto);
        validate(dto);

        existing.setAppId(dto.getAppId());
        existing.setAmount(dto.getAmount());
        existing.setRefNo(dto.getRefNo());
        existing.setMode(dto.getMode());
        existing.setBankDetails(dto.getBankDetails());
        existing.setDisbursedDate(dto.getDisbursedDate());

        applyTrancheState(existing, dto);

        Disbursement saved = repository.save(existing);

        notifyLoanService(saved);
        generateEmiSchedule(saved);

        return toDto(saved);
    }

    // =====================================================================
    // Construction-loan balance release
    // =====================================================================

    @Override
    public DisbursementDTO releaseBalance(String appId, DisbursementDTO dto) {
        Validators.required(appId, "appId");

        Disbursement existing = repository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("No disbursement found for application " + appId + "."));

        BigDecimal pending = nvl(existing.getPendingAmount());

        if (!isAwaitingBalance(existing) || pending.signum() <= 0) {
            throw new ValidationException(
                    "Application " + appId + " has no pending balance tranche to release.");
        }

        String signStatus = engineerSignStatus(appId);

        if (!SIGN_VERIFIED.equals(signStatus)) {
            throw new ValidationException(reasonFor(signStatus));
        }

        DisbursementDTO input = dto == null ? new DisbursementDTO() : dto;

        String balanceRefNo = isBlank(input.getBalanceRefNo())
                ? (isBlank(input.getRefNo()) ? "BAL-" + System.currentTimeMillis() : input.getRefNo().trim())
                : input.getBalanceRefNo().trim();

        if (!isBlank(input.getMode())) {
            String mode = input.getMode().trim().toUpperCase();
            Validators.oneOf(mode, "mode", VALID_MODES.toArray(new String[0]));
            existing.setMode(mode);
        }

        if (!isBlank(input.getBankDetails())) {
            existing.setBankDetails(input.getBankDetails().trim());
        }

        BigDecimal sanctioned = nvl(existing.getSanctionedAmount());
        BigDecimal fullyDisbursed = scale(nvl(existing.getDisbursedAmount()).add(pending));

        // Defensive: never credit more than what was sanctioned.
        if (sanctioned.signum() > 0 && fullyDisbursed.compareTo(sanctioned) > 0) {
            fullyDisbursed = scale(sanctioned);
        }

        // Rows written before v5 have no tranche 1 figure recorded. This is
        // the last moment it can still be derived, so backfill it here.
        if (existing.getFirstTrancheAmount() == null) {
            existing.setFirstTrancheAmount(scale(nvl(existing.getDisbursedAmount())));
        }

        existing.setDisbursedAmount(fullyDisbursed);
        existing.setAmount(fullyDisbursed);
        existing.setPendingAmount(BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
        existing.setTrancheStatus(TRANCHE_COMPLETED);
        existing.setBalanceRefNo(balanceRefNo);
        existing.setBalanceReleasedDate(OffsetDateTime.now());

        Disbursement saved = repository.save(existing);

        // Sam's choice: rebuild the full schedule after each tranche, so the
        // customer's EMI now reflects the entire sanctioned amount rather
        // than tranche 1 only.
        rebuildEmiSchedule(saved);
        notifyLoanService(saved);

        log.info("Balance tranche of {} released for {} (ref {}).", pending, appId, balanceRefNo);

        return toDto(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public BalanceEligibilityDTO checkBalanceEligibility(String appId) {
        Validators.required(appId, "appId");

        Disbursement existing = repository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("No disbursement found for application " + appId + "."));

        BalanceEligibilityDTO result = new BalanceEligibilityDTO();
        result.setAppId(appId);
        result.setTrancheStatus(existing.getTrancheStatus());
        result.setSanctionedAmount(existing.getSanctionedAmount());
        result.setDisbursedAmount(existing.getDisbursedAmount());
        result.setPendingAmount(existing.getPendingAmount());

        if (!isAwaitingBalance(existing) || nvl(existing.getPendingAmount()).signum() <= 0) {
            result.setEligible(false);
            result.setEngineerSignStatus(SIGN_VERIFIED.equals(existing.getTrancheStatus())
                    ? SIGN_VERIFIED
                    : SIGN_UNKNOWN);
            result.setReason("This loan has no pending balance tranche.");
            return result;
        }

        String signStatus = engineerSignStatus(appId);

        result.setEngineerSignStatus(signStatus);
        result.setEligible(SIGN_VERIFIED.equals(signStatus));
        result.setReason(SIGN_VERIFIED.equals(signStatus)
                ? "Engineer's sign verified - balance can be released."
                : reasonFor(signStatus));

        return result;
    }

    /**
     * Reads the application's post-disbursement documents from
     * document-service and reduces them to a single engineer's-sign status.
     * A "Verified" document anywhere in the list wins; a rejection only
     * counts when nothing has been verified.
     */
    private String engineerSignStatus(String appId) {
        if (documentServiceClient == null) {
            return SIGN_UNKNOWN;
        }

        List<Map<String, Object>> docs;

        try {
            docs = documentServiceClient.getPostDisbursementDocuments(appId);
        } catch (Exception ex) {
            log.warn("Could not read post-disbursement documents for {} from document-service: {}",
                    appId, ex.getMessage());
            return SIGN_UNKNOWN;
        }

        if (docs == null || docs.isEmpty()) {
            return SIGN_NOT_UPLOADED;
        }

        boolean found = false;
        boolean rejected = false;

        for (Map<String, Object> doc : docs) {
            if (doc == null || doc.get("deletedAt") != null) {
                continue;
            }
            if (!matchesEngineerSign(asString(doc.get("docType")))) {
                continue;
            }

            found = true;
            String status = asString(doc.get("status"));

            if ("Verified".equalsIgnoreCase(status)) {
                return SIGN_VERIFIED;
            }
            if ("Rejected".equalsIgnoreCase(status)) {
                rejected = true;
            }
        }

        if (!found) {
            return SIGN_NOT_UPLOADED;
        }

        return rejected ? SIGN_REJECTED : SIGN_PENDING_VERIFICATION;
    }

    private String reasonFor(String signStatus) {
        return switch (signStatus) {
            case SIGN_NOT_UPLOADED -> "The engineer's-sign document has not been uploaded yet.";
            case SIGN_PENDING_VERIFICATION -> "The engineer's-sign document is uploaded but not yet verified by Legal.";
            case SIGN_REJECTED -> "The engineer's-sign document was rejected. A fresh document must be uploaded and verified.";
            case SIGN_UNKNOWN -> "Could not confirm the engineer's-sign document with document-service. Try again shortly.";
            default -> "Balance release is not available for this application.";
        };
    }

    private boolean matchesEngineerSign(String docType) {
        if (docType == null) {
            return false;
        }
        return simplify(docType).contains(simplify(engineerSignDocType));
    }

    /** Strips everything but letters/digits and lowercases, so "Engineer's Sign" == "ENGINEER_SIGN". */
    private String simplify(String value) {
        return value == null ? "" : value.replaceAll("[^A-Za-z0-9]", "").toLowerCase();
    }

    // =====================================================================
    // Tranche state
    // =====================================================================

    /**
     * Decides, at save time, whether this disbursement is a single full
     * credit or the first tranche of a construction loan, and fills in the
     * sanctioned / disbursed / pending columns accordingly.
     *
     * Rules:
     *  - non-construction product  -> FULL, nothing pending
     *  - construction, amount >= sanctioned -> FULL (officer chose to credit
     *    everything up front; still valid, just no balance to hold back)
     *  - construction, amount < sanctioned  -> PARTIAL, balance withheld
     *    until the engineer's sign is verified
     */
    private void applyTrancheState(Disbursement entity, DisbursementDTO dto) {
        // Once completed, a later edit must not silently re-open a balance.
        if (TRANCHE_COMPLETED.equals(entity.getTrancheStatus())
                && nvl(entity.getPendingAmount()).signum() <= 0
                && entity.getBalanceReleasedDate() != null) {

            entity.setDisbursedAmount(scale(nvl(entity.getAmount())));
            return;
        }

        LoanApplication app = loanApplication(entity.getAppId());

        BigDecimal credited = scale(nvl(entity.getAmount()));

        BigDecimal sanctioned = dto != null && dto.getSanctionedAmount() != null
                ? scale(dto.getSanctionedAmount())
                : (app != null && app.getLoanAmount() != null ? scale(app.getLoanAmount()) : credited);

        if (sanctioned.signum() <= 0) {
            sanctioned = credited;
        }

        if (credited.compareTo(sanctioned) > 0) {
            throw new ValidationException(
                    "Disbursement amount (" + credited + ") cannot exceed the sanctioned loan amount ("
                            + sanctioned + ").");
        }

        boolean construction = isConstructionLoan(app);
        BigDecimal pending = scale(sanctioned.subtract(credited));

        if (!construction || pending.signum() <= 0) {
            entity.setSanctionedAmount(sanctioned);
            entity.setDisbursedAmount(credited);
            entity.setPendingAmount(BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
            entity.setDisbursementType(TYPE_FULL);
            entity.setTrancheStatus(TRANCHE_COMPLETED);
            entity.setFirstTrancheAmount(credited);
            return;
        }

        entity.setSanctionedAmount(sanctioned);
        entity.setDisbursedAmount(credited);
        entity.setPendingAmount(pending);
        entity.setDisbursementType(TYPE_PARTIAL);
        entity.setTrancheStatus(TRANCHE_AWAITING_ENGINEER_SIGN);

        // CHG(v5): remember what tranche 1 credited. releaseBalance() will
        // overwrite disbursedAmount with the full sanctioned amount, and the
        // customer's phase-wise tracking view needs the split back.
        entity.setFirstTrancheAmount(credited);
    }

    private boolean isAwaitingBalance(Disbursement entity) {
        return TRANCHE_AWAITING_ENGINEER_SIGN.equals(entity.getTrancheStatus());
    }

    private boolean isConstructionLoan(LoanApplication app) {
        if (app == null || isBlank(app.getProductId())) {
            return false;
        }

        String productId = app.getProductId().trim();

        for (String candidate : constructionProductIds.split(",")) {
            if (candidate.trim().equalsIgnoreCase(productId)) {
                return true;
            }
        }

        return false;
    }

    private LoanApplication loanApplication(String appId) {
        if (loanApplicationRepository == null || appId == null) {
            return null;
        }
        return loanApplicationRepository.findByAppIdAndDeletedAtIsNull(appId).orElse(null);
    }

    // =====================================================================
    // Reads
    // =====================================================================

    @Override
    public boolean softDelete(Long disbursementId) {
        return repository.findByDisbursementIdAndDeletedAtIsNull(disbursementId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                })
                .orElse(false);
    }

    @Override
    public boolean restore(Long disbursementId) {
        return repository.findById(disbursementId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                })
                .orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public DisbursementDTO findById(Long disbursementId) {
        return repository.findByDisbursementIdAndDeletedAtIsNull(disbursementId)
                .map(this::toDto)
                .orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public DisbursementDTO findByAppId(String appId) {
        Validators.required(appId, "appId");

        return repository.findByAppIdAndDeletedAtIsNull(appId)
                .map(this::toDto)
                .orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DisbursementDTO> findAll() {
        return repository.findByDeletedAtIsNull()
                .stream()
                .map(this::toDto)
                .toList();
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private void normalize(DisbursementDTO dto) {
        if (dto.getMode() != null) {
            dto.setMode(dto.getMode().trim().toUpperCase());
        }
        if (dto.getRefNo() != null) {
            dto.setRefNo(dto.getRefNo().trim());
        }
        if (dto.getBankDetails() != null) {
            dto.setBankDetails(dto.getBankDetails().trim());
        }
        if (dto.getDisbursedDate() == null) {
            dto.setDisbursedDate(OffsetDateTime.now());
        }
    }

    private void validate(DisbursementDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.positive(dto.getAmount(), "amount");
        Validators.required(dto.getRefNo(), "refNo");
        Validators.oneOf(dto.getMode(), "mode", VALID_MODES.toArray(new String[0]));
        Validators.required(dto.getBankDetails(), "bankDetails");

        if (dto.getSanctionedAmount() != null && dto.getSanctionedAmount().signum() <= 0) {
            throw new ValidationException("sanctionedAmount must be positive.");
        }

        if (dto.getDisbursedDate() != null && dto.getDisbursedDate().isAfter(OffsetDateTime.now())) {
            throw new ValidationException("disbursedDate cannot be in the future.");
        }
    }

    /** First tranche (or a full credit): build the schedule if none exists. */
    private void generateEmiSchedule(Disbursement disbursement) {
        buildEmiSchedule(disbursement, false);
    }

    /** Balance release: tear down the old schedule and rebuild on the new total. */
    private void rebuildEmiSchedule(Disbursement disbursement) {
        buildEmiSchedule(disbursement, true);
    }

    private void buildEmiSchedule(Disbursement disbursement, boolean rebuild) {
        if (emiInstallmentService == null) {
            return;
        }

        try {
            LoanApplication loanApplication = loanApplication(disbursement.getAppId());

            if (loanApplication == null) {
                log.warn("Could not generate EMI schedule for {}: loan application not found.",
                        disbursement.getAppId());
                return;
            }

            BigDecimal principal = disbursement.getDisbursedAmount() != null
                    ? disbursement.getDisbursedAmount()
                    : (disbursement.getAmount() != null ? disbursement.getAmount() : loanApplication.getLoanAmount());

            Integer tenureYears = loanApplication.getTenureYears();

            if (principal == null || tenureYears == null) {
                log.warn("Could not generate EMI schedule for {}: missing principal or tenure.",
                        disbursement.getAppId());
                return;
            }

            OffsetDateTime disbursedDate = disbursement.getDisbursedDate() != null
                    ? disbursement.getDisbursedDate()
                    : OffsetDateTime.now();

            if (rebuild) {
                emiInstallmentService.regenerateSchedule(
                        disbursement.getAppId(),
                        principal,
                        loanApplication.getInterestRate(),
                        tenureYears,
                        disbursedDate.toLocalDate().plusMonths(1)
                );
            } else {
                emiInstallmentService.generateSchedule(
                        disbursement.getAppId(),
                        principal,
                        loanApplication.getInterestRate(),
                        tenureYears,
                        disbursedDate.toLocalDate().plusMonths(1)
                );
            }

        } catch (ValidationException ex) {
            // A rebuild is refused when installments have already been paid -
            // that is a real business condition the officer must see, not a
            // background warning to swallow.
            if (rebuild) {
                throw ex;
            }
            log.warn("EMI schedule generation failed for {}: {}", disbursement.getAppId(), ex.getMessage());
        } catch (Exception ex) {
            log.warn("EMI schedule generation failed for {}: {}", disbursement.getAppId(), ex.getMessage());
        }
    }

    /**
     * Pushes the disbursement outcome back to loan-service. A construction
     * loan sitting on its first tranche is reported as "Partially Disbursed"
     * so no downstream screen treats it as fully funded.
     */
    private void notifyLoanService(Disbursement disbursement) {
        if (loanServiceClient == null || disbursement == null || disbursement.getAppId() == null) {
            return;
        }

        String status = isAwaitingBalance(disbursement) && nvl(disbursement.getPendingAmount()).signum() > 0
                ? STATUS_PARTIALLY_DISBURSED
                : STATUS_DISBURSED;

        try {
            loanServiceClient.updateLoanStage(
                    disbursement.getAppId(),
                    Map.of(
                            "stageIndex", DISBURSEMENT_STAGE_INDEX,
                            "status", status
                    )
            );
        } catch (Exception ex) {
            log.warn("Could not push disbursement status for {} to loan-service: {}",
                    disbursement.getAppId(),
                    ex.getMessage());
        }
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static BigDecimal nvl(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private static BigDecimal scale(BigDecimal value) {
        return nvl(value).setScale(2, RoundingMode.HALF_UP);
    }

    private static String asString(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    private Disbursement toEntity(DisbursementDTO dto) {
        return Disbursement.builder()
                .disbursementId(dto.getDisbursementId())
                .appId(dto.getAppId())
                .disbursedDate(dto.getDisbursedDate())
                .amount(dto.getAmount())
                .refNo(dto.getRefNo())
                .mode(dto.getMode())
                .bankDetails(dto.getBankDetails())
                .sanctionedAmount(dto.getSanctionedAmount())
                .build();
    }

    private DisbursementDTO toDto(Disbursement entity) {
        return DisbursementDTO.builder()
                .disbursementId(entity.getDisbursementId())
                .appId(entity.getAppId())
                .disbursedDate(entity.getDisbursedDate())
                .amount(entity.getAmount())
                .refNo(entity.getRefNo())
                .mode(entity.getMode())
                .bankDetails(entity.getBankDetails())
                .sanctionedAmount(entity.getSanctionedAmount())
                .disbursedAmount(entity.getDisbursedAmount())
                .pendingAmount(entity.getPendingAmount())
                .disbursementType(entity.getDisbursementType())
                .trancheStatus(entity.getTrancheStatus())
                .balanceRefNo(entity.getBalanceRefNo())
                .balanceReleasedDate(entity.getBalanceReleasedDate())
                .firstTrancheAmount(entity.getFirstTrancheAmount())
                .build();
    }
}
