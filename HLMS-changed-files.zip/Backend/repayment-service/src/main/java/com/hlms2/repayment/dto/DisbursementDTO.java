package com.hlms2.repayment.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * CHG(v4): carries the construction-loan tranche fields alongside the
 * original disbursement fields. `amount` continues to mean "money actually
 * credited so far", so nothing that already reads this DTO needs changing.
 */
public class DisbursementDTO {
    private Long disbursementId;
    private String appId;
    private OffsetDateTime disbursedDate;
    private BigDecimal amount;
    private String refNo;
    private String mode;
    private String bankDetails;

    // ---- construction-loan tranche fields (v4) ----
    private BigDecimal sanctionedAmount;
    private BigDecimal disbursedAmount;
    private BigDecimal pendingAmount;
    private String disbursementType;
    private String trancheStatus;
    private String balanceRefNo;
    private OffsetDateTime balanceReleasedDate;

    /** CHG(v5): what tranche 1 credited, so the split survives the balance release. */
    private BigDecimal firstTrancheAmount;

    public DisbursementDTO() {
    }

    /** Pre-v4 constructor - kept so existing callers/tests still compile. */
    public DisbursementDTO(Long disbursementId, String appId, OffsetDateTime disbursedDate, BigDecimal amount, String refNo, String mode, String bankDetails) {
        this.disbursementId = disbursementId;
        this.appId = appId;
        this.disbursedDate = disbursedDate;
        this.amount = amount;
        this.refNo = refNo;
        this.mode = mode;
        this.bankDetails = bankDetails;
    }

    public DisbursementDTO(Long disbursementId, String appId, OffsetDateTime disbursedDate, BigDecimal amount,
                           String refNo, String mode, String bankDetails, BigDecimal sanctionedAmount,
                           BigDecimal disbursedAmount, BigDecimal pendingAmount, String disbursementType,
                           String trancheStatus, String balanceRefNo, OffsetDateTime balanceReleasedDate) {
        this(disbursementId, appId, disbursedDate, amount, refNo, mode, bankDetails);
        this.sanctionedAmount = sanctionedAmount;
        this.disbursedAmount = disbursedAmount;
        this.pendingAmount = pendingAmount;
        this.disbursementType = disbursementType;
        this.trancheStatus = trancheStatus;
        this.balanceRefNo = balanceRefNo;
        this.balanceReleasedDate = balanceReleasedDate;
    }

    public Long getDisbursementId() {
        return disbursementId;
    }
    public void setDisbursementId(Long disbursementId) {
        this.disbursementId = disbursementId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public OffsetDateTime getDisbursedDate() {
        return disbursedDate;
    }
    public void setDisbursedDate(OffsetDateTime disbursedDate) {
        this.disbursedDate = disbursedDate;
    }
    public BigDecimal getAmount() {
        return amount;
    }
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    public String getRefNo() {
        return refNo;
    }
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    public String getMode() {
        return mode;
    }
    public void setMode(String mode) {
        this.mode = mode;
    }
    public String getBankDetails() {
        return bankDetails;
    }
    public void setBankDetails(String bankDetails) {
        this.bankDetails = bankDetails;
    }

    public BigDecimal getSanctionedAmount() {
        return sanctionedAmount;
    }
    public void setSanctionedAmount(BigDecimal sanctionedAmount) {
        this.sanctionedAmount = sanctionedAmount;
    }
    public BigDecimal getDisbursedAmount() {
        return disbursedAmount;
    }
    public void setDisbursedAmount(BigDecimal disbursedAmount) {
        this.disbursedAmount = disbursedAmount;
    }
    public BigDecimal getPendingAmount() {
        return pendingAmount;
    }
    public void setPendingAmount(BigDecimal pendingAmount) {
        this.pendingAmount = pendingAmount;
    }
    public String getDisbursementType() {
        return disbursementType;
    }
    public void setDisbursementType(String disbursementType) {
        this.disbursementType = disbursementType;
    }
    public String getTrancheStatus() {
        return trancheStatus;
    }
    public void setTrancheStatus(String trancheStatus) {
        this.trancheStatus = trancheStatus;
    }
    public String getBalanceRefNo() {
        return balanceRefNo;
    }
    public void setBalanceRefNo(String balanceRefNo) {
        this.balanceRefNo = balanceRefNo;
    }
    public OffsetDateTime getBalanceReleasedDate() {
        return balanceReleasedDate;
    }
    public void setBalanceReleasedDate(OffsetDateTime balanceReleasedDate) {
        this.balanceReleasedDate = balanceReleasedDate;
    }
    public BigDecimal getFirstTrancheAmount() {
        return firstTrancheAmount;
    }
    public void setFirstTrancheAmount(BigDecimal firstTrancheAmount) {
        this.firstTrancheAmount = firstTrancheAmount;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long disbursementId;
        private String appId;
        private OffsetDateTime disbursedDate;
        private BigDecimal amount;
        private String refNo;
        private String mode;
        private String bankDetails;
        private BigDecimal sanctionedAmount;
        private BigDecimal disbursedAmount;
        private BigDecimal pendingAmount;
        private String disbursementType;
        private String trancheStatus;
        private String balanceRefNo;
        private OffsetDateTime balanceReleasedDate;
        private BigDecimal firstTrancheAmount;

        public Builder disbursementId(Long disbursementId) {
            this.disbursementId = disbursementId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder disbursedDate(OffsetDateTime disbursedDate) {
            this.disbursedDate = disbursedDate;
            return this;
        }
        public Builder amount(BigDecimal amount) {
            this.amount = amount;
            return this;
        }
        public Builder refNo(String refNo) {
            this.refNo = refNo;
            return this;
        }
        public Builder mode(String mode) {
            this.mode = mode;
            return this;
        }
        public Builder bankDetails(String bankDetails) {
            this.bankDetails = bankDetails;
            return this;
        }
        public Builder sanctionedAmount(BigDecimal sanctionedAmount) {
            this.sanctionedAmount = sanctionedAmount;
            return this;
        }
        public Builder disbursedAmount(BigDecimal disbursedAmount) {
            this.disbursedAmount = disbursedAmount;
            return this;
        }
        public Builder pendingAmount(BigDecimal pendingAmount) {
            this.pendingAmount = pendingAmount;
            return this;
        }
        public Builder disbursementType(String disbursementType) {
            this.disbursementType = disbursementType;
            return this;
        }
        public Builder trancheStatus(String trancheStatus) {
            this.trancheStatus = trancheStatus;
            return this;
        }
        public Builder balanceRefNo(String balanceRefNo) {
            this.balanceRefNo = balanceRefNo;
            return this;
        }
        public Builder balanceReleasedDate(OffsetDateTime balanceReleasedDate) {
            this.balanceReleasedDate = balanceReleasedDate;
            return this;
        }

        public Builder firstTrancheAmount(BigDecimal firstTrancheAmount) {
            this.firstTrancheAmount = firstTrancheAmount;
            return this;
        }

        public DisbursementDTO build() {
            DisbursementDTO dto = new DisbursementDTO(disbursementId, appId, disbursedDate, amount, refNo, mode,
                    bankDetails, sanctionedAmount, disbursedAmount, pendingAmount, disbursementType, trancheStatus,
                    balanceRefNo, balanceReleasedDate);
            dto.setFirstTrancheAmount(firstTrancheAmount);
            return dto;
        }
    }
}
